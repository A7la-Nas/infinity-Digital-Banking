define("AuthenticationMA/AuthUIModule/frmLogin", function() {
    return function(controller) {
        function addWidgetsfrmLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var tbxAutopopulateIssueFix = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "tbxAutopopulateIssueFix",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "175dp",
                "secureTextEntry": false,
                "skin": "tbxInvisible",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "98dp",
                "width": "300dp",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxMain = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "580dp",
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 2
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxImgKony = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "60dp",
                "id": "flxImgKony",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10%",
                "isModalContainer": false,
                "top": "70dp",
                "width": "140dp",
                "zIndex": 6,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgKony.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "skin": "slImage",
                "src": "digital_banking.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgKony.add(imgKony);
            var flxDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "51dp",
                "skin": "flxHoverSkinPointer",
                "top": "31dp",
                "width": "299dp",
                "zIndex": 4,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var lblCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "52.00%",
                "id": "lblCheckBox",
                "isVisible": true,
                "right": "25dp",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": "17dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Product"
            });
            var imgDropdown = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Language Dropdown"
                },
                "centerY": "50%",
                "height": "7dp",
                "id": "imgDropdown",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "0%",
                "skin": "slImage",
                "src": "arrow_down.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLanguage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "English"
                },
                "centerY": "50.00%",
                "height": "25dp",
                "id": "lblLanguage",
                "isVisible": true,
                "left": "15dp",
                "right": "50dp",
                "skin": "sknLabelSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.ULT.OLB.Language\")",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "English"
            });
            flxDropdown.add(lblCheckBox, imgDropdown, lblLanguage);
            var flxLanguagePicker = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-live": "off",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLanguagePicker",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "73dp",
                "skin": "sknflxMenuTransprent",
                "top": "65dp",
                "width": "13.61%",
                "zIndex": 50,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLanguagePicker.setDefaultUnit(kony.flex.DP);
            var imgToolTip = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "10dp",
                "id": "imgToolTip",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "0.50%",
                "skin": "slImage",
                "src": "tool_tip.png",
                "top": "0dp",
                "width": "17dp",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDifferentLanguagesSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "blur": {
                    "enabled": false,
                    "value": 0
                },
                "clipBounds": false,
                "id": "flxDifferentLanguagesSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "sknflxShdwLangPopWeb104c7d",
                "top": "-3dp",
                "width": "100%",
                "zIndex": 50,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDifferentLanguagesSegment.setDefaultUnit(kony.flex.DP);
            var segLanguagesList = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segLanguagesList",
                "isVisible": true,
                "left": "0%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxLangList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnLang": "btnLang",
                    "flxLangList": "flxLangList",
                    "lblLang": "lblLang",
                    "lblSeparator": "lblSeparator",
                    "lblTranslatedLang": "lblTranslatedLang"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDifferentLanguagesSegment.add(segLanguagesList);
            flxLanguagePicker.add(imgToolTip, flxDifferentLanguagesSegment);
            var flxLogin = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "680dp",
                "width": "100%",
                "zIndex": 50,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogin.setDefaultUnit(kony.flex.DP);
            var flxLoginComponentContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoginComponentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0h3193b034de74c",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginComponentContainer.setDefaultUnit(kony.flex.DP);
            var flxCloseIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxCloseIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "111dp",
                "isModalContainer": false,
                "top": "233dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseIcon.setDefaultUnit(kony.flex.DP);
            var imgCloseIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "14%",
                "height": "64dp",
                "id": "imgCloseIcon",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "80dp",
                "skin": "slImage",
                "src": "digital_banking.png",
                "top": "13dp",
                "width": "102dp",
                "zIndex": 6
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseIcon.add(imgCloseIcon);
            var loginComponent = new com.InfinityOLB.AuthenticationMA.login({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "loginComponent",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "viewType": "loginComponent",
                "overrides": {
                    "login": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var loginComponent_data = (appConfig.componentMetadata && appConfig.componentMetadata["AuthenticationMA"] && appConfig.componentMetadata["AuthenticationMA"]["frmLogin"] && appConfig.componentMetadata["AuthenticationMA"]["frmLogin"]["loginComponent"]) || {};
            loginComponent.identityServiceName = loginComponent_data.identityServiceName || "DbxUserLogin";
            loginComponent.successCallback = loginComponent_data.successCallback || "{$.c.successCallback}";
            loginComponent.labelSkin = loginComponent_data.labelSkin || "{\"640\":{\"skin\":\"sknSSP72727213Px\"},\"768\":{\"skin\":\"sknlbl727272SSPReg15px\"},\"1024\":{\"skin\":\"sknlbl727272SSPReg15px\"},\"default\":{\"skin\":\"sknlbl727272SSPReg15px\"}}";
            loginComponent.riskScore = loginComponent_data.riskScore || "{$.c.riskScore}";
            loginComponent.username = loginComponent_data.username || "";
            loginComponent.failureCallback = loginComponent_data.failureCallback || "{$.c.failureCallback}";
            loginComponent.flxSkins = loginComponent_data.flxSkins || "{\"normalSkin\":\"sknBorderE3E3E3\", \"focusSkin\":\"sknFocusBorder293275\", \"errorSkin\" : \"sknborderff0000error\"}";
            loginComponent.closePopups = loginComponent_data.closePopups || "null";
            loginComponent.primaryBtnEnableSkin = loginComponent_data.primaryBtnEnableSkin || "{\"normal\":\"sknBtnNormalSSPFFFFFF15Px\", \"hoverSkin\":\"sknBtnNormalSSPFFFFFFHover15Px\", \"focusSkin\":\"sknBtnNormalSSPFFFFFF15PxFocus\"}";
            loginComponent.primaryBtnDisableSkin = loginComponent_data.primaryBtnDisableSkin || "{\"normal\":\"sknBtnBlockedSSPFFFFFF15Px\", \"hoverSkin\":\"sknBtnBlockedSSPFFFFFF15Px\", \"focusSkin\":\"sknBtnBlockedSSPFFFFFF15Px\"}";
            var flxInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80dp",
                "id": "flxInfo",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "16dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "40dp",
                "skin": "slImage",
                "src": "info_image.png",
                "top": "10dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"I18n.billPay.QuitTransactionMsg\")"
                },
                "id": "rtxInfo",
                "isVisible": true,
                "left": "65dp",
                "text": "If you forgot Temporary Password or Missed Temporary Password or want to reset temporary password”, click “Cant' sign-in” option to Reset password.",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 10, 0, 10],
                "paddingInPixel": true
            }, {});
            flxInfo.add(imgInfo, rtxInfo);
            var flxNewNEnroll = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxNewNEnroll",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "4%",
                "width": "85%",
                "zIndex": 10,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewNEnroll.setDefaultUnit(kony.flex.DP);
            var flxOpenNewAccount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxOpenNewAccount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOpenNewAccount.setDefaultUnit(kony.flex.DP);
            var btnOpenNewAccount = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "allyARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "id": "btnOpenNewAccount",
                "isVisible": true,
                "left": 0,
                "skin": "sknBtnSSP0273E314Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.CreateNewAccount\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgInfoIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Info "
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxImgInfoIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "7dp",
                "width": "20dp",
                "zIndex": 5,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgInfoIcon.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "15dp",
                "id": "imgInfoIcon",
                "isVisible": true,
                "left": "17.50%",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0dp",
                "width": "15dp",
                "zIndex": 5
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgInfoIcon.add(imgInfoIcon);
            flxOpenNewAccount.add(btnOpenNewAccount, flxImgInfoIcon);
            var flxAllForms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxAllForms",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 10,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAllForms.setDefaultUnit(kony.flex.DP);
            var AllForms1 = new com.InfinityOLB.BillPay.InfoIcon.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "AllForms1",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "-130dp",
                "width": "100%",
                "zIndex": 10000,
                "appName": "BillPayMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": false,
                        "left": "0dp",
                        "top": "-130dp",
                        "zIndex": 10000
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAllForms.add(AllForms1);
            var btnOnlineAccessEnroll = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Enroll / Activate"
                },
                "id": "btnOnlineAccessEnroll",
                "isVisible": true,
                "maxWidth": "45%",
                "right": 0,
                "skin": "sknBtnSSP0273E314Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Login.EnrollActivate\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 7
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewNEnroll.add(flxOpenNewAccount, flxAllForms, btnOnlineAccessEnroll);
            var carousel = new com.InfinityOLB.Resources.carousel({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "175px",
                "id": "carousel",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": "10dp",
                "width": "95%",
                "appName": "ResourcesMA",
                "overrides": {
                    "carousel": {
                        "bottom": "viz.val_cleared",
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "height": "175px",
                        "isVisible": false,
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "10dp",
                        "width": "95%"
                    },
                    "segCarousel": {
                        "left": "-5px",
                        "right": "-5px",
                        "width": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAppStore = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "52px",
                "id": "flxAppStore",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "545dp",
                "width": "150dp",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAppStore.setDefaultUnit(kony.flex.DP);
            var imgAppstore = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "46px",
                "id": "imgAppstore",
                "isVisible": true,
                "left": "95dp",
                "skin": "slImage",
                "src": "appstore_2x.png",
                "top": "0dp",
                "width": "144px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAppStore.add(imgAppstore);
            var flxPlayStore = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "0dp",
                "id": "flxPlayStore",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "545dp",
                "width": "0dp",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPlayStore.setDefaultUnit(kony.flex.DP);
            var imgPlayStore = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "height": "150dp",
                "id": "imgPlayStore",
                "isVisible": true,
                "left": "95dp",
                "skin": "slImage",
                "src": "google_play_2x.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPlayStore.add(imgPlayStore);
            flxLoginComponentContainer.add(flxCloseIcon, loginComponent, flxInfo, flxNewNEnroll, carousel, flxAppStore, flxPlayStore);
            var OTPComponent = new com.InfinityOLB.Resources.mfa.OTPModule({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "OTPComponent",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ResourcesMA",
                "viewType": "OTPComponent",
                "overrides": {
                    "OTPModule": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var OTPComponent_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmLogin"] && appConfig.componentMetadata["ResourcesMA"]["frmLogin"]["OTPComponent"]) || {};
            OTPComponent.primaryBtnEnableSkin = OTPComponent_data.primaryBtnEnableSkin || "{\"normal\":\"sknBtnNormalSSPFFFFFF15Px\", \"hoverSkin\":\"sknBtnNormalSSPFFFFFFHover15Px\", \"focusSkin\":\"sknBtnNormalSSPFFFFFF15PxFocus\"}";
            OTPComponent.displayAll = OTPComponent_data.displayAll || "DISPLAY_ALL";
            OTPComponent.serviceKey = OTPComponent_data.serviceKey || "";
            OTPComponent.objectService = OTPComponent_data.objectService || "Login";
            OTPComponent.primaryBtnDisableSkin = OTPComponent_data.primaryBtnDisableSkin || "{\"normal\":\"sknBtnBlockedSSP0273e315px\", \"hoverSkin\":\"sknBtnBlockedSSP0273e315px\", \"focusSkin\":\"sknBtnBlockedSSP0273e315px\"}";
            OTPComponent.displayPrimary = OTPComponent_data.displayPrimary || "DISPLAY_PRIMARY";
            OTPComponent.dataModel = OTPComponent_data.dataModel || "Users_2";
            OTPComponent.isPostLogin = OTPComponent_data.isPostLogin || false;
            OTPComponent.verifyOTPOperationName = OTPComponent_data.verifyOTPOperationName || "verifyLoginMFAOTP";
            OTPComponent.displayNoValue = OTPComponent_data.displayNoValue || "DISPLAY_NO_VALUE";
            OTPComponent.errorFlexSkin = OTPComponent_data.errorFlexSkin || "sknborderff0000error";
            OTPComponent.serviceName = OTPComponent_data.serviceName || "SERVICE_ID_67";
            OTPComponent.requestOTPOperationName = OTPComponent_data.requestOTPOperationName || "requestLoginMFAOTP";
            OTPComponent.normalFlexSkin = OTPComponent_data.normalFlexSkin || "sknBorderE3E3E3";
            OTPComponent.resendOTPOperationName = OTPComponent_data.resendOTPOperationName || "requestLoginMFAOTP";
            OTPComponent.communicationType = OTPComponent_data.communicationType || "";
            OTPComponent.checkboxSelectedSkin = OTPComponent_data.checkboxSelectedSkin || "sknFontIconCheckBoxSelected";
            OTPComponent.action = OTPComponent_data.action || "";
            OTPComponent.checkboxSelected = OTPComponent_data.checkboxSelected || "C";
            OTPComponent.checkboxUnSelectedSkin = OTPComponent_data.checkboxUnSelectedSkin || "skn0273e320pxolbfonticons";
            OTPComponent.checkboxUnSelected = OTPComponent_data.checkboxUnSelected || "D";
            var cantSignIn = new com.InfinityOLB.AuthenticationMA.cantSignIn({
                "height": "100%",
                "id": "cantSignIn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "cantSignIn": {
                        "centerX": "viz.val_cleared",
                        "height": "100%",
                        "isVisible": true,
                        "top": "0dp",
                        "width": "100%"
                    },
                    "flxContent": {
                        "isVisible": true,
                        "width": "85%"
                    },
                    "flxHeader": {
                        "height": "120dp",
                        "isVisible": true,
                        "top": "0dp"
                    },
                    "imgCaptcha": {
                        "src": "imagedrag.png"
                    },
                    "imgClose": {
                        "src": "bbcloseicon.png"
                    },
                    "imgUserVerify": {
                        "src": "user_verify.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var regenrateActivationCodeComponent = new com.InfinityOLB.AuthenticationMA.regenrateActivationCode({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "regenrateActivationCodeComponent",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "viewType": "regenrateActivationCodeComponent",
                "overrides": {
                    "regenrateActivationCode": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var regenrateActivationCodeComponent_data = (appConfig.componentMetadata && appConfig.componentMetadata["AuthenticationMA"] && appConfig.componentMetadata["AuthenticationMA"]["frmLogin"] && appConfig.componentMetadata["AuthenticationMA"]["frmLogin"]["regenrateActivationCodeComponent"]) || {};
            regenrateActivationCodeComponent.sknLblCongratulations = regenrateActivationCodeComponent_data.sknLblCongratulations || "{\"1024\": \"sknLabel42424224px\", \"default\": \"sknSSP72727220Px\"}";
            regenrateActivationCodeComponent.sknLblActivationcodeRegenerated = regenrateActivationCodeComponent_data.sknLblActivationcodeRegenerated || "{\"640\" : \"sknLabel42424224px\", \"768\": \"sknLabel42424224px\", \"1024\": \"bbSknLbl424242SSP15Px\", \"default\": \"sknlbl42424240px\"}";
            regenrateActivationCodeComponent.sknLblText = regenrateActivationCodeComponent_data.sknLblText || "{\"640\" : \"sknlbl727272SSPReg15px\", \"768\": \"sknlbl727272SSPReg15px\", \"1024\": \"sknlbl727272SSPReg15px\", \"default\": \"bbSknLbl424242SSP20Px\"}";
            regenrateActivationCodeComponent.btnEnableSkin = regenrateActivationCodeComponent_data.btnEnableSkin || "{\"640\" : {\"normalSkin\": \"sknBtnNormalSSPFFFFFF13Px\", \"hoverSkin\": \"sknBtnNormalSSPFFFFFFHover13Px\", \"focusSkin\": \"sknBtnNormalSSPFFFFFF13PxFocus\"}, \"768\": {\"normalSkin\": \"sknBtnNormalSSPFFFFFF13Px\", \"hoverSkin\": \"sknBtnNormalSSPFFFFFFHover13Px\", \"focusSkin\": \"sknBtnNormalSSPFFFFFF13PxFocus\"}, \"default\": {\"normalSkin\": \"sknBtnNormalSSPFFFFFF15Px\", \"hoverSkin\": \"sknBtnNormalSSPFFFFFFHover15Px\", \"focusSkin\": \"sknBtnNormalSSPFFFFFF15PxFocus\"}}";
            regenrateActivationCodeComponent.btnDisableSkin = regenrateActivationCodeComponent_data.btnDisableSkin || "{\"640\" : {\"normalSkin\": \"sknBtnBlockedSSP0273e313px\", \"hoverSkin\": \"sknBtnBlockedSSP0273e313px\", \"focusSkin\": \"sknBtnBlockedSSP0273e313px\"}, \"768\": {\"normalSkin\": \"sknBtnBlockedSSP0273e313px\", \"hoverSkin\": \"sknBtnBlockedSSP0273e313px\", \"focusSkin\": \"sknBtnBlockedSSP0273e313px\"},\"default\": {\"normalSkin\": \"sknBtnBlockedSSP0273e315px\", \"hoverSkin\": \"sknBtnBlockedSSP0273e315px\", \"focusSkin\": \"sknBtnBlockedSSP0273e315px\"}}";
            var resetPasswordComponent = new com.InfinityOLB.AuthenticationMA.resetPassword({
                "height": "100%",
                "id": "resetPasswordComponent",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "viewType": "resetPasswordComponent",
                "overrides": {
                    "resetPassword": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var resetPasswordComponent_data = (appConfig.componentMetadata && appConfig.componentMetadata["AuthenticationMA"] && appConfig.componentMetadata["AuthenticationMA"]["frmLogin"] && appConfig.componentMetadata["AuthenticationMA"]["frmLogin"]["resetPasswordComponent"]) || {};
            resetPasswordComponent.primaryBtnDisableSkin = resetPasswordComponent_data.primaryBtnDisableSkin || "{\"640\" : {\"normalSkin\": \"sknBtnBlockedSSP0273e313px\", \"hoverSkin\": \"sknBtnBlockedSSP0273e313px\", \"focusSkin\": \"sknBtnBlockedSSP0273e313px\"}, \"768\": {\"normalSkin\": \"sknBtnBlockedSSP0273e313px\", \"hoverSkin\": \"sknBtnBlockedSSP0273e313px\", \"focusSkin\": \"sknBtnBlockedSSP0273e313px\"},\"default\": {\"normalSkin\": \"sknBtnBlockedSSP0273e315px\", \"hoverSkin\": \"sknBtnBlockedSSP0273e315px\", \"focusSkin\": \"sknBtnBlockedSSP0273e315px\"}}";
            resetPasswordComponent.exclamationFontIcon = resetPasswordComponent_data.exclamationFontIcon || "K";
            resetPasswordComponent.textAlignment = resetPasswordComponent_data.textAlignment || "{\"640\":\"CONTENT_ALIGN_CENTER\", \"768\":\"CONTENT_ALIGN_CENTER\", \"1024\":\"CONTENT_ALIGN_CENTER\", \"default\":\"CONTENT_ALIGN_MIDDLE_LEFT\"}";
            resetPasswordComponent.username = resetPasswordComponent_data.username || "";
            resetPasswordComponent.objectService = resetPasswordComponent_data.objectService || "Users_2";
            resetPasswordComponent.primaryBtnEnableSkin = resetPasswordComponent_data.primaryBtnEnableSkin || "{\"640\" : {\"normalSkin\": \"sknBtnNormalSSPFFFFFF13Px\", \"hoverSkin\": \"sknBtnNormalSSPFFFFFFHover13Px\", \"focusSkin\": \"sknBtnNormalSSPFFFFFF13PxFocus\"}, \"768\": {\"normalSkin\": \"sknBtnNormalSSPFFFFFF13Px\", \"hoverSkin\": \"sknBtnNormalSSPFFFFFFHover13Px\", \"focusSkin\": \"sknBtnNormalSSPFFFFFF13PxFocus\"}, \"default\": {\"normalSkin\": \"sknBtnNormalSSPFFFFFF15Px\", \"hoverSkin\": \"sknBtnNormalSSPFFFFFFHover15Px\", \"focusSkin\": \"sknBtnNormalSSPFFFFFF15PxFocus\"}}";
            resetPasswordComponent.tickFontIcon = resetPasswordComponent_data.tickFontIcon || "N";
            resetPasswordComponent.serviceKey = resetPasswordComponent_data.serviceKey || "";
            resetPasswordComponent.resetPasswordRequestOTP = resetPasswordComponent_data.resetPasswordRequestOTP || "requestResetPasswordOTP";
            resetPasswordComponent.flxSkins = resetPasswordComponent_data.flxSkins || "{\"normalSkin\": \"sknBorderE3E3E3\", \"focusSkin\": \"sknFlxBorder4A90E23px\", \"errorSkin\": \"sknborderff0000error\"}";
            resetPasswordComponent.resetPasswordVerifyOTP = resetPasswordComponent_data.resetPasswordVerifyOTP || "verifyOTPPreLogin";
            resetPasswordComponent.successIconSkin = resetPasswordComponent_data.successIconSkin || "sknFontIcon2a9e07Bgffffont18pxOlbFontIcon";
            resetPasswordComponent.resetDbxUserPassword = resetPasswordComponent_data.resetDbxUserPassword || "resetUserPassword";
            resetPasswordComponent.warningIconSkin = resetPasswordComponent_data.warningIconSkin || "sknFontIconffa909Bgffffont18pxOlbFontIcon";
            resetPasswordComponent.passwordRulesAndPoliciesOperation = resetPasswordComponent_data.passwordRulesAndPoliciesOperation || "getPasswordRulesAndPolicy";
            resetPasswordComponent.labelHeaderSkin = resetPasswordComponent_data.labelHeaderSkin || "{\"640\":\"sknLblSSP42424213px\", \"768\":\"sknLblSSP42424213px\", \"1024\":\"sknLblSSP42424215px\", \"default\":\"sknSSP42424217Px\"}";
            resetPasswordComponent.labelTitleSkin = resetPasswordComponent_data.labelTitleSkin || "{\"640\":\"sknLblSSP42424215px\", \"768\":\"sknLblSSP42424215px\", \"1024\":\"ICSknBBLabelSSP42424220px\", \"default\":\"ICSknBBLabelSSP42424220px\"}";
            resetPasswordComponent.labelInfoSkin = resetPasswordComponent_data.labelInfoSkin || "{\"640\":\"sknLblSSP72727213px\", \"768\":\"sknLblSSP72727213px\", \"1024\":\"sknLblSSP72727213px\", \"default\":\"sknLblSSP72727215px\"}";
            resetPasswordComponent.labelResendCodeSkin = resetPasswordComponent_data.labelResendCodeSkin || "{\"640\":\"sknSSP4176a413px\", \"768\":\"sknSSP4176a413px\", \"1024\":\"sknSSP4176a413px\", \"default\":\"bbSknLblSSP4176A415Px\"}";
            resetPasswordComponent.labelErrorSkin = resetPasswordComponent_data.labelErrorSkin || "{\"640\":\"sknlblff000015px\", \"768\":\"sknlblff000015px\", \"default\":\"sknlblff000015px\"}";
            resetPasswordComponent.labelUsernameTitleSkin = resetPasswordComponent_data.labelUsernameTitleSkin || "{\"640\":\"sknLblSSP42424215px\", \"768\":\"sknLblSSP42424215px\", \"default\":\"sknSSP72727220Px\"}";
            resetPasswordComponent.labelUsernameSkin = resetPasswordComponent_data.labelUsernameSkin || "{\"640\":\"sknlblSSPreg42424220px\", \"768\":\"sknlblSSPreg42424220px\", \"default\":\"sknlbl42424240px\"}";
            resetPasswordComponent.txtSkin = resetPasswordComponent_data.txtSkin || "{\"640\":\"sknTbxSSP42424213PxWithoutBorder\", \"768\":\"sknTbxSSP42424213PxWithoutBorder\", \"1024\":\"sknTbxSSP42424215PxWithoutBorder\", \"default\":\"sknTbxSSP42424215PxWithoutBorder\"}";
            flxLogin.add(flxLoginComponentContainer, OTPComponent, cantSignIn, regenrateActivationCodeComponent, resetPasswordComponent);
            var flxLegalEntity = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxLegalEntity",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50dp",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow",
                "top": "680dp",
                "width": "100%",
                "zIndex": 50,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegalEntity.setDefaultUnit(kony.flex.DP);
            var flxOuter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxOuter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOuter.setDefaultUnit(kony.flex.DP);
            flxOuter.add();
            var flxLegalEntitySelect1 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLegalEntitySelect1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegalEntitySelect1.setDefaultUnit(kony.flex.DP);
            var lblPleaseSelectEntity = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblPleaseSelectEntity",
                "isVisible": true,
                "left": "41dp",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.legalEntity.pleaseSelectAnEntity\")",
                "top": "4dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLegalEntitySelect1.add(lblPleaseSelectEntity);
            var flxLegalEntityMain = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLegalEntityMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegalEntityMain.setDefaultUnit(kony.flex.DP);
            var lblSelectEntity = new kony.ui.Label({
                "id": "lblSelectEntity",
                "isVisible": true,
                "left": "0",
                "text": "Select Entity",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLegalEntityDropDown = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLegalEntityDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegalEntityDropDown.setDefaultUnit(kony.flex.DP);
            var lblSelectLegalEntity = new kony.ui.Label({
                "id": "lblSelectLegalEntity",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgdropdownExpand = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgdropdownExpand",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "25dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLegalEntityDropDown.add(lblSelectLegalEntity, imgdropdownExpand);
            var flxLegalEntityCombine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLegalEntityCombine",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow",
                "top": "70dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegalEntityCombine.setDefaultUnit(kony.flex.DP);
            var flxLegalSearch = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxLegalSearch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegalSearch.setDefaultUnit(kony.flex.DP);
            var txtLegalSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtLegalSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Search",
                "secureTextEntry": false,
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var imgSearch = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgSearch",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLegalSearch.add(txtLegalSearch, imgSearch);
            var flxLegalDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxLegalDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLegalDropdown.setDefaultUnit(kony.flex.DP);
            var lblLegalEntityHeader = new kony.ui.Label({
                "id": "lblLegalEntityHeader",
                "isVisible": false,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segLegalEntity = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "groupCells": false,
                "height": "240dp",
                "id": "segLegalEntity",
                "isVisible": true,
                "left": "0",
                "maxHeight": "400dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "99%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLegalDropdown.add(lblLegalEntityHeader, segLegalEntity);
            flxLegalEntityCombine.add(flxLegalSearch, flxLegalDropdown);
            var flxRemember = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRemember",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "90dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRemember.setDefaultUnit(kony.flex.DP);
            var flexcheckuncheck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flexcheckuncheck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flexcheckuncheck.setDefaultUnit(kony.flex.DP);
            var imgRememberMe = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgRememberMe",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "0%",
                "skin": "slImage",
                "src": "unchecked_box.png",
                "top": "0%",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFavoriteEmailCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "id": "lblFavoriteEmailCheckBox",
                "isVisible": true,
                "skin": "sknFontIconCheckBoxSelected",
                "text": "D",
                "top": 0,
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flexcheckuncheck.add(imgRememberMe, lblFavoriteEmailCheckBox);
            var lblRememberMe = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblRememberMe",
                "isVisible": true,
                "left": 10,
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.legalEntity.SetAsDefaultEntity\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRemember.add(flexcheckuncheck, lblRememberMe);
            var btnLegalEntity = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yHint": "Click on Log In to log into your account"
                },
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnLegalEntity",
                "isVisible": true,
                "left": "0",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.btnContinue\")",
                "top": "29dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxLegalEntityMain.add(lblSelectEntity, flxLegalEntityDropDown, flxLegalEntityCombine, flxRemember, btnLegalEntity);
            var flxCloseLegalEntity = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxCloseLegalEntity",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "111dp",
                "isModalContainer": false,
                "top": "233dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseLegalEntity.setDefaultUnit(kony.flex.DP);
            var imgCloseLegalEntity = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "14%",
                "height": "64dp",
                "id": "imgCloseLegalEntity",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "80dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "13dp",
                "width": "102dp",
                "zIndex": 6
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseLegalEntity.add(imgCloseLegalEntity);
            flxLegalEntity.add(flxOuter, flxLegalEntitySelect1, flxLegalEntityMain, flxCloseLegalEntity);
            var flxLoginSelectedUsername = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxLoginSelectedUsername",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "500dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginSelectedUsername.setDefaultUnit(kony.flex.DP);
            var MainLogin = new com.InfinityOLB.AuthenticationMA.main({
                "height": "100%",
                "id": "MainLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "btnForgotPassword": {
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Login.CantLogin\")",
                        "right": "3.0599999999999996%",
                        "width": "50%"
                    },
                    "btnLogin": {
                        "centerX": "86%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.login\")",
                        "left": "0"
                    },
                    "btnOnlineAccessEnroll": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Login.Enroll\")",
                        "width": "40%"
                    },
                    "btnOpenNewAccount": {
                        "centerX": "25%",
                        "width": "40%"
                    },
                    "flxContainer": {
                        "centerX": "viz.val_cleared",
                        "height": "568dp",
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "500dp"
                    },
                    "flxHeaderNError": {
                        "isVisible": true
                    },
                    "flxImageUser": {
                        "isVisible": true,
                        "left": "0",
                        "top": "16.28%"
                    },
                    "flxPassword": {
                        "top": "3.50%"
                    },
                    "flxRemember": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "width": "47%"
                    },
                    "flxRememberMe": {
                        "height": "70dp"
                    },
                    "flxUserDropdown": {
                        "isVisible": false
                    },
                    "flxUserName": {
                        "isVisible": false,
                        "top": "4%"
                    },
                    "imgInfoIcon": {
                        "src": "info_grey.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgPassword": {
                        "src": "password.png"
                    },
                    "imgRememberMe": {
                        "src": "unchecked_box.png"
                    },
                    "imgUser": {
                        "centerX": "12.25%",
                        "centerY": "27.17%",
                        "isVisible": false,
                        "src": "default_username.png"
                    },
                    "imgUserAToolTip": {
                        "src": "username_tooltip.png"
                    },
                    "imgUserName": {
                        "isVisible": false,
                        "src": "username.png"
                    },
                    "imgUserOutline": {
                        "centerX": "12.25%",
                        "centerY": "27.17%",
                        "isVisible": false,
                        "src": "verify_user.png"
                    },
                    "imgViewPassword": {
                        "src": "view.png"
                    },
                    "lblRememberMe": {
                        "text": "R",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblWelcomeMobile": {
                        "isVisible": false,
                        "text": "Welcome Back"
                    },
                    "main": {
                        "isVisible": true,
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "rtxErrorMsg": {
                        "centerX": "48%",
                        "isVisible": true,
                        "top": "9dp"
                    },
                    "segUsers": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "data": [{
                            "lblBottom": "",
                            "lblusers": ""
                        }],
                        "maxHeight": "120dp"
                    },
                    "tbxPassword": {
                        "maxTextLength": 20,
                        "secureTextEntry": true
                    },
                    "tbxUserName": {
                        "left": "2%",
                        "maxTextLength": 24
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            MainLogin.btnForgotPassword.onClick = controller.AS_Button_ead9d66606d2401ea0d5e7bb9943bf25;
            MainLogin.btnLogin.onClick = controller.AS_Button_de4e981b9fec4fa78dae2465790df83f;
            MainLogin.btnOnlineAccessEnroll.onClick = controller.AS_Button_b1c783f693db4c88b35b960d93ccc013;
            MainLogin.btnOpenNewAccount.onClick = controller.AS_Button_jd7ba24236124efb8537a66ac4a97242;
            MainLogin.segUsers.onRowClick = controller.AS_Segment_e71ec59a0219453f9933531a29981d7c;
            MainLogin.tbxPassword.onBeginEditing = controller.AS_TextField_e48f6a4124bf4de286d0c4a912983d38;
            MainLogin.tbxPassword.onKeyUp = controller.AS_TextField_d95ee59d841c471cb206a8bf70db7295;
            MainLogin.tbxPassword.onDone = controller.AS_TextField_bcdc10ae8b1a403c82fa05d79cf6b6df;
            MainLogin.tbxUserName.onBeginEditing = controller.AS_TextField_ed806356b3314d86b37761258f426fca;
            MainLogin.tbxUserName.onEndEditing = controller.AS_TextField_ba5381fb58bc4e69a7e5366199a2aecb;
            MainLogin.tbxUserName.onKeyUp = controller.AS_TextField_cfa0d44f49e44ed09ae7f7c35af168f4;
            var lblWelcomeBackSelectedUsername = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblWelcomeBackSelectedUsername",
                "isVisible": true,
                "left": "63dp",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.WelcomeBackLabel\")",
                "top": "120dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var flxUserContentSelectUsername = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxUserContentSelectUsername",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "147dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "180dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserContentSelectUsername.setDefaultUnit(kony.flex.DP);
            var flxWelcomeUserImageSelectUsername = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "54dp",
                "id": "flxWelcomeUserImageSelectUsername",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5.28%",
                "width": "54dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWelcomeUserImageSelectUsername.setDefaultUnit(kony.flex.DP);
            var imgVerifiedUserSelectUsername = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "imgVerifiedUserSelectUsername",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "default_username.png",
                "width": "44dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVerifiedUserGreenFrameUsername = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "54dp",
                "id": "imgVerifiedUserGreenFrameUsername",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "user_verify_success.png",
                "width": "54dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWelcomeUserImageSelectUsername.add(imgVerifiedUserSelectUsername, imgVerifiedUserGreenFrameUsername);
            var lblYourSelectUsername = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "id": "lblYourSelectUsername",
                "isVisible": true,
                "left": "59dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.UserName\")",
                "top": "5.16%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var lblVerifiedSelectUsername = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblVerifiedSelectUsername",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknSSP42424230Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.WelcomeBack.JohnBailey\")",
                "top": "25.50%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserContentSelectUsername.add(flxWelcomeUserImageSelectUsername, lblYourSelectUsername, lblVerifiedSelectUsername);
            flxLoginSelectedUsername.add(MainLogin, lblWelcomeBackSelectedUsername, flxUserContentSelectUsername);
            var flxVerification = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxVerification",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerification.setDefaultUnit(kony.flex.DP);
            var letsverify = new com.InfinityOLB.Resources.letsverify({
                "height": "100%",
                "id": "letsverify",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "letsverify": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var AllForms = new com.InfinityOLB.BillPay.InfoIcon.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "AllForms",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA",
                "overrides": {
                    "imgCross": {
                        "src": "icon_close_grey.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgClose",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxClose.add(imgClose);
            flxVerification.add(letsverify, AllForms, flxClose);
            var flxWelcomeBack = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxWelcomeBack",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWelcomeBack.setDefaultUnit(kony.flex.DP);
            var flxCloseWelcomeBack = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseWelcomeBack",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseWelcomeBack.setDefaultUnit(kony.flex.DP);
            var imgCloseWelcomeBack = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseWelcomeBack",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "icon_close_grey.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseWelcomeBack.add(imgCloseWelcomeBack);
            var LblVerifiedUserWelcome = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "LblVerifiedUserWelcome",
                "isVisible": true,
                "left": "63dp",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.WelcomeBackLabel\")",
                "top": "18.64%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var flxUserContent = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxUserContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "147dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserContent.setDefaultUnit(kony.flex.DP);
            var flxWelcomeUserImage = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "54dp",
                "id": "flxWelcomeUserImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5.28%",
                "width": "54dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWelcomeUserImage.setDefaultUnit(kony.flex.DP);
            var imgVerifiedUser = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "imgVerifiedUser",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "default_username.png",
                "width": "44dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVerifiedUserGreenFrame = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "54dp",
                "id": "imgVerifiedUserGreenFrame",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "user_verify_success.png",
                "width": "54dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWelcomeUserImage.add(imgVerifiedUser, imgVerifiedUserGreenFrame);
            var lblYourUsername = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "id": "lblYourUsername",
                "isVisible": true,
                "left": "59dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.UserName\")",
                "top": "5.16%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var lblVerifiedUsername = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblVerifiedUsername",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknSSP42424230Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.WelcomeBack.JohnBailey\")",
                "top": "25.50%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserContent.add(flxWelcomeUserImage, lblYourUsername, lblVerifiedUsername);
            var flxWelcomeBackBtns = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxWelcomeBackBtns",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "46dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWelcomeBackBtns.setDefaultUnit(kony.flex.DP);
            var AlterneteActionsSignIn = new com.InfinityOLB.AuthenticationMA.AlterneteActions({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "focusSkin": "sknBgE3E3E3Op20Border4A90E2",
                "height": "10.66%",
                "id": "AlterneteActionsSignIn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_febaf38267ab420ea10a7175c9a77888,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "7.04%",
                "width": "85%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "10.66%",
                        "top": "7.04%"
                    },
                    "flxImgContainer": {
                        "height": "100%",
                        "left": "1dp"
                    },
                    "imgOptionKA": {
                        "height": "32dp",
                        "src": "login_signin.png",
                        "width": "33dp"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.SignInAs\")",
                        "top": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            AlterneteActionsSignIn.onTouchStart = controller.AS_UWI_febaf38267ab420ea10a7175c9a77888;
            var orlineWelcomeBack = new com.InfinityOLB.AuthenticationMA.orline({
                "height": "35dp",
                "id": "orlineWelcomeBack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "imgOr": {
                        "src": "or_circle.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var AlterneteActionsResetPassword = new com.InfinityOLB.AuthenticationMA.AlterneteActions({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "focusSkin": "sknBgE3E3E3Op20Border4A90E2",
                "height": "10.66%",
                "id": "AlterneteActionsResetPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_g49f33dc26c54fb5af2ced556a943d58,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "5.28%",
                "width": "85%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "10.66%",
                        "top": "5.28%"
                    },
                    "flxImgContainer": {
                        "height": "100%",
                        "left": "1dp"
                    },
                    "imgOptionKA": {
                        "src": "reset_password.png"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.ResetMyPassword\")",
                        "top": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            AlterneteActionsResetPassword.onTouchStart = controller.AS_UWI_g49f33dc26c54fb5af2ced556a943d58;
            flxWelcomeBackBtns.add(AlterneteActionsSignIn, orlineWelcomeBack, AlterneteActionsResetPassword);
            flxWelcomeBack.add(flxCloseWelcomeBack, LblVerifiedUserWelcome, flxUserContent, flxWelcomeBackBtns);
            var flxResetPasswordOptions = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "578dp",
                "id": "flxResetPasswordOptions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetPasswordOptions.setDefaultUnit(kony.flex.DP);
            var flxCloseResetPassword = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseResetPassword",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseResetPassword.setDefaultUnit(kony.flex.DP);
            var imgCloseResetPassword = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseResetPassword",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseResetPassword.add(imgCloseResetPassword);
            var lblResetYourPassword = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblResetYourPassword",
                "isVisible": true,
                "left": "63dp",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.ResetPassword\")",
                "top": "10.70%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var flxResetContent = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxResetContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "78dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetContent.setDefaultUnit(kony.flex.DP);
            var flxResetUserImg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "54dp",
                "id": "flxResetUserImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "54dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetUserImg.setDefaultUnit(kony.flex.DP);
            var imgUserReset = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "54dp",
                "id": "imgUserReset",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "default_username.png",
                "width": "54dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgUserBoundary = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "57dp",
                "id": "imgUserBoundary",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "verify_user.png",
                "width": "57dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxResetUserImg.add(imgUserReset, imgUserBoundary);
            var lvlVerificationNotice = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": 199,
                "id": "lvlVerificationNotice",
                "isVisible": true,
                "left": "60dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.VerificationNotice\")",
                "top": "8.95%",
                "width": "280dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [1, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxResetContent.add(flxResetUserImg, lvlVerificationNotice);
            var flxResetPassBtns = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxResetPassBtns",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "103dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetPassBtns.setDefaultUnit(kony.flex.DP);
            var AlterneteActionsEnterCVV = new com.InfinityOLB.AuthenticationMA.AlterneteActions({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "focusSkin": "sknBgE3E3E3Op20Border4A90E2",
                "height": "14%",
                "id": "AlterneteActionsEnterCVV",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_ed53609c73864a7187559ff06aed44c6,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "8.80%",
                "width": "85%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "14%",
                        "top": "8.80%",
                        "width": "85%"
                    },
                    "fontIconOption": {
                        "text": "x"
                    },
                    "imgOptionKA": {
                        "src": "active_cvv_icon.png"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.EnterCvvCodeInfo\")",
                        "left": "85dp",
                        "width": "61.90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            AlterneteActionsEnterCVV.onTouchStart = controller.AS_UWI_ed53609c73864a7187559ff06aed44c6;
            var OrLineForCVVandPIN = new com.InfinityOLB.AuthenticationMA.orline({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "30dp",
                "id": "OrLineForCVVandPIN",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5.28%",
                "width": "85%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "imgOr": {
                        "src": "or_circle.png"
                    },
                    "orline": {
                        "centerX": "50%",
                        "height": "30dp",
                        "top": "5.28%",
                        "width": "85%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var AlterneteActionsEnterPIN = new com.InfinityOLB.AuthenticationMA.AlterneteActions({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "focusSkin": "sknBgE3E3E3Op20Border4A90E2",
                "height": "14%",
                "id": "AlterneteActionsEnterPIN",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_d63f35e0cf744eaab601100605282f5d,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "5.28%",
                "width": "85%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "14%",
                        "top": "5.28%",
                        "width": "85%"
                    },
                    "fontIconOption": {
                        "text": "y"
                    },
                    "imgOptionKA": {
                        "src": "active_send_pin.png"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.SendPIN\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            AlterneteActionsEnterPIN.onTouchStart = controller.AS_UWI_d63f35e0cf744eaab601100605282f5d;
            flxResetPassBtns.add(AlterneteActionsEnterCVV, OrLineForCVVandPIN, AlterneteActionsEnterPIN);
            flxResetPasswordOptions.add(flxCloseResetPassword, lblResetYourPassword, flxResetContent, flxResetPassBtns);
            var flxSendOTP = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxSendOTP",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSendOTP.setDefaultUnit(kony.flex.DP);
            var resetusingOTP = new com.InfinityOLB.AuthenticationMA.resetusingOTP({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "resetusingOTP",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "btnUseCVV": {
                        "top": "6%"
                    },
                    "flxImgTxt": {
                        "width": "100%"
                    },
                    "flxResetBySecureCode": {
                        "clipBounds": true,
                        "top": "33dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "imgCVVOrOTP": {
                        "src": "send_pin.png"
                    },
                    "imgUser": {
                        "src": "default_username.png"
                    },
                    "imgUserOutline": {
                        "src": "user_reset_password_frame.png"
                    },
                    "imgViewCVV": {
                        "src": "view.png"
                    },
                    "lblResendOTPMsg": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.sendingOTP\")"
                    },
                    "lblResetPasswordMsg": {
                        "centerX": "viz.val_cleared",
                        "left": "80dp",
                        "top": "0dp",
                        "width": "70%"
                    },
                    "lblWrongOTP": {
                        "isVisible": false,
                        "left": "80dp"
                    },
                    "orline": {
                        "top": "6.5%"
                    },
                    "orline.imgOr": {
                        "src": "or_circle.png"
                    },
                    "resetusingOTP": {
                        "isVisible": true,
                        "left": "0dp",
                        "width": "100%"
                    },
                    "rtxEnterCVVCode": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.WantOTP\")",
                        "left": "50dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "tbxCVV": {
                        "height": "100%",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            resetusingOTP.btnNext.onClick = controller.AS_Button_je1a71e9e3a441829c006de52cf56f16;
            resetusingOTP.btnUseCVV.onClick = controller.AS_Button_b014ab53d3c6421cb0d39f83ae5e147f;
            var flxCloseSendOTP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseSendOTP",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseSendOTP.setDefaultUnit(kony.flex.DP);
            var imgCloseSendOTP = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseSendOTP",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseSendOTP.add(imgCloseSendOTP);
            flxSendOTP.add(resetusingOTP, flxCloseSendOTP);
            var flxResetUsingOTP = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxResetUsingOTP",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetUsingOTP.setDefaultUnit(kony.flex.DP);
            var resetusingOTPEnterOTP = new com.InfinityOLB.AuthenticationMA.resetusingOTP({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "resetusingOTPEnterOTP",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "flxCVV": {
                        "width": "68%"
                    },
                    "flxImageUser": {
                        "centerX": "viz.val_cleared",
                        "left": 0,
                        "top": "0%"
                    },
                    "flxImgTxt": {
                        "centerX": "50%",
                        "height": "130dp",
                        "width": "68%"
                    },
                    "flxResetBySecureCode": {
                        "height": "100dp",
                        "left": "78dp",
                        "top": "22dp",
                        "width": "80%"
                    },
                    "imgCVVOrOTP": {
                        "src": "send_pin.png"
                    },
                    "imgUser": {
                        "src": "default_username.png"
                    },
                    "imgUserOutline": {
                        "src": "user_reset_password_frame.png"
                    },
                    "imgViewCVV": {
                        "src": "view.png"
                    },
                    "lblResendOTPMsg": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.AskToResendOTPMsg\")"
                    },
                    "orline.imgOr": {
                        "src": "or_circle.png"
                    },
                    "rtxEnterCVVCode": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.EnterOTP\")"
                    },
                    "tbxCVV": {
                        "secureTextEntry": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            resetusingOTPEnterOTP.btnNext.onClick = controller.AS_Button_e674540514d44d46a690c2ba43e3d1bf;
            resetusingOTPEnterOTP.btnUseCVV.onClick = controller.AS_Button_bdb7d79246ab43e38d477d71090512cd;
            resetusingOTPEnterOTP.imgViewCVV.onTouchStart = controller.AS_Image_a77ff3d5f598477d96ba8a7a74a917ea;
            resetusingOTPEnterOTP.tbxCVV.onBeginEditing = controller.AS_TextField_j0019f86f656471d85690a0d9c52a0fe;
            resetusingOTPEnterOTP.tbxCVV.onKeyUp = controller.AS_TextField_g6943b93f48a40b4b3253ac5cc4bacc3;
            var flxCloseResetUsingOTP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseResetUsingOTP",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseResetUsingOTP.setDefaultUnit(kony.flex.DP);
            var imgCloseResetUsingOTP = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseResetUsingOTP",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseResetUsingOTP.add(imgCloseResetUsingOTP);
            flxResetUsingOTP.add(resetusingOTPEnterOTP, flxCloseResetUsingOTP);
            var flxResetUsingCVV = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxResetUsingCVV",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetUsingCVV.setDefaultUnit(kony.flex.DP);
            var ResetOrEnroll = new com.InfinityOLB.AuthenticationMA.ResetOrEnroll({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "568dp",
                "id": "ResetOrEnroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "ResetOrEnroll": {
                        "height": "568dp"
                    },
                    "flxCVV": {
                        "top": "21dp"
                    },
                    "flxResetEnrollCVV": {
                        "height": "120dp",
                        "top": "5.5%"
                    },
                    "imgCVV": {
                        "src": "cvv_icon.png"
                    },
                    "imgUser": {
                        "src": "default_username.png"
                    },
                    "imgUserOutline": {
                        "src": "user_reset_password_frame.png"
                    },
                    "imgViewCVV": {
                        "src": "view.png"
                    },
                    "lblResendOtp": {
                        "isVisible": false
                    },
                    "lblResetPassword": {
                        "text": "hg"
                    },
                    "lblWrongCvv": {
                        "text": "E"
                    },
                    "orline.imgOr": {
                        "src": "or_circle.png"
                    },
                    "rtxEnterCVV": {
                        "height": kony.flex.USE_PREFFERED_SIZE
                    },
                    "tbxCVV": {
                        "height": "100%",
                        "left": "0%",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            ResetOrEnroll.btnNext.onClick = controller.AS_Button_ec982f6c3e4d43dda32d288ea7cb89ea;
            ResetOrEnroll.btnUseOTP.onClick = controller.AS_Button_da99080919b041c4ac365b2690a28094;
            ResetOrEnroll.lstbxCards.onTouchStart = controller.AS_ListBox_c790c4d06bea4977bc373f4d4d1d535c;
            ResetOrEnroll.tbxCVV.onBeginEditing = controller.AS_TextField_c2d9de5f0b544570a165739090cb744c;
            ResetOrEnroll.tbxCVV.onKeyUp = controller.AS_TextField_e1039fff3fb44a11822e0ea10aa5484e;
            var flxCloseResetUsingCVV = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseResetUsingCVV",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseResetUsingCVV.setDefaultUnit(kony.flex.DP);
            var imgCloseResetUsingCVV = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseResetUsingCVV",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseResetUsingCVV.add(imgCloseResetUsingCVV);
            flxResetUsingCVV.add(ResetOrEnroll, flxCloseResetUsingCVV);
            var flxSelectUsername = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxSelectUsername",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectUsername.setDefaultUnit(kony.flex.DP);
            var flxCloseSelectUsername = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseSelectUsername",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseSelectUsername.setDefaultUnit(kony.flex.DP);
            var imgCloseSelectUsername = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseSelectUsername",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseSelectUsername.add(imgCloseSelectUsername);
            var lblWelcomeBack = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "id": "lblWelcomeBack",
                "isVisible": true,
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.WelcomeBackLabel\")",
                "top": "3.52%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUsername = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxUsername",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "80dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "80%",
                "zIndex": 5,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUsername.setDefaultUnit(kony.flex.DP);
            var lblUsername = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblUsername",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.UserName\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxUsername.add(lblUsername);
            var lstBoxSelectUsername = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblUsername",
                        "aria-required": true
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lstBoxSelectUsername",
                "isVisible": true,
                "left": "80dp",
                "masterData": [
                    ["lb1", "John.Bailey"]
                ],
                "skin": "sknlbxalto33333315pxBordere3e3e32pxRadius",
                "top": "10dp",
                "width": "69%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var flxSelectSignInOrResetPassword = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSelectSignInOrResetPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "67dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectSignInOrResetPassword.setDefaultUnit(kony.flex.DP);
            var SignInAs = new com.InfinityOLB.AuthenticationMA.AlterneteActions({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "focusSkin": "sknBgE3E3E3Op20Border4A90E2",
                "height": "14%",
                "id": "SignInAs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_c75fce5205ea4c54b77c8800515b5267,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "8.80%",
                "width": "85%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "14%",
                        "top": "8.80%"
                    },
                    "fontIconOption": {
                        "centerY": "50%",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "left": "0dp",
                        "text": "L",
                        "top": "viz.val_cleared",
                        "width": "100%"
                    },
                    "imgOptionKA": {
                        "src": "active_cvv_icon.png"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.EnterCvvCodeInfo\")",
                        "left": "85dp",
                        "width": "61.90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "hoverSkin": "sknBGFFFFFBdrE3E3E3BdrRadius2PxHover",
                "overrides": {}
            });
            SignInAs.onTouchStart = controller.AS_UWI_cad98eb1a8304f689ee3b40cfa08351f;
            var OrLineForSelectUsername = new com.InfinityOLB.AuthenticationMA.orline({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "30dp",
                "id": "OrLineForSelectUsername",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5.28%",
                "width": "85%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "imgOr": {
                        "src": "or_circle.png"
                    },
                    "orline": {
                        "centerX": "50%",
                        "height": "30dp",
                        "top": "5.28%",
                        "width": "85%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var ResetMyPassword = new com.InfinityOLB.AuthenticationMA.AlterneteActions({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "focusSkin": "sknBgE3E3E3Op20Border4A90E2",
                "height": "14%",
                "id": "ResetMyPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_h3cca751c81e47ef96559d0df9dceeb9,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "5.28%",
                "width": "85%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "14%",
                        "top": "5.28%",
                        "width": "85%"
                    },
                    "fontIconOption": {
                        "centerY": "50%",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "text": "r",
                        "top": "viz.val_cleared",
                        "width": "100%"
                    },
                    "imgOptionKA": {
                        "src": "active_send_pin.png"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.SendPIN\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "hoverSkin": "sknBGFFFFFBdrE3E3E3BdrRadius2PxHover",
                "overrides": {}
            });
            ResetMyPassword.onTouchStart = controller.AS_UWI_c13e044fb512427b8ea7503d5078016c;
            flxSelectSignInOrResetPassword.add(SignInAs, OrLineForSelectUsername, ResetMyPassword);
            flxSelectUsername.add(flxCloseSelectUsername, lblWelcomeBack, flxUsername, lstBoxSelectUsername, flxSelectSignInOrResetPassword);
            var flxResetPassword = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxResetPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "-1dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetPassword.setDefaultUnit(kony.flex.DP);
            var newpasswordsetting = new com.InfinityOLB.AuthenticationMA.newpasswordsetting({
                "height": "100%",
                "id": "newpasswordsetting",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "btnNext": {
                        "width": "68%"
                    },
                    "flxMain": {
                        "height": "610dp"
                    },
                    "flxMatchPassword": {
                        "width": "68%"
                    },
                    "flxNewPassword": {
                        "width": "68%"
                    },
                    "flxRulesPassword": {
                        "centerX": "50%",
                        "isVisible": false,
                        "width": "68%"
                    },
                    "imgPasswordMatched": {
                        "src": "success_icon.png"
                    },
                    "imgRules": {
                        "src": "info.png"
                    },
                    "imgUser": {
                        "src": "default_username.png"
                    },
                    "imgUserOutline": {
                        "src": "user_reset_password_frame.png"
                    },
                    "imgValidPassword": {
                        "src": "success_icon.png"
                    },
                    "rtxRulesPassword": {
                        "height": kony.flex.USE_PREFFERED_SIZE
                    },
                    "tbxNewPassword": {
                        "secureTextEntry": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            newpasswordsetting.btnNext.onClick = controller.AS_Button_g8926370565949d99200dc018568c10c;
            var flxCloseResetPswd = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseResetPswd",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseResetPswd.setDefaultUnit(kony.flex.DP);
            var imgCloseResetPswd = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseResetPswd",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "icon_close_grey.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseResetPswd.add(imgCloseResetPswd);
            flxResetPassword.add(newpasswordsetting, flxCloseResetPswd);
            var flxLoginMFA = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxLoginMFA",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "110dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginMFA.setDefaultUnit(kony.flex.DP);
            var MFAFlow = new com.InfinityOLB.AuthenticationMA.MFAFlow({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "550dp",
                "id": "MFAFlow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Px",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "MFAFlow": {
                        "height": "550dp",
                        "isVisible": true
                    },
                    "btnProceed": {
                        "top": "30dp"
                    },
                    "flxCheckboxPhone": {
                        "top": "10dp"
                    },
                    "flxRegisteredPhone": {
                        "width": "100%"
                    },
                    "imgCheckboxEmailId": {
                        "src": "checked_box.png"
                    },
                    "imgCheckboxPhone": {
                        "src": "checked_box.png"
                    },
                    "imgNewBrowserDetection": {
                        "src": "mfa_new_brower_detection.png"
                    },
                    "lblCloseBracePhone": {
                        "top": -6
                    },
                    "lblNewBrowserDetection": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginMFA.WeHaveDetectedaNewDevice\")"
                    },
                    "lblOpenBracePhone": {
                        "top": -7
                    },
                    "lblRegisteredEmailId": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginMFA.Email\")"
                    },
                    "lblRegisteredPhone": {
                        "top": 7
                    },
                    "lblRegisteredPhoneNo": {
                        "top": 8
                    },
                    "lblSentYouSecureAccessCode": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginMFA.WeHaveSentYouTheSecureAccessCodeToYourEmailOrPhone\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var MFA = new com.InfinityOLB.AuthenticationMA.MFA({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "568dp",
                "id": "MFA",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Px",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "MFA": {
                        "isVisible": false
                    },
                    "imgNeweBrowserDetection": {
                        "src": "mfa_new_brower_detection.png"
                    },
                    "imgViewSACCode": {
                        "src": "view.png"
                    },
                    "lblNeweBrowserDetection": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginMFA.WeHaveDetectedaNewDevice\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLoginMFA.add(MFAFlow, MFA);
            var flxResetSuccessful = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "398dp",
                "id": "flxResetSuccessful",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "180dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetSuccessful.setDefaultUnit(kony.flex.DP);
            var passwordresetsuccess = new com.InfinityOLB.AuthenticationMA.passwordresetsuccess({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "550dp",
                "id": "passwordresetsuccess",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "imgTickFrame": {
                        "src": "user_verify_success_frame.png"
                    },
                    "imgUserwithoutTick": {
                        "src": "default_username.png"
                    },
                    "lblReserSuccessMsg": {
                        "width": "75%"
                    },
                    "orlineSuccess.imgOr": {
                        "src": "or_circle.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            passwordresetsuccess.btnLoginLater.onClick = controller.AS_Button_ie4688df9bed49909277fa74cc9a8cce;
            passwordresetsuccess.btnProceed.onClick = controller.AS_Button_ea17702b24d74d10b184d18ad2c0577a;
            var flxCloseResetSuccessful = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseResetSuccessful",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseResetSuccessful.setDefaultUnit(kony.flex.DP);
            var imgCloseResetSuccessful = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "height": "100%",
                "id": "imgCloseResetSuccessful",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseResetSuccessful.add(imgCloseResetSuccessful);
            flxResetSuccessful.add(passwordresetsuccess, flxCloseResetSuccessful);
            var flxBlocked = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxBlocked",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "53%",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBlocked.setDefaultUnit(kony.flex.DP);
            var blocked = new com.InfinityOLB.AuthenticationMA.blocked({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "568dp",
                "id": "blocked",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "imgTakeHelpTime": {
                        "src": "help_large.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            blocked.btnProceed.onClick = controller.AS_Button_c3f3b614ef974d01822ba57f93ce1714;
            var flxCloseBlocked = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseBlocked",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseBlocked.setDefaultUnit(kony.flex.DP);
            var imgCloseBlocked = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseBlocked",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseBlocked.add(imgCloseBlocked);
            flxBlocked.add(blocked, flxCloseBlocked);
            var flxEnrollOrServerError = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "451dp",
                "id": "flxEnrollOrServerError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "147dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnrollOrServerError.setDefaultUnit(kony.flex.DP);
            var EnrollAlert = new com.InfinityOLB.AuthenticationMA.EnrollAlert({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "400dp",
                "id": "EnrollAlert",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "btnBackToLogin": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.backToLoginCaps\")"
                    },
                    "imgEnroll": {
                        "src": "server_error.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            EnrollAlert.btnBackToLogin.onClick = controller.AS_Button_hb4e02e809db4e1bae0ba4b9556b99ea;
            EnrollAlert.btnEnroll.onClick = controller.AS_Button_e5560a494d924458bc9240c27758a826;
            EnrollAlert.lblHowToEnroll.onTouchStart = controller.AS_Label_hbeccaed576f4fe2b9a931795bd748aa;
            flxEnrollOrServerError.add(EnrollAlert);
            var flxEnroll = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxEnroll",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "500dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnroll.setDefaultUnit(kony.flex.DP);
            var EnrollPromptScreen = new com.InfinityOLB.AuthenticationMA.EnrollAlert({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "EnrollPromptScreen",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "EnrollAlert": {
                        "height": "100%"
                    },
                    "btnBackToLogin": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.HowToEnroll\")",
                        "zIndex": 1
                    },
                    "btnEnroll": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.EnrollLabel\")"
                    },
                    "imgEnroll": {
                        "src": "server_error.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCloseEnroll = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseEnroll",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseEnroll.setDefaultUnit(kony.flex.DP);
            var imgCloseEnroll = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseEnroll",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseEnroll.add(imgCloseEnroll);
            flxEnroll.add(EnrollPromptScreen, flxCloseEnroll);
            var flxLogoutMsg = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100dp",
                "id": "flxLogoutMsg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogoutMsg.setDefaultUnit(kony.flex.DP);
            var logOutMsg = new com.InfinityOLB.AuthenticationMA.logOutMsg({
                "height": "100%",
                "id": "logOutMsg",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActionsLoginNow": {
                        "left": "87dp",
                        "top": "430dp"
                    },
                    "AlterneteActionsLoginNow.fontIconOption": {
                        "text": "V"
                    },
                    "AlterneteActionsLoginNow.imgOptionKA": {
                        "src": "login_signin.png"
                    },
                    "AlterneteActionsLoginNow.imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "AlterneteActionsLoginNow.rtxCVV": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.loginNow\")"
                    },
                    "imgLogoutSuccess": {
                        "centerY": "30.560000000000002%",
                        "height": "32dp",
                        "src": "success_green.png",
                        "width": "32dp"
                    },
                    "lblLoggedOut": {
                        "centerY": "30.560000000000002%",
                        "left": "100dp",
                        "width": "65%"
                    },
                    "lblSuccessIcon": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.LogOutSuccess\")",
                        "left": "87dp",
                        "top": "234dp",
                        "width": "70%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogoutMsg.add(logOutMsg);
            var flxPhoneAndEmail = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxPhoneAndEmail",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "1dp",
                "width": "500dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneAndEmail.setDefaultUnit(kony.flex.DP);
            var OTPModule = new com.InfinityOLB.Resources.mfaold.OTPModule({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "OTPModule",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxAgree": {
                        "isVisible": false
                    },
                    "flxCVV": {
                        "width": "350dp"
                    },
                    "flxDescription": {
                        "centerX": "viz.val_cleared"
                    },
                    "flxImgTxt": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "flxRememberMe": {
                        "isVisible": false
                    },
                    "flximgrtx": {
                        "centerX": "53%",
                        "height": "120dp",
                        "left": "80dp",
                        "top": "140dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "imgPhoneOTP": {
                        "src": "send_pin.png"
                    },
                    "imgRememberMe": {
                        "src": "unchecked_box.png"
                    },
                    "lblOTP": {
                        "centerX": "viz.val_cleared",
                        "height": "66dp"
                    },
                    "lblPhoneOTP": {
                        "centerX": "viz.val_cleared"
                    },
                    "lblResendOTPMessage": {
                        "bottom": "0%",
                        "isVisible": true,
                        "text": "If you have not recieved the secure access code on your phone, please use the resend option.",
                        "top": "viz.val_cleared",
                        "width": "90%"
                    },
                    "lblWrongOTP": {
                        "text": "Sorry, this secure code is incorrect. Try again."
                    },
                    "rtxEnterCVVCode": {
                        "centerX": "54%",
                        "centerY": "30%"
                    },
                    "tbxCVV": {
                        "centerY": "53%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCloseMFA = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close "
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseMFA",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseMFA.setDefaultUnit(kony.flex.DP);
            var imgCloseMFA = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseMFA",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseMFA.add(imgCloseMFA);
            flxPhoneAndEmail.add(OTPModule, flxCloseMFA);
            var flxEnrollActivateContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxEnrollActivateContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnrollActivateContainer.setDefaultUnit(kony.flex.DP);
            var flxContent = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxSelectOption = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSelectOption",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "67dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectOption.setDefaultUnit(kony.flex.DP);
            var lblSelectOption = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "centerX": "50%",
                "id": "lblSelectOption",
                "isVisible": true,
                "left": 75,
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginEnrollActivate.PleaseSelectAnOption\")",
                "top": "150dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var EnrollNow = new com.InfinityOLB.AuthenticationMA.AlterneteActionsWithInfo({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "EnrollNow",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActionsWithInfo": {
                        "isVisible": false,
                        "top": 0
                    },
                    "fontIconOption": {
                        "centerY": "viz.val_cleared"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "lblInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.enrollNowHelpText\")",
                        "top": "5dp"
                    },
                    "lblName": {
                        "text": "Label"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var lblSeperator = new com.InfinityOLB.AuthenticationMA.orline({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "35dp",
                "id": "lblSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "70%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "imgOr": {
                        "src": "or_circle.png"
                    },
                    "orline": {
                        "centerX": "50%",
                        "isVisible": true,
                        "top": "20dp",
                        "width": "70%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var ActivateNow = new com.InfinityOLB.AuthenticationMA.AlterneteActionsWithInfo({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "ActivateNow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActionsWithInfo": {
                        "top": 0
                    },
                    "flxInfoContent": {
                        "clipBounds": false
                    },
                    "fontIconOption": {
                        "centerY": "viz.val_cleared",
                        "text": "c"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "lblInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.activateNowHelpText\")",
                        "top": "0dp"
                    },
                    "lblName": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.ActivateYourProfile\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSelectOption.add(lblSelectOption, EnrollNow, lblSeperator, ActivateNow);
            flxContent.add(flxSelectOption);
            var flxActivateProfile = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxActivateProfile",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivateProfile.setDefaultUnit(kony.flex.DP);
            var enrollActivateComponent = new com.InfinityOLB.AuthenticationMA.activateNow({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "id": "enrollActivateComponent",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "viewType": "enrollActivateComponent",
                "overrides": {
                    "activateNow": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var enrollActivateComponent_data = (appConfig.componentMetadata && appConfig.componentMetadata["AuthenticationMA"] && appConfig.componentMetadata["AuthenticationMA"]["frmLogin"] && appConfig.componentMetadata["AuthenticationMA"]["frmLogin"]["enrollActivateComponent"]) || {};
            enrollActivateComponent.primaryBtnEnableSkin = enrollActivateComponent_data.primaryBtnEnableSkin || "{\"normal\":\"sknBtnNormalSSPFFFFFF15Px\", \"hoverSkin\":\"sknBtnNormalSSPFFFFFFHover15Px\", \"focusSkin\":\"sknBtnNormalSSPFFFFFF15PxFocus\"}";
            enrollActivateComponent.tickFontIcon = enrollActivateComponent_data.tickFontIcon || "N";
            enrollActivateComponent.objectName = enrollActivateComponent_data.objectName || "ExternalUserManagement";
            enrollActivateComponent.setPasswordErrorMessage = enrollActivateComponent_data.setPasswordErrorMessage || "Unable to set password.Please try again.";
            enrollActivateComponent.primaryBtnDisableSkin = enrollActivateComponent_data.primaryBtnDisableSkin || "{\"normal\":\"sknBtnBlockedSSP0273e315px\", \"hoverSkin\":\"sknBtnBlockedSSP0273e315px\", \"focusSkin\":\"sknBtnBlockedSSP0273e315px\"}";
            enrollActivateComponent.exclamationFontIcon = enrollActivateComponent_data.exclamationFontIcon || "K";
            enrollActivateComponent.objectService = enrollActivateComponent_data.objectService || "ExternalUsers_2";
            enrollActivateComponent.expiredActivationCode = enrollActivateComponent_data.expiredActivationCode || "Your activation code has expired. Please select “Can’t Sign In” to regenerate a new activation code";
            enrollActivateComponent.textBoxSkins = enrollActivateComponent_data.textBoxSkins || "{\"normalSkin\":\"sknBorderE3E3E3\", \"focusSkin\":\"sknFlxBorder4A90E23px\", \"errorSkin\":\"sknborderff0000error\"}";
            enrollActivateComponent.activationCodeValidationOperation = enrollActivateComponent_data.activationCodeValidationOperation || "validateActivationCodeForEnrollment";
            enrollActivateComponent.activationCodeBlock = enrollActivateComponent_data.activationCodeBlock || "Your activation code is blocked. Please select “Can’t Sign In” to regenerate a new activation code";
            enrollActivateComponent.successIconSkin = enrollActivateComponent_data.successIconSkin || "sknFontIcon2a9e07Bgffffont18pxOlbFontIcon";
            enrollActivateComponent.setPasswordOperation = enrollActivateComponent_data.setPasswordOperation || "UpdatePasswordForActivationFlow";
            enrollActivateComponent.warningIconSkin = enrollActivateComponent_data.warningIconSkin || "sknFontIconffa909Bgffffont18pxOlbFontIcon";
            enrollActivateComponent.passwordRulesAndPoliciesOperation = enrollActivateComponent_data.passwordRulesAndPoliciesOperation || "getPasswordRules";
            flxActivateProfile.add(enrollActivateComponent);
            var flxCloseEnrollActivate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close and go back to login"
                },
                "bottom": "0dp",
                "clipBounds": true,
                "height": "25dp",
                "id": "flxCloseEnrollActivate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseEnrollActivate.setDefaultUnit(kony.flex.DP);
            var lblCloseEnrollActivate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "lblCloseEnrollActivate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseEnrollActivate.add(lblCloseEnrollActivate);
            flxEnrollActivateContainer.add(flxContent, flxActivateProfile, flxCloseEnrollActivate);
            var flxBeyondBankingContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeyondBankingContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "670dp",
                "isModalContainer": false,
                "top": "130dp",
                "width": "45.57%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeyondBankingContent.setDefaultUnit(kony.flex.DP);
            var flxBeyondBanking = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeyondBanking",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "80%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeyondBanking.setDefaultUnit(kony.flex.DP);
            var lblBeyondBanking = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblBeyondBanking",
                "isVisible": true,
                "left": "595dp",
                "skin": "sknSSPLblFFFFFF58px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.WelcomeMsg\")",
                "top": "250dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBeyondBanking.add(lblBeyondBanking);
            var flxBeyondBankingDesc = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeyondBankingDesc",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeyondBankingDesc.setDefaultUnit(kony.flex.DP);
            var lblBeyondBankingDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblBeyondBankingDesc",
                "isVisible": true,
                "left": "594dp",
                "skin": "sknSSPLblFFFFFF24px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.WelcomeSubMsg\")",
                "top": "5dp",
                "width": "90%",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBeyondBankingDesc.add(lblBeyondBankingDesc);
            flxBeyondBankingContent.add(flxBeyondBanking, flxBeyondBankingDesc);
            var btnVeiwMore = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Learn More",
                    "allyARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknbtn0a78d1viewmoreFocus",
                "height": "40dp",
                "id": "btnVeiwMore",
                "isVisible": true,
                "left": "595dp",
                "skin": "sknbtn0273e3Viewmore",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.viewMore\")",
                "top": "344dp",
                "width": "130dp",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFooterMenu = new kony.ui.FlexContainer({
                "bottom": "70dp",
                "clipBounds": false,
                "height": "25dp",
                "id": "flxFooterMenu",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "700dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "84%",
                "width": "148dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterMenu.setDefaultUnit(kony.flex.DP);
            var flxFooterContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxFooterContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterContainer.setDefaultUnit(kony.flex.DP);
            var btnLocateUs = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnLocateUs",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var flxVBar1 = new kony.ui.FlexContainer({
                "centerY": "55%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar1.setDefaultUnit(kony.flex.DP);
            flxVBar1.add();
            var btnContactUs = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnContactUs",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var flxVBar2 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar2.setDefaultUnit(kony.flex.DP);
            flxVBar2.add();
            var btnPrivacy = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknSSPBtnFFFFFF13px",
                "id": "btnPrivacy",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.privacy\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknSSPBtnFFFFFF13px"
            });
            var flxVBar3 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 35,
                "isModalContainer": false,
                "right": 1,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar3.setDefaultUnit(kony.flex.DP);
            flxVBar3.add();
            var btnTermsAndConditions = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknSSPBtnFFFFFF13px",
                "id": "btnTermsAndConditions",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknSSPBtnFFFFFF13px"
            });
            var flxVBar4 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar4.setDefaultUnit(kony.flex.DP);
            flxVBar4.add();
            var btnFaqs = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknSSPBtnFFFFFF13px",
                "id": "btnFaqs",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.faqs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknSSPBtnFFFFFF13px"
            });
            flxFooterContainer.add(btnLocateUs, flxVBar1, btnContactUs, flxVBar2, btnPrivacy, flxVBar3, btnTermsAndConditions, flxVBar4, btnFaqs);
            flxFooterMenu.add(flxFooterContainer);
            var flxCopyRight = new kony.ui.FlexContainer({
                "bottom": "20dp",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxCopyRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "590dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "zIndex": 50,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCopyRight.setDefaultUnit(kony.flex.DP);
            var imgTemenos = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Temenos Logo"
                },
                "centerX": "14%",
                "height": "18dp",
                "id": "imgTemenos",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "0dp",
                "skin": "slImage",
                "src": "temenos_logo_white.png",
                "top": "0%",
                "width": "50px",
                "zIndex": 6
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCopyright = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCopyright",
                "isVisible": true,
                "left": "150dp",
                "skin": "sknLblSSPNormalB5D7F412px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyright\")",
                "top": "1px",
                "width": "58.02%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCopyRight.add(imgTemenos, lblCopyright);
            var lblCopyrightTab1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCopyrightTab1",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknSSPLblFFFFFF12px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab1\")",
                "top": "505dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCopyrightTab2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCopyrightTab2",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknSSPLblB6D7F212Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab2\")",
                "top": "505dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnUseMobileApp = new kony.ui.Button({
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "btnUseMobileApp",
                "isVisible": true,
                "left": "83dp",
                "skin": "sknBtnSecondarySSPsknBtnSecondarySSP0273e315Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.DownloadApp\")",
                "top": "553dp",
                "width": "260dp",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseFontIconParent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "45dp",
                "id": "flxCloseFontIconParent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "456dp",
                "isModalContainer": false,
                "right": "16%",
                "skin": "slFbox",
                "top": "59dp",
                "width": "45dp",
                "zIndex": 20,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseFontIconParent.setDefaultUnit(kony.flex.DP);
            var flxCloseFontIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "25dp",
                "id": "flxCloseFontIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseFontIcon.setDefaultUnit(kony.flex.DP);
            var lblCloseFontIconCommon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "lblCloseFontIconCommon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseFontIcon.add(lblCloseFontIconCommon);
            flxCloseFontIconParent.add(flxCloseFontIcon);
            var flxAppLogo = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "65dp",
                "id": "flxAppLogo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50dp",
                "isModalContainer": false,
                "top": "5%",
                "width": "370dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAppLogo.setDefaultUnit(kony.flex.DP);
            var imgAppLogo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Login Kony Logo"
                },
                "centerX": "14%",
                "height": "64dp",
                "id": "imgAppLogo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "7.50%",
                "skin": "slImage",
                "src": "digital_banking.png",
                "top": "13dp",
                "width": "148dp",
                "zIndex": 6
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAppLogo.add(imgAppLogo);
            var flxTNCEntity = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxTNCEntity",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTNCEntity.setDefaultUnit(kony.flex.DP);
            var TermsAndConditionLegalEntity = new com.InfinityOLB.Resources.TermsAndConditionLegalEntity({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "id": "TermsAndConditionLegalEntity",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "width": "50%",
                "appName": "ResourcesMA",
                "overrides": {
                    "TermsAndConditionBody": {
                        "left": "0dp"
                    },
                    "TermsAndConditionLegalEntity": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerX": "50%",
                        "centerY": "50%",
                        "isVisible": true,
                        "left": "0dp",
                        "top": "viz.val_cleared",
                        "width": "50%"
                    },
                    "btnAcceptTAndC": {
                        "width": "30%"
                    },
                    "btnCancelTAndC": {
                        "bottom": "0",
                        "right": "200dp",
                        "top": "viz.val_cleared",
                        "width": "30%"
                    },
                    "flxLegalEntityBtn": {
                        "left": "0",
                        "top": "10dp"
                    },
                    "flxTermsAndConditionDetails": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "0dp",
                        "top": "50dp"
                    },
                    "flxTermsAndCondtionBody": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "top": "0dp",
                        "width": "94%"
                    },
                    "imgCloseTC": {
                        "src": "blue_close_icon.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTNCEntity.add(TermsAndConditionLegalEntity);
            flxMain.add(flxImgKony, flxDropdown, flxLanguagePicker, flxLogin, flxLegalEntity, flxLoginSelectedUsername, flxVerification, flxWelcomeBack, flxResetPasswordOptions, flxSendOTP, flxResetUsingOTP, flxResetUsingCVV, flxSelectUsername, flxResetPassword, flxLoginMFA, flxResetSuccessful, flxBlocked, flxEnrollOrServerError, flxEnroll, flxLogoutMsg, flxPhoneAndEmail, flxEnrollActivateContainer, flxBeyondBankingContent, btnVeiwMore, flxFooterMenu, flxCopyRight, lblCopyrightTab1, lblCopyrightTab2, btnUseMobileApp, flxCloseFontIconParent, flxAppLogo, flxTNCEntity);
            var flxLoading = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxLoadingChangeLanguage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoadingChangeLanguage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingChangeLanguage.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapperChangeLang = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapperChangeLang",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapperChangeLang.setDefaultUnit(kony.flex.DP);
            var flxImageContainerChangeLang = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainerChangeLang",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainerChangeLang.setDefaultUnit(kony.flex.DP);
            var imgLoadingChangeLang = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoadingChangeLang",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainerChangeLang.add(imgLoadingChangeLang);
            flxLoadingWrapperChangeLang.add(flxImageContainerChangeLang);
            var lblChangeLang = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblChangeLang",
                "isVisible": true,
                "left": "670dp",
                "skin": "sknLabelSSPffffff13",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.lblChangeLang\")",
                "top": "421dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1000
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingChangeLanguage.add(flxLoadingWrapperChangeLang, lblChangeLang);
            var flxFeedbackTakeSurvey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxFeedbackTakeSurvey",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackTakeSurvey.setDefaultUnit(kony.flex.DP);
            var CustomFeedbackPopup = new com.InfinityOLB.SelfServiceEnrolmentMA.CustomFeedbackPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "260px",
                "id": "CustomFeedbackPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "width": "60%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "CustomFeedbackPopup": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "top": "viz.val_cleared",
                        "width": "60%"
                    },
                    "btnNo": {
                        "width": "40%"
                    },
                    "btnYes": {
                        "width": "40%"
                    },
                    "lblPopupMessage": {
                        "width": "90%"
                    },
                    "lblPopupmsg": {
                        "width": "90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CustomFeedbackPopup.btnNo.onClick = controller.AS_Button_ja24bde46bf44018b58917cff76e85aa;
            CustomFeedbackPopup.btnYes.onClick = controller.AS_Button_f30ad6790c514d8b9e3a3b6642ab8841;
            flxFeedbackTakeSurvey.add(CustomFeedbackPopup);
            var flxChangeLanguage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxChangeLanguage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChangeLanguage.setDefaultUnit(kony.flex.DP);
            var CustomChangeLanguagePopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomChangeLanguagePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "70%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "70%",
                        "zIndex": 1100
                    },
                    "btnYes": {
                        "isVisible": true,
                        "left": "viz.val_cleared"
                    },
                    "lblHeading": {
                        "text": "Language"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.changeLanguagePopup\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxChangeLanguage.add(CustomChangeLanguagePopup);
            var BrowserCheckPopup = new com.InfinityOLB.AuthenticationMA.BrowserCheckPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "BrowserCheckPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA",
                "overrides": {
                    "BrowserCheckPopup": {
                        "isVisible": false,
                        "left": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxDiffLanguage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDiffLanguage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiffLanguage.setDefaultUnit(kony.flex.DP);
            var DiffLanguagePopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "DiffLanguagePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "70%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "70%",
                        "zIndex": 1100
                    },
                    "btnYes": {
                        "isVisible": true,
                        "left": "viz.val_cleared"
                    },
                    "lblHeading": {
                        "text": "Language"
                    },
                    "lblPopupMessage": {
                        "text": "Are you sure you want to change the language?"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDiffLanguage.add(DiffLanguagePopup);
            var flxBG = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxBG",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBG.setDefaultUnit(kony.flex.DP);
            var flxLoginBG = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxLoginBG",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginBG.setDefaultUnit(kony.flex.DP);
            var imgLoginBg = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgLoginBg",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "loginbackground.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImg = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxImg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknLoginflxGradient",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImg.setDefaultUnit(kony.flex.DP);
            flxImg.add();
            flxLoginBG.add(imgLoginBg, flxImg);
            flxBG.add(flxLoginBG);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1400,
                "640": {
                    "frmLogin": {
                        "segmentProps": []
                    },
                    "tbxAutopopulateIssueFix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "height": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "13.88%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94dp"
                        },
                        "segmentProps": []
                    },
                    "imgKony": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "94dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "13.88%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "lblCheckBox": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "skn0273e315pxolbfonticons",
                        "segmentProps": []
                    },
                    "lblLanguage": {
                        "skin": "sknLabelSSP0273e315px",
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "right": {
                            "type": "string",
                            "value": "61dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "flxDifferentLanguagesSegment": {
                        "skin": "sknflxShdwLangPopMB696969",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxLogin": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFFFFFFnoshadow",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxLoginComponentContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxCloseIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "closeicon.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "loginComponent": {
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "rtxInfo": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "text": "If you forgot Temporary Password or Missed Temporary Password or want to reset temporary password”, click “Cant' sign-in” option to Reset password.",
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxNewNEnroll": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms1": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms1"
                    },
                    "carousel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "carousel"
                    },
                    "flxAppStore": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgAppstore": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "appstore_2x.png",
                        "segmentProps": []
                    },
                    "flxPlayStore": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgPlayStore": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "google_play_2x.png",
                        "segmentProps": []
                    },
                    "OTPComponent": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "cantSignIn": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "cantSignIn"
                    },
                    "regenrateActivationCodeComponent": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "resetPasswordComponent": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLegalEntity": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxOuter": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "segmentProps": []
                    },
                    "flxLegalEntitySelect1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "94"
                        },
                        "segmentProps": []
                    },
                    "lblPleaseSelectEntity": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "skin": "sknLabelSSP42424217px",
                        "segmentProps": []
                    },
                    "flxLegalEntityMain": {
                        "left": {
                            "type": "number",
                            "value": "25"
                        },
                        "top": {
                            "type": "number",
                            "value": "150"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectEntity": {
                        "skin": "sknLblSSP72727215px",
                        "segmentProps": []
                    },
                    "flxLegalEntityDropDown": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknFlxLegalEntity",
                        "top": {
                            "type": "number",
                            "value": "30"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectLegalEntity": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "skin": "slLabel0fb44c6072cea44",
                        "text": "Select",
                        "segmentProps": []
                    },
                    "imgdropdownExpand": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "25px"
                        },
                        "left": {
                            "type": "string",
                            "value": "90%"
                        },
                        "src": "listboxarw.png",
                        "width": {
                            "type": "string",
                            "value": "25px"
                        },
                        "segmentProps": []
                    },
                    "flxLegalEntityCombine": {
                        "segmentProps": []
                    },
                    "flxLegalSearch": {
                        "segmentProps": []
                    },
                    "txtLegalSearch": {
                        "skin": "tbxPlaceholder",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "imgSearch": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "left": {
                            "type": "string",
                            "value": "90%"
                        },
                        "src": "selecetd_search.png",
                        "top": {
                            "type": "string",
                            "value": "8px"
                        },
                        "width": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxLegalDropdown": {
                        "left": {
                            "type": "number",
                            "value": "2"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "lblLegalEntityHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slLabel0fb44c6072cea44",
                        "text": "LEGAL ENTITY",
                        "segmentProps": []
                    },
                    "segLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "data": [{
                            "lblLegalEntityList": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "India"
                            }
                        }, {
                            "lblLegalEntityList": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "USA"
                            }
                        }],
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AuthenticationMA",
                            "friendlyName": "flxsegList"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxsegList": "flxsegList",
                            "lblLegalEntityList": "lblLegalEntityList"
                        },
                        "zIndex": 10,
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AuthenticationMA"
                    },
                    "flxRemember": {
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "btnLegalEntity": {
                        "top": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLoginSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnForgotPassword": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnOnlineAccessEnroll": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnOpenNewAccount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flexcheckuncheck": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "90%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "15%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxLoginUser": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "MainLogin.flxNewNEnroll": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxRememberMe": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxUserName": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.imgViewPassword": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.lblRememberMe": {
                        "maxWidth": {
                            "type": "string",
                            "value": "85%"
                        },
                        "text": "Remember me",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "MainLogin.lblWelcome": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "MainLogin.lblWelcomeMobile": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.rtxErrorMsg": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.rtxErrorMsgUser": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "lblWelcomeBackSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxUserContentSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImageSelectUsername": {
                        "top": {
                            "type": "string",
                            "value": "1.2800000000000002%"
                        },
                        "segmentProps": []
                    },
                    "lblYourSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "skin": "s1479fa717444db6b49648e6b8b80f1a",
                        "top": {
                            "type": "string",
                            "value": "44.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP42424230Px",
                        "top": {
                            "type": "string",
                            "value": "56.5%"
                        },
                        "segmentProps": []
                    },
                    "flxVerification": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "letsverify": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "letsverify"
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "164dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "346dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "42.28%"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "AllForms.flxInformationText": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "AllForms.imgToolTip": {
                        "left": {
                            "type": "string",
                            "value": "11%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgClose": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "LblVerifiedUserWelcome": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxUserContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImage": {
                        "top": {
                            "type": "string",
                            "value": "1.2800000000000002%"
                        },
                        "segmentProps": []
                    },
                    "lblYourUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "skin": "s1479fa717444db6b49648e6b8b80f1a",
                        "top": {
                            "type": "string",
                            "value": "44.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP42424230Px",
                        "top": {
                            "type": "string",
                            "value": "56.5%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBackBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1.5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsSignIn"
                    },
                    "AlterneteActionsSignIn.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn.imgOptionKA": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn.imgRightTip": {
                        "left": {
                            "type": "string",
                            "value": "-2px"
                        },
                        "segmentProps": []
                    },
                    "orlineWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "orlineWelcomeBack"
                    },
                    "AlterneteActionsResetPassword": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "72%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsResetPassword"
                    },
                    "AlterneteActionsResetPassword.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsResetPassword.imgRightTip": {
                        "height": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "-2px"
                        },
                        "width": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetPasswordOptions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseResetPassword": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "lblResetYourPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "56dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetUserImg": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgUserReset": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "segmentProps": []
                    },
                    "imgUserBoundary": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lvlVerificationNotice": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxResetPassBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0.8000000000000007%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterCVV"
                    },
                    "AlterneteActionsEnterCVV.rtxCVV": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OrLineForCVVandPIN": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "OrLineForCVVandPIN"
                    },
                    "AlterneteActionsEnterPIN": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "72.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterPIN"
                    },
                    "AlterneteActionsEnterPIN.rtxCVV": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSendOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnUseCVV": {
                        "segmentProps": []
                    },
                    "resetusingOTP.flxCVV": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImgTxt": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxResetBySecureCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.orline": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTP"
                    },
                    "resetusingOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.tbxCVV": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "imgCloseSendOTP": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxResetUsingOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnResendOTP": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "5.280000000000001%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImgTxt": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxResetBySecureCode": {
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "1"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.orline": {
                        "top": {
                            "type": "string",
                            "value": "2.2800000000000002%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTPEnterOTP"
                    },
                    "resetusingOTPEnterOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseResetUsingOTP": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxResetUsingCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "ResetOrEnroll"
                    },
                    "ResetOrEnroll.btnNext": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.btnUseOTP": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVVHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCards": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxResetEnrollCVV": {
                        "top": {
                            "type": "string",
                            "value": "22.5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWrongCvv": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.orline": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.rtxEnterCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseResetUsingCVV": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseSelectUsername": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "lblWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSupportedFileTypes",
                        "top": {
                            "type": "string",
                            "value": "76dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxUsername": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lstBoxSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectSignInOrResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "SignInAs": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "OrLineForSelectUsername": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "43.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "ResetMyPassword": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "74.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxMatchPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.50%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxNewPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.50%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxRulesPassword": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.imgPasswordMatched": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.imgValidPassword": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.lblErrorInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.lblResetPasswordTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.tbxNewPassword": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLoginMFA": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "MFAFlow"
                    },
                    "MFAFlow.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.imgNewBrowserDetection": {
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblCloseBrace": {
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblNewBrowserDetection": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblOpenBrace": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblOpenBracePhone": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblRegisteredEmailIDs": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblRegisteredPhone": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "MFA.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "flxResetSuccessful": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.btnLoginLater": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "57.56%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxDoneLoginLater": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "82%"
                        },
                        "width": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxPasswordSuccess": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "141dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblCongrats": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "198dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblReserSuccessMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "282dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.orlineSuccess": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "passwordresetsuccess"
                    },
                    "passwordresetsuccess.rtxDoneLoginlater": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgCloseResetSuccessful": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxBlocked": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "blocked": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "blocked"
                    },
                    "blocked.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "blocked.imgTakeHelpTime": {
                        "top": {
                            "type": "string",
                            "value": "21.32%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseBlocked": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxEnrollOrServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollAlert"
                    },
                    "EnrollAlert.btnBackToLogin": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.rtxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "77.21%"
                        },
                        "segmentProps": []
                    },
                    "flxEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollPromptScreen"
                    },
                    "EnrollPromptScreen.btnBackToLogin": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "115dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.rtxServerError": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseEnroll": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxLogoutMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.flxLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.imgLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblLoggedOut": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblSuccessIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "106dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneAndEmail": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnLogin": {
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnProceed": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxClick": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPModule.flxDescription": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterOTP": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxImgTxt": {
                        "height": {
                            "type": "string",
                            "value": "210px"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRemember": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRememberMe": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flximgrtx": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "380dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblHeaderOTP": {
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblPhoneOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredPhone": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblResendOTPMessage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPModule.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "290px"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lbxEmail": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lbxPhone": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "20%"
                        },
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "text": "Enter Secure Access Code sent on\nyour mobile phone.",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.tbxCVV": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseMFA": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseMFA": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxEnrollActivateContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "580px"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectOption": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectOption": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [0, 0, 0, 0],
                        "text": "Please select an option:",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "EnrollNow": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollNow"
                    },
                    "EnrollNow.fontIconOption": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "EnrollNow.lblName": {
                        "text": "Enroll now",
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "ActivateNow": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ActivateNow"
                    },
                    "ActivateNow.fontIconOption": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "d",
                        "segmentProps": []
                    },
                    "flxActivateProfile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "enrollActivateComponent": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseEnrollActivate": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "lblCloseEnrollActivate": {
                        "segmentProps": []
                    },
                    "flxBeyondBankingContent": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "865dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "centerY": {
                            "type": "string",
                            "value": "52%"
                        },
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCopyRight": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "905dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgTemenos": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnSecondarySSPsknBtnSecondarySSP0273e315Px",
                        "top": {
                            "type": "string",
                            "value": "80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "72.30%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxAppLogo": {
                        "height": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "imgAppLogo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "flxTNCEntity": {
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.TermsAndConditionBody": {
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "750dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "TermsAndConditionLegalEntity"
                    },
                    "TermsAndConditionLegalEntity.btnAcceptTAndC": {
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.btnCancelTAndC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxLegalEntityBtn": {
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxTermsAndConditionDetails": {
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxTermsAndCondtionBody": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "590dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "Updating your preferred Language",
                        "top": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackTakeSurvey": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFeedbackPopup"
                    },
                    "CustomFeedbackPopup.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupMessage": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupmsg": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.no",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.yes",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDiffLanguage": {
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.btnNo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.no",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.yes",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBG": {
                        "segmentProps": []
                    },
                    "imgLoginBg": {
                        "segmentProps": []
                    }
                },
                "768": {
                    "frmLogin": {
                        "segmentProps": []
                    },
                    "tbxAutopopulateIssueFix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20.25%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "138dp"
                        },
                        "segmentProps": []
                    },
                    "imgKony": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "20.25%"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "lblCheckBox": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "skn0273e315pxolbfonticons",
                        "segmentProps": []
                    },
                    "lblLanguage": {
                        "skin": "sknLabelSSP0273e315px",
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "right": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    },
                    "flxDifferentLanguagesSegment": {
                        "skin": "sknflxShdwLangPopTab696969",
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFFFFFFnoshadow",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxLoginComponentContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxCloseIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "18"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21px"
                        },
                        "segmentProps": []
                    },
                    "imgCloseIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "closeicon.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "loginComponent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewNEnroll": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms1": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms1"
                    },
                    "AllForms1.RichTextInfo": {
                        "i18n_text": "i18n.login.NAOInfo",
                        "text": "Using this option you can open retail account only like savings account, checking account, credit card etc.",
                        "segmentProps": []
                    },
                    "AllForms1.lblInfo": {
                        "i18n_text": "i18n.WireTransfers.Information",
                        "text": "Information",
                        "segmentProps": []
                    },
                    "carousel": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "carousel"
                    },
                    "flxAppStore": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgAppstore": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "src": "appstore_2x.png",
                        "segmentProps": []
                    },
                    "flxPlayStore": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgPlayStore": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "src": "google_play_2x.png",
                        "segmentProps": []
                    },
                    "OTPComponent": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "cantSignIn": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "cantSignIn"
                    },
                    "regenrateActivationCodeComponent": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "resetPasswordComponent": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxOuter": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "segmentProps": []
                    },
                    "flxLegalEntitySelect1": {
                        "height": {
                            "type": "string",
                            "value": "220px"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "140px"
                        },
                        "segmentProps": []
                    },
                    "lblPleaseSelectEntity": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxLegalEntityMain": {
                        "height": {
                            "type": "string",
                            "value": "220px"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "200px"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectEntity": {
                        "skin": "sknLblSSP72727215px",
                        "segmentProps": []
                    },
                    "flxLegalEntityDropDown": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknFlxLegalEntity",
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "skin": "slLabel0fb44c6072cea44",
                        "text": "Select",
                        "segmentProps": []
                    },
                    "imgdropdownExpand": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "25px"
                        },
                        "left": {
                            "type": "string",
                            "value": "90%"
                        },
                        "src": "listboxarw.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLegalEntityCombine": {
                        "segmentProps": []
                    },
                    "flxLegalSearch": {
                        "segmentProps": []
                    },
                    "txtLegalSearch": {
                        "skin": "tbxPlaceholder",
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgSearch": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "90%"
                        },
                        "src": "selecetd_search.png",
                        "top": {
                            "type": "number",
                            "value": "7"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxLegalDropdown": {
                        "segmentProps": []
                    },
                    "lblLegalEntityHeader": {
                        "left": {
                            "type": "number",
                            "value": "10"
                        },
                        "skin": "slLabel0fb44c6072cea44",
                        "text": "LEGAL ENTITY",
                        "segmentProps": []
                    },
                    "segLegalEntity": {
                        "data": [{
                            "lblLegalEntityList": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "India"
                            }
                        }, {
                            "lblLegalEntityList": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "USA"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AuthenticationMA",
                            "friendlyName": "flxsegList"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxsegList": "flxsegList",
                            "lblLegalEntityList": "lblLegalEntityList"
                        },
                        "zIndex": 10,
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AuthenticationMA"
                    },
                    "btnLegalEntity": {
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "18"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21px"
                        },
                        "segmentProps": []
                    },
                    "imgCloseLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLoginSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnForgotPassword": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnOnlineAccessEnroll": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnOpenNewAccount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flexcheckuncheck": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "16%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxImageUser": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxNewNEnroll": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxRememberMe": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "MainLogin.flxUserDropdown": {
                        "isVisible": false,
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "MainLogin.flxUserName": {
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.imgViewPassword": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.lblRememberMe": {
                        "maxWidth": {
                            "type": "string",
                            "value": "85%"
                        },
                        "text": "Remember me",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "MainLogin.lblWelcomeMobile": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.rtxErrorMsg": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "36dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.rtxErrorMsgUser": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "segmentProps": []
                    },
                    "lblWelcomeBackSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxUserContentSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImageSelectUsername": {
                        "top": {
                            "type": "string",
                            "value": "1.2800000000000002%"
                        },
                        "segmentProps": []
                    },
                    "lblYourSelectUsername": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "41.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "52.5%"
                        },
                        "segmentProps": []
                    },
                    "flxVerification": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "letsverify": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "letsverify"
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "362dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "44.61%"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "AllForms.imgCross": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "AllForms.imgToolTip": {
                        "left": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "LblVerifiedUserWelcome": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxUserContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImage": {
                        "top": {
                            "type": "string",
                            "value": "1.2800000000000002%"
                        },
                        "segmentProps": []
                    },
                    "lblYourUsername": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "41.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "52.5%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBackBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0.040000000000000036%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsSignIn"
                    },
                    "orlineWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "42.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": [],
                        "instanceId": "orlineWelcomeBack"
                    },
                    "AlterneteActionsResetPassword": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "72.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsResetPassword"
                    },
                    "flxResetPasswordOptions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblResetYourPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "86dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "32"
                        },
                        "segmentProps": []
                    },
                    "flxResetUserImg": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lvlVerificationNotice": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "54%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxResetPassBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0.04%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterCVV"
                    },
                    "OrLineForCVVandPIN": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "OrLineForCVVandPIN"
                    },
                    "AlterneteActionsEnterPIN": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "72.2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterPIN"
                    },
                    "flxSendOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "4.199999999999999%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnUseCVV": {
                        "segmentProps": []
                    },
                    "resetusingOTP.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxHeaderNError": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0.8200000000000003%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImgTxt": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "53dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxResetBySecureCode": {
                        "height": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "-6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgUserOutline": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.orline": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTP"
                    },
                    "resetusingOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "2.2%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnResendOTP": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "5.280000000000001%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxCVV": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImgTxt": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxResetBySecureCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "-7dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "34%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "58%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.orline": {
                        "top": {
                            "type": "string",
                            "value": "3.2800000000000002%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTPEnterOTP"
                    },
                    "resetusingOTPEnterOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "43dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "ResetOrEnroll"
                    },
                    "ResetOrEnroll.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.btnUseOTP": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVVHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCards": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxHeaderNError": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxResetEnrollCVV": {
                        "top": {
                            "type": "string",
                            "value": "117dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWrongCvv": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.orline": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.rtxEnterCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.tbxCVV": {
                        "segmentProps": []
                    },
                    "flxSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblWelcomeBack": {
                        "top": {
                            "type": "string",
                            "value": "76dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lstBoxSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "79%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectSignInOrResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "SignInAs": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "OrLineForSelectUsername": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "43.2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ResetMyPassword": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "74.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxMatchPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxNewPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxRulesPassword": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.imgPasswordMatched": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.imgValidPassword": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMFA": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "MFA.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "flxResetSuccessful": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "62.56%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxDoneLoginLater": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "582dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "127dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblCongrats": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "184dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblReserSuccessMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "44.019999999999996%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.orlineSuccess": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "520dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "passwordresetsuccess"
                    },
                    "passwordresetsuccess.rtxDoneLoginlater": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxBlocked": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "blocked.imgTakeHelpTime": {
                        "top": {
                            "type": "string",
                            "value": "22.32%"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollOrServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollAlert"
                    },
                    "EnrollAlert.btnBackToLogin": {
                        "top": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollPromptScreen"
                    },
                    "EnrollPromptScreen.flxServerError": {
                        "top": {
                            "type": "string",
                            "value": "136dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogoutMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.flxLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.imgLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblLoggedOut": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblSuccessIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneAndEmail": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxCVV": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxClick": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPModule.flxDescription": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "297dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterOTP": {
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxImgTxt": {
                        "height": {
                            "type": "string",
                            "value": "160px"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRemember": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRememberMe": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flximgrtx": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "OTPModule.lblHeaderOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblPhoneOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredPhone": {
                        "top": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblResendOTPMessage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPModule.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "290px"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.rtxEnterCVVCode": {
                        "centerY": {
                            "type": "string",
                            "value": "20%"
                        },
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.tbxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseMFA": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollActivateContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectOption": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectOption": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "Please select an option:",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "EnrollNow": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollNow"
                    },
                    "EnrollNow.fontIconOption": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "EnrollNow.lblName": {
                        "text": "Enroll Now",
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "ActivateNow": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ActivateNow"
                    },
                    "ActivateNow.fontIconOption": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "d",
                        "segmentProps": []
                    },
                    "flxActivateProfile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "enrollActivateComponent": {
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseEnrollActivate": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "45"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "lblCloseEnrollActivate": {
                        "segmentProps": []
                    },
                    "flxBeyondBankingContent": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "930dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "left": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxCopyRight": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "965dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "imgTemenos": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "126dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "855dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "centerX": {
                            "type": "string",
                            "value": "49.94%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "202dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "552dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "59.40%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "15%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxAppLogo": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "18%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "138dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "imgAppLogo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTNCEntity": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": [],
                        "instanceId": "TermsAndConditionLegalEntity"
                    },
                    "TermsAndConditionLegalEntity.btnAcceptTAndC": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.btnCancelTAndC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxLegalEntityBtn": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxTermsAndConditionDetails": {
                        "height": {
                            "type": "string",
                            "value": "340dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxTermsAndCondtionBody": {
                        "height": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "Updating your preferred Language",
                        "top": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackTakeSurvey": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFeedbackPopup"
                    },
                    "CustomFeedbackPopup.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupMessage": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupmsg": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "i18n_text": "i18n.common.no",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "i18n_text": "i18n.common.yes",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxDiffLanguage": {
                        "segmentProps": []
                    },
                    "DiffLanguagePopup": {
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.btnNo": {
                        "i18n_text": "i18n.common.no",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "i18n_text": "i18n.common.yes",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "imgLoginBg": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "frmLogin": {
                        "segmentProps": []
                    },
                    "tbxAutopopulateIssueFix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "138dp"
                        },
                        "segmentProps": []
                    },
                    "imgKony": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "lblCheckBox": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "skn0273e315pxolbfonticons",
                        "segmentProps": []
                    },
                    "lblLanguage": {
                        "skin": "sknLabelSSP0273e315px",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "right": {
                            "type": "string",
                            "value": "245dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "flxDifferentLanguagesSegment": {
                        "skin": "sknflxShdwLangPopTab696969",
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "900dp"
                        },
                        "skin": "sknFFFFFFnoshadow",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxLoginComponentContainer": {
                        "height": {
                            "type": "string",
                            "value": "93%"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxCloseIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "closeicon.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "loginComponent": {
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "rtxInfo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "right": {
                            "type": "number",
                            "value": ""
                        },
                        "text": "If you forgot Temporary Password or Missed Temporary Password or want to reset temporary password”, click “Cant' sign-in” option to Reset password.",
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxNewNEnroll": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms1": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms1"
                    },
                    "AllForms1.RichTextInfo": {
                        "i18n_text": "i18n.login.NAOInfo",
                        "text": "Using this option you can open retail account only like savings account, checking account, credit card etc.",
                        "segmentProps": []
                    },
                    "AllForms1.lblInfo": {
                        "i18n_text": "i18n.WireTransfers.Information",
                        "text": "Information",
                        "segmentProps": []
                    },
                    "carousel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "carousel"
                    },
                    "flxAppStore": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgAppstore": {
                        "isVisible": true,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "src": "appstore_2x.png",
                        "segmentProps": []
                    },
                    "flxPlayStore": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgPlayStore": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "src": "google_play_2x.png",
                        "segmentProps": []
                    },
                    "OTPComponent": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "cantSignIn": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "cantSignIn"
                    },
                    "regenrateActivationCodeComponent": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "resetPasswordComponent": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "900dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "22%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxOuter": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "segmentProps": []
                    },
                    "flxLegalEntitySelect1": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "20"
                        },
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "lblPleaseSelectEntity": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLegalEntityMain": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "170px"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectEntity": {
                        "skin": "sknLblSSP72727215px",
                        "segmentProps": []
                    },
                    "flxLegalEntityDropDown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknFlxLegalEntity",
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectLegalEntity": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "skin": "sknLblSSP72727215px",
                        "text": "Select",
                        "segmentProps": []
                    },
                    "imgdropdownExpand": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "90%"
                        },
                        "src": "listboxarw.png",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxLegalSearch": {
                        "segmentProps": []
                    },
                    "txtLegalSearch": {
                        "skin": "tbxPlaceholder",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgSearch": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "90%"
                        },
                        "src": "selecetd_search.png",
                        "top": {
                            "type": "number",
                            "value": "7"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxLegalDropdown": {
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "lblLegalEntityHeader": {
                        "left": {
                            "type": "number",
                            "value": "10"
                        },
                        "skin": "slLabel0fb44c6072cea44",
                        "text": "LEGAL ENTITY",
                        "segmentProps": []
                    },
                    "segLegalEntity": {
                        "data": [{
                            "lblLegalEntityList": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "India"
                            }
                        }, {
                            "lblLegalEntityList": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "USA"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AuthenticationMA",
                            "friendlyName": "flxsegList"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxsegList": "flxsegList",
                            "lblLegalEntityList": "lblLegalEntityList"
                        },
                        "zIndex": 10,
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AuthenticationMA"
                    },
                    "btnLegalEntity": {
                        "top": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLoginSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnForgotPassword": {
                        "right": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnOnlineAccessEnroll": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnOpenNewAccount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flexcheckuncheck": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "16%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxImageUser": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxNewNEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxRememberMe": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxUserDropdown": {
                        "isVisible": false,
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "MainLogin.flxUserName": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "7.04%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.imgViewPassword": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.lblRememberMe": {
                        "maxWidth": {
                            "type": "string",
                            "value": "85%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Remember me",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "MainLogin.lblWelcomeMobile": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.rtxErrorMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.rtxErrorMsgUser": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "72dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblWelcomeBackSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxUserContentSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImageSelectUsername": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUserSelectUsername": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUserGreenFrameUsername": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblYourSelectUsername": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "49.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "63.5%"
                        },
                        "segmentProps": []
                    },
                    "flxVerification": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "letsverify": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "letsverify"
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "355dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "37.46%"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "AllForms.imgCross": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "AllForms.imgToolTip": {
                        "left": {
                            "type": "string",
                            "value": "69.10%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "LblVerifiedUserWelcome": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxUserContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImage": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUser": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUserGreenFrame": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblYourUsername": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "49.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "63.5%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBackBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsSignIn"
                    },
                    "orlineWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "19.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "orlineWelcomeBack"
                    },
                    "AlterneteActionsResetPassword": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "16.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsResetPassword"
                    },
                    "flxResetPasswordOptions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblResetYourPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "top": {
                            "type": "string",
                            "value": "86dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetUserImg": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lvlVerificationNotice": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "56%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxResetPassBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterCVV"
                    },
                    "OrLineForCVVandPIN": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "OrLineForCVVandPIN"
                    },
                    "AlterneteActionsEnterPIN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "76.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterPIN"
                    },
                    "flxSendOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnUseCVV": {
                        "segmentProps": []
                    },
                    "resetusingOTP.flxCVV": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxHeaderNError": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "131dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImgTxt": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxResetBySecureCode": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "2"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResetPasswordMsg": {
                        "segmentProps": []
                    },
                    "resetusingOTP.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.orline": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "resetusingOTP"
                    },
                    "resetusingOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "46dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "6.280000000000001%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "131dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImgTxt": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65.89%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxResetBySecureCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "-1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "63.83%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.orline": {
                        "top": {
                            "type": "string",
                            "value": "7.280000000000001%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTPEnterOTP"
                    },
                    "resetusingOTPEnterOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.tbxCVV": {
                        "centerY": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "ResetOrEnroll"
                    },
                    "ResetOrEnroll.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.btnUseOTP": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVVHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCards": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxHeaderNError": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "number",
                            "value": "245"
                        },
                        "top": {
                            "type": "string",
                            "value": "1.5100000000000016%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxResetEnrollCVV": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWrongCvv": {
                        "isVisible": false,
                        "text": "Enrolling ",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.orline": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.rtxEnterCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblWelcomeBack": {
                        "top": {
                            "type": "string",
                            "value": "86dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lstBoxSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectSignInOrResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "SignInAs": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "OrLineForSelectUsername": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42.80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ResetMyPassword": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "74.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxMatchPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.50%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxNewPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.50%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.imgPasswordMatched": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.imgValidPassword": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMFA": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "MFA.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "flxResetSuccessful": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "55.56%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxDoneLoginLater": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "536dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxPasswordSuccess": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "127dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.imgTickFrame": {
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblCongrats": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "184dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblReserSuccessMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "44.02%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.orlineSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "448dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "passwordresetsuccess"
                    },
                    "passwordresetsuccess.rtxDoneLoginlater": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxBlocked": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "blocked.imgTakeHelpTime": {
                        "top": {
                            "type": "string",
                            "value": "25.32%"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollOrServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollAlert"
                    },
                    "EnrollAlert.btnBackToLogin": {
                        "top": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.rtxServerError": {
                        "top": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxEnroll": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen": {
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollPromptScreen"
                    },
                    "EnrollPromptScreen.btnBackToLogin": {
                        "top": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.flxServerError": {
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "131dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.rtxServerError": {
                        "top": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxLogoutMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow.fontIconOption": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.flxLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.imgLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "47.43%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblLoggedOut": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblSuccessIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg": {
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "logOutMsg"
                    },
                    "flxPhoneAndEmail": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.btnProceed": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxDescription": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterOTP": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterSecureAccessCode": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxImgTxt": {
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRemember": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRememberMe": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "132dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flximgrtx": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblHeaderOTP": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblPhoneOTP": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredPhone": {
                        "top": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblWrongOTP": {
                        "isVisible": false,
                        "text": "Sorry, this secure code is incorrect. Try again.Sorry, this secure code is incorrect. Try again.Sorry, this secure code is incorrect. Try again.",
                        "top": {
                            "type": "string",
                            "value": "270px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.rtxEnterCVVCode": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPModule.tbxCVV": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseMFA": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollActivateContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxSelectOption": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectOption": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "Please select an option:",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "EnrollNow": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollNow"
                    },
                    "EnrollNow.fontIconOption": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "EnrollNow.lblName": {
                        "text": "Enroll Now",
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "ActivateNow": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ActivateNow"
                    },
                    "ActivateNow.fontIconOption": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "d",
                        "segmentProps": []
                    },
                    "flxActivateProfile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "enrollActivateComponent": {
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseEnrollActivate": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "lblCloseEnrollActivate": {
                        "segmentProps": []
                    },
                    "flxBeyondBankingContent": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "970dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "650dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "padding": [0, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxCopyRight": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "1015dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "imgTemenos": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "126dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "850dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "95.5%"
                        },
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "625dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "51%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxAppLogo": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "22.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "138dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "imgAppLogo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTNCEntity": {
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.TermsAndConditionBody": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity": {
                        "height": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": [],
                        "instanceId": "TermsAndConditionLegalEntity"
                    },
                    "TermsAndConditionLegalEntity.btnAcceptTAndC": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.btnCancelTAndC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxLegalEntityBtn": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxTermsAndConditionDetails": {
                        "height": {
                            "type": "string",
                            "value": "340dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxTermsAndCondtionBody": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "updating your preferred language",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackTakeSurvey": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup": {
                        "segmentProps": [],
                        "instanceId": "CustomFeedbackPopup"
                    },
                    "CustomFeedbackPopup.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupmsg": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "i18n_text": "i18n.common.no",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.yes",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxDiffLanguage": {
                        "segmentProps": []
                    },
                    "DiffLanguagePopup": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.btnNo": {
                        "i18n_text": "i18n.common.no",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.yes",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "imgLoginBg": {
                        "segmentProps": []
                    },
                    "flxImg": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1400": {
                    "frmLogin": {
                        "segmentProps": []
                    },
                    "tbxAutopopulateIssueFix": {
                        "height": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "skin": "tbxInvisible",
                        "text": "test",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "370dp"
                        },
                        "segmentProps": []
                    },
                    "imgKony": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "a11yLabel": "Infinity Digital Banking"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "148dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknFlxF1F1F1Border1PX",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "126dp"
                        },
                        "segmentProps": []
                    },
                    "lblCheckBox": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknffffff15pxolbfonticons",
                        "text": "O",
                        "segmentProps": []
                    },
                    "lblLanguage": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPLblFFFFFF15Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "sknflxMenuTransprent",
                        "width": {
                            "type": "string",
                            "value": "126dp"
                        },
                        "segmentProps": []
                    },
                    "flxDifferentLanguagesSegment": {
                        "skin": "sknflxShdwLangPopWeb104c7d",
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxLogin": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "650dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxLoginComponentContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "90%"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgCloseIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "closeicon.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "loginComponent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "rtxInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxNewNEnroll": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms1": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "-100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms1"
                    },
                    "AllForms1.RichTextInfo": {
                        "i18n_text": "i18n.login.NAOInfo",
                        "text": "Using this option you can open retail account only like savings account, checking account, credit card etc.",
                        "segmentProps": []
                    },
                    "AllForms1.lblInfo": {
                        "i18n_text": "i18n.WireTransfers.Information",
                        "text": "Information",
                        "segmentProps": []
                    },
                    "carousel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "carousel"
                    },
                    "carousel.segCarousel": {
                        "segmentProps": []
                    },
                    "flxAppStore": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgAppstore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPlayStore": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgPlayStore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPComponent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "cantSignIn": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "cantSignIn"
                    },
                    "cantSignIn.flxContent": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "cantSignIn.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "regenrateActivationCodeComponent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "8%"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "resetPasswordComponent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLegalEntity": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "650dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxOuter": {
                        "height": {
                            "type": "string",
                            "value": "918dp"
                        },
                        "isCustomLayout": false,
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "-4dp"
                        },
                        "skin": "sab1179a6e2a45b8b9bcbff84e887675",
                        "top": {
                            "type": "string",
                            "value": "-4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "106.00%"
                        },
                        "zIndex": 4,
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxLegalEntitySelect1": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "top": {
                            "type": "number",
                            "value": "140"
                        },
                        "segmentProps": []
                    },
                    "lblPleaseSelectEntity": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "text": "Please select An entity",
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxLegalEntityMain": {
                        "height": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "top": {
                            "type": "number",
                            "value": "190"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectEntity": {
                        "skin": "sknLblSSP72727215px",
                        "segmentProps": []
                    },
                    "flxLegalEntityDropDown": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknFlxLegalEntity",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectLegalEntity": {
                        "height": {
                            "type": "string",
                            "value": "90%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slLabel0fb44c6072cea44",
                        "text": "Select",
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "69%"
                        },
                        "segmentProps": []
                    },
                    "imgdropdownExpand": {
                        "bottom": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "245"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "listboxuparrow.png",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "flxLegalEntityCombine": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxLegalSearch": {
                        "segmentProps": []
                    },
                    "txtLegalSearch": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "placeholder": "Search",
                        "skin": "tbxPlaceholder",
                        "width": {
                            "type": "string",
                            "value": "284dp"
                        },
                        "segmentProps": []
                    },
                    "imgSearch": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "src": "selecetd_search.png",
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxLegalDropdown": {
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "lblLegalEntityHeader": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "slLabel0fb44c6072cea44",
                        "text": "LEGAL ENTITY",
                        "segmentProps": []
                    },
                    "segLegalEntity": {
                        "data": [{
                            "lblLegalEntityList": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "India"
                            }
                        }, {
                            "lblLegalEntityList": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "USA"
                            }
                        }],
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AuthenticationMA",
                            "friendlyName": "flxsegList"
                        }),
                        "sectionHeaderTemplate": "",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "widgetDataMap": {
                            "flxsegList": "flxsegList",
                            "lblLegalEntityList": "lblLegalEntityList"
                        },
                        "zIndex": 10,
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AuthenticationMA"
                    },
                    "btnLegalEntity": {
                        "top": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgCloseLegalEntity": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxLoginSelectedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "skin": "bbSKnFlxffffff",
                        "segmentProps": []
                    },
                    "MainLogin.btnForgotPassword": {
                        "right": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "50.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnOnlineAccessEnroll": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.btnOpenNewAccount": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flexcheckuncheck": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "580dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxImageUser": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "109dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxLoginUser": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "1.5%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxPassword": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxRememberMe": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.flxUserDropdown": {
                        "isVisible": false,
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "MainLogin.flxUserName": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.imgUser": {
                        "centerY": {
                            "type": "string",
                            "value": "88.17%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "MainLogin.imgUserOutline": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "53%"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.lblRememberMe": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "82%"
                        },
                        "text": "Remember me",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "MainLogin.lblVerifiedUser": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.lblWelcomeMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.rtxErrorMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.rtxErrorMsgUser": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": []
                    },
                    "MainLogin.rtxWithUsername": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "text": "Please login with username",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblWelcomeBackSelectedUsername": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSupportedFileTypes",
                        "segmentProps": []
                    },
                    "flxUserContentSelectUsername": {
                        "height": {
                            "type": "string",
                            "value": "82dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84.00%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImageSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUserSelectUsername": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUserGreenFrameUsername": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "lblYourSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "63dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "12.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedSelectUsername": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "32.5%"
                        },
                        "segmentProps": []
                    },
                    "flxVerification": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "letsverify": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": [],
                        "instanceId": "letsverify"
                    },
                    "AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "225dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "382dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "41.93%"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "AllForms.imgToolTip": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseWelcomeBack": {
                        "segmentProps": []
                    },
                    "LblVerifiedUserWelcome": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSupportedFileTypes",
                        "top": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "segmentProps": []
                    },
                    "flxUserContent": {
                        "height": {
                            "type": "string",
                            "value": "82dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84.00%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUser": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUserGreenFrame": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "lblYourUsername": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "63dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "12.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedUsername": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "32.5%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBackBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "7.04%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsSignIn"
                    },
                    "AlterneteActionsSignIn.fontIconOption": {
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn.imgOptionKA": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "orlineWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "43.63%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "orlineWelcomeBack"
                    },
                    "AlterneteActionsResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "69%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsResetPassword"
                    },
                    "flxResetPasswordOptions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "lblResetYourPassword": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSupportedFileTypes",
                        "top": {
                            "type": "string",
                            "value": "112dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetContent": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "flxResetUserImg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgUserReset": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgUserBoundary": {
                        "segmentProps": []
                    },
                    "lvlVerificationNotice": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [1, 0, 2, 0],
                        "skin": "sbaa434a53c643c4a3fc0f563dbd2403",
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "segmentProps": []
                    },
                    "flxResetPassBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "0.040000000000000036%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterCVV"
                    },
                    "AlterneteActionsEnterCVV.fontIconOption": {
                        "text": "x",
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsEnterCVV.imgOptionKA": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OrLineForCVVandPIN": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "36.6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "OrLineForCVVandPIN"
                    },
                    "AlterneteActionsEnterPIN": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "62%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsEnterPIN"
                    },
                    "AlterneteActionsEnterPIN.fontIconOption": {
                        "text": "y",
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "flxSendOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "2.1999999999999993%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.btnResendOTP": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "resetusingOTP.btnUseCVV": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxCVV": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxImgTxt": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.flxResetBySecureCode": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "45%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgUser": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.imgUserOutline": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP.orline": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "resetusingOTP"
                    },
                    "resetusingOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "left": {
                            "type": "string",
                            "value": "45px"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "7px"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "3.2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnResendOTP": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.btnUseCVV": {
                        "top": {
                            "type": "string",
                            "value": "4.280000000000001%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxHeaderNError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "156dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImageUser": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "3"
                        },
                        "top": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxImgTxt": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.flxResetBySecureCode": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "77dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.imgCVVOrOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.imgUser": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.imgUserOutline": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResendOTPMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblResetPasswordMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.lblWrongOTP": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP.orline": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "resetusingOTPEnterOTP": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "resetusingOTPEnterOTP"
                    },
                    "resetusingOTPEnterOTP.rtxEnterCVVCode": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxResetUsingCVV": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "ResetOrEnroll"
                    },
                    "ResetOrEnroll.btnNext": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.btnUseOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCVVHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxCards": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxHeaderNError": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxImageUser": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.flxResetEnrollCVV": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "128dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgCVV": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgUser": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.imgUserOutline": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.lblWrongCvv": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "76dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.orline": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "98dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.rtxEnterCVV": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "58%"
                        },
                        "segmentProps": []
                    },
                    "ResetOrEnroll.tbxCVV": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "skin": "bbSKnFlxffffff",
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "lblWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "80"
                        },
                        "skin": "sknSupportedFileTypes",
                        "top": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "lstBoxSelectUsername": {
                        "padding": [4, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxSelectSignInOrResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "SignInAs": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7.04%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "OrLineForSelectUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "43.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ResetMyPassword": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "69%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.btnNext": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxHeaderNError": {
                        "top": {
                            "type": "string",
                            "value": "156dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxMain": {
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxMatchPassword": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxNewPassword": {
                        "top": {
                            "type": "string",
                            "value": "3.50%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxPasswordResetContent": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "newpasswordsetting.flxRulesPassword": {
                        "segmentProps": []
                    },
                    "newpasswordsetting.imgPasswordMatched": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.imgValidPassword": {
                        "right": {
                            "type": "string",
                            "value": "3.03%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.lblErrorInfo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting.lblResetPasswordTitle": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "newpasswordsetting": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "newpasswordsetting"
                    },
                    "newpasswordsetting.tbxMatchPassword": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLoginMFA": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "MFAFlow"
                    },
                    "MFAFlow.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.flxRegisteredEmailId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.flxRegisteredPhone": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.imgNewBrowserDetection": {
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblNewBrowserDetection": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblOpenBrace": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblRegisteredEmailIDs": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblRegisteredEmailId": {
                        "text": "JXHXBXIXEX@GMAIL.COM",
                        "segmentProps": []
                    },
                    "MFAFlow.lblRegisteredPhone": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "MFAFlow.lblSentYouSecureAccessCode": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "MFA": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "MFA"
                    },
                    "MFA.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "flxResetSuccessful": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.btnProceed": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "59.56%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxDoneLoginLater": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "83.5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxPasswordSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.flxUserImagewithTick": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "138dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.imgTickFrame": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.imgUserwithoutTick": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblCongrats": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "99dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "154dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.lblReserSuccessMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "45%"
                        },
                        "top": {
                            "type": "string",
                            "value": "254dp"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess.orlineSuccess": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "73%"
                        },
                        "segmentProps": []
                    },
                    "passwordresetsuccess": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "passwordresetsuccess"
                    },
                    "flxCloseResetSuccessful": {
                        "segmentProps": []
                    },
                    "flxBlocked": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "blocked": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "blocked"
                    },
                    "flxEnrollOrServerError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollAlert"
                    },
                    "EnrollAlert.btnBackToLogin": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.btnEnroll": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "74"
                        },
                        "top": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblNotYetEnrolledOrError": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "EnrollAlert.rtxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "It seems our servers are having some difficulties. The data displayed may be inaccurate. Please refresh the page and try logging in again",
                        "top": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEnroll": {
                        "isVisible": false,
                        "skin": "bbSKnFlxffffff",
                        "segmentProps": []
                    },
                    "EnrollPromptScreen": {
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollPromptScreen"
                    },
                    "EnrollPromptScreen.btnBackToLogin": {
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.btnEnroll": {
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollPromptScreen.rtxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxLogoutMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "bbSKnFlxffffff",
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow": {
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "99px"
                        },
                        "top": {
                            "type": "string",
                            "value": "36dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow.flxImgMain": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.flxLogoutSuccess": {
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.imgLogoutSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblLoggedOut": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblSuccessIcon": {
                        "left": {
                            "type": "string",
                            "value": "76dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "74.49%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg": {
                        "zIndex": 1,
                        "segmentProps": [],
                        "instanceId": "logOutMsg"
                    },
                    "flxPhoneAndEmail": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule": {
                        "top": {
                            "type": "string",
                            "value": "94dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxClick": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterOTP": {
                        "segmentProps": []
                    },
                    "OTPModule.flxEnterSecureAccessCode": {
                        "segmentProps": []
                    },
                    "OTPModule.flxImgTxt": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRemember": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flxRememberMe": {
                        "width": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.flximgrtx": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblHeaderOTP": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblPhoneOTP": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "30%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblRegisteredEmail": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblResendMessage": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.lblWrongOTP": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "OTPModule.rtxEnterCVVCode": {
                        "centerY": {
                            "type": "string",
                            "value": "35%"
                        },
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPModule.tbxCVV": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseMFA": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollActivateContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxContent": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSelectOption": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectOption": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "Please select an option:",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "EnrollNow": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "instanceId": "EnrollNow"
                    },
                    "EnrollNow.fontIconOption": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "EnrollNow.lblName": {
                        "text": "",
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ActivateNow": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ActivateNow"
                    },
                    "ActivateNow.fontIconOption": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "d",
                        "segmentProps": []
                    },
                    "flxActivateProfile": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "680dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "enrollActivateComponent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxCloseEnrollActivate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "lblCloseEnrollActivate": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "a11yHidden": true,
                            "tagName": "span"
                        },
                        "segmentProps": []
                    },
                    "flxBeyondBankingContent": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "zIndex": 4,
                        "segmentProps": []
                    },
                    "flxBeyondBanking": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBeyondBankingDesc": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "displayText": true,
                        "focusSkin": "sknbtn0a78d1viewmoreFocus",
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "380dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "zIndex": 20,
                        "hoverSkin": "sknbtn41a0edviewmoreHover",
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "zIndex": 4,
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "focusSkin": "sknSSPBtnFFFFFF13px",
                        "padding": [0, 0, 1, 0],
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "focusSkin": "sknSSPBtnFFFFFF13px",
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxCopyRight": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgTemenos": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "padding": [0, 0, 0, 0],
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "583dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "341dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "455dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxAppLogo": {
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "imgAppLogo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTNCEntity": {
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity": {
                        "height": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": [],
                        "instanceId": "TermsAndConditionLegalEntity"
                    },
                    "TermsAndConditionLegalEntity.btnCancelTAndC": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxTermsAndConditionDetails": {
                        "height": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditionLegalEntity.flxTermsAndCondtionBody": {
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoading": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingWrapperChangeLang": {
                        "layoutType": kony.flex.FREE_FORM,
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxImageContainerChangeLang": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "Updating your preferred language",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxFeedbackTakeSurvey": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup": {
                        "width": {
                            "type": "string",
                            "value": "36.60%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFeedbackPopup"
                    },
                    "CustomFeedbackPopup.btnNo": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.btnYes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblHeading": {
                        "width": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupMessage": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupmsg": {
                        "isVisible": false,
                        "text": "Are you sure you want to cancel this transaction?",
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "i18n_text": "i18n.common.no",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.yes",
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblHeading": {
                        "i18n_text": "i18n.Profile.Language",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxDiffLanguage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "DiffLanguagePopup": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.btnNo": {
                        "i18n_text": "i18n.common.no",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.yes",
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.lblHeading": {
                        "i18n_text": "i18n.Profile.Language",
                        "text": "",
                        "segmentProps": []
                    },
                    "DiffLanguagePopup.lblPopupMessage": {
                        "i18n_text": "i18n.common.diffLanguagePopup",
                        "text": "Logged in  language is different from your preferred language. Do you want to Continue with selected language ?",
                        "segmentProps": []
                    },
                    "flxBG": {
                        "left": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLoginBG": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "900dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1014dp"
                        },
                        "segmentProps": []
                    },
                    "imgLoginBg": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "a11yLabel": "Infinity Digital Banking"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "loginComponent": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "AllForms1": {
                    "left": "0dp",
                    "top": "-130dp",
                    "zIndex": 10000
                },
                "AllForms1.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "AllForms1.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "carousel": {
                    "bottom": "",
                    "centerX": "50%",
                    "centerY": "",
                    "height": "175px",
                    "left": "0dp",
                    "maxHeight": "",
                    "maxWidth": "",
                    "minHeight": "",
                    "minWidth": "",
                    "right": "",
                    "top": "10dp",
                    "width": "95%"
                },
                "carousel.segCarousel": {
                    "left": "-5px",
                    "right": "-5px",
                    "width": ""
                },
                "OTPComponent": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                },
                "cantSignIn": {
                    "centerX": "",
                    "height": "100%",
                    "top": "0dp",
                    "width": "100%"
                },
                "cantSignIn.flxContent": {
                    "width": "85%"
                },
                "cantSignIn.flxHeader": {
                    "height": "120dp",
                    "top": "0dp"
                },
                "cantSignIn.imgCaptcha": {
                    "src": "imagedrag.png"
                },
                "cantSignIn.imgClose": {
                    "src": "bbcloseicon.png"
                },
                "cantSignIn.imgUserVerify": {
                    "src": "user_verify.png"
                },
                "regenrateActivationCodeComponent": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                },
                "resetPasswordComponent": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                },
                "MainLogin.btnForgotPassword": {
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "right": "3.0599999999999996%",
                    "width": "50%"
                },
                "MainLogin.btnLogin": {
                    "centerX": "86%",
                    "left": "0"
                },
                "MainLogin.btnOnlineAccessEnroll": {
                    "width": "40%"
                },
                "MainLogin.btnOpenNewAccount": {
                    "centerX": "25%",
                    "width": "40%"
                },
                "MainLogin.flxContainer": {
                    "centerX": "",
                    "height": "568dp",
                    "left": "",
                    "right": "",
                    "top": "0dp",
                    "width": "500dp"
                },
                "MainLogin.flxImageUser": {
                    "left": "0",
                    "top": "16.28%"
                },
                "MainLogin.flxPassword": {
                    "top": "3.50%"
                },
                "MainLogin.flxRemember": {
                    "width": "47%"
                },
                "MainLogin.flxRememberMe": {
                    "height": "70dp"
                },
                "MainLogin.flxUserName": {
                    "top": "4%"
                },
                "MainLogin.imgInfoIcon": {
                    "src": "info_grey.png"
                },
                "MainLogin.imgKony": {
                    "src": "kony_logo.png"
                },
                "MainLogin.imgPassword": {
                    "src": "password.png"
                },
                "MainLogin.imgRememberMe": {
                    "src": "unchecked_box.png"
                },
                "MainLogin.imgUser": {
                    "centerX": "12.25%",
                    "centerY": "27.17%",
                    "src": "default_username.png"
                },
                "MainLogin.imgUserAToolTip": {
                    "src": "username_tooltip.png"
                },
                "MainLogin.imgUserName": {
                    "src": "username.png"
                },
                "MainLogin.imgUserOutline": {
                    "centerX": "12.25%",
                    "centerY": "27.17%",
                    "src": "verify_user.png"
                },
                "MainLogin.imgViewPassword": {
                    "src": "view.png"
                },
                "MainLogin.lblRememberMe": {
                    "text": "R",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "MainLogin.lblWelcomeMobile": {
                    "text": "Welcome Back"
                },
                "MainLogin": {
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%"
                },
                "MainLogin.rtxErrorMsg": {
                    "centerX": "48%",
                    "top": "9dp"
                },
                "MainLogin.segUsers": {
                    "data": [{
                        "lblBottom": "",
                        "lblusers": ""
                    }],
                    "maxHeight": "120dp"
                },
                "MainLogin.tbxUserName": {
                    "left": "2%"
                },
                "AllForms.imgCross": {
                    "src": "icon_close_grey.png"
                },
                "AllForms.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "AlterneteActionsSignIn": {
                    "height": "10.66%",
                    "top": "7.04%"
                },
                "AlterneteActionsSignIn.flxImgContainer": {
                    "height": "100%",
                    "left": "1dp"
                },
                "AlterneteActionsSignIn.imgOptionKA": {
                    "height": "32dp",
                    "src": "login_signin.png",
                    "width": "33dp"
                },
                "AlterneteActionsSignIn.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "AlterneteActionsSignIn.rtxCVV": {
                    "centerY": "50%",
                    "top": ""
                },
                "orlineWelcomeBack.imgOr": {
                    "src": "or_circle.png"
                },
                "AlterneteActionsResetPassword": {
                    "height": "10.66%",
                    "top": "5.28%"
                },
                "AlterneteActionsResetPassword.flxImgContainer": {
                    "height": "100%",
                    "left": "1dp"
                },
                "AlterneteActionsResetPassword.imgOptionKA": {
                    "src": "reset_password.png"
                },
                "AlterneteActionsResetPassword.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "AlterneteActionsResetPassword.rtxCVV": {
                    "centerX": "",
                    "centerY": "50%",
                    "top": ""
                },
                "AlterneteActionsEnterCVV": {
                    "height": "14%",
                    "top": "8.80%",
                    "width": "85%"
                },
                "AlterneteActionsEnterCVV.fontIconOption": {
                    "text": "x"
                },
                "AlterneteActionsEnterCVV.imgOptionKA": {
                    "src": "active_cvv_icon.png"
                },
                "AlterneteActionsEnterCVV.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "AlterneteActionsEnterCVV.rtxCVV": {
                    "left": "85dp",
                    "width": "61.90%"
                },
                "OrLineForCVVandPIN.imgOr": {
                    "src": "or_circle.png"
                },
                "OrLineForCVVandPIN": {
                    "centerX": "50%",
                    "height": "30dp",
                    "top": "5.28%",
                    "width": "85%"
                },
                "AlterneteActionsEnterPIN": {
                    "height": "14%",
                    "top": "5.28%",
                    "width": "85%"
                },
                "AlterneteActionsEnterPIN.fontIconOption": {
                    "text": "y"
                },
                "AlterneteActionsEnterPIN.imgOptionKA": {
                    "src": "active_send_pin.png"
                },
                "AlterneteActionsEnterPIN.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "resetusingOTP.btnUseCVV": {
                    "top": "6%"
                },
                "resetusingOTP.flxImgTxt": {
                    "width": "100%"
                },
                "resetusingOTP.flxResetBySecureCode": {
                    "top": "33dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "resetusingOTP.imgCVVOrOTP": {
                    "src": "send_pin.png"
                },
                "resetusingOTP.imgUser": {
                    "src": "default_username.png"
                },
                "resetusingOTP.imgUserOutline": {
                    "src": "user_reset_password_frame.png"
                },
                "resetusingOTP.imgViewCVV": {
                    "src": "view.png"
                },
                "resetusingOTP.lblResetPasswordMsg": {
                    "centerX": "",
                    "left": "80dp",
                    "top": "0dp",
                    "width": "70%"
                },
                "resetusingOTP.lblWrongOTP": {
                    "left": "80dp"
                },
                "resetusingOTP.orline": {
                    "top": "6.5%"
                },
                "resetusingOTP.orline.imgOr": {
                    "src": "or_circle.png"
                },
                "resetusingOTP": {
                    "left": "0dp",
                    "width": "100%"
                },
                "resetusingOTP.rtxEnterCVVCode": {
                    "left": "50dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "resetusingOTP.tbxCVV": {
                    "height": "100%",
                    "width": "100%"
                },
                "resetusingOTPEnterOTP.flxCVV": {
                    "width": "68%"
                },
                "resetusingOTPEnterOTP.flxImageUser": {
                    "centerX": "",
                    "left": 0,
                    "top": "0%"
                },
                "resetusingOTPEnterOTP.flxImgTxt": {
                    "centerX": "50%",
                    "height": "130dp",
                    "width": "68%"
                },
                "resetusingOTPEnterOTP.flxResetBySecureCode": {
                    "height": "100dp",
                    "left": "78dp",
                    "top": "22dp",
                    "width": "80%"
                },
                "resetusingOTPEnterOTP.imgCVVOrOTP": {
                    "src": "send_pin.png"
                },
                "resetusingOTPEnterOTP.imgUser": {
                    "src": "default_username.png"
                },
                "resetusingOTPEnterOTP.imgUserOutline": {
                    "src": "user_reset_password_frame.png"
                },
                "resetusingOTPEnterOTP.imgViewCVV": {
                    "src": "view.png"
                },
                "resetusingOTPEnterOTP.orline.imgOr": {
                    "src": "or_circle.png"
                },
                "ResetOrEnroll": {
                    "height": "568dp"
                },
                "ResetOrEnroll.flxCVV": {
                    "top": "21dp"
                },
                "ResetOrEnroll.flxResetEnrollCVV": {
                    "height": "120dp",
                    "top": "5.5%"
                },
                "ResetOrEnroll.imgCVV": {
                    "src": "cvv_icon.png"
                },
                "ResetOrEnroll.imgUser": {
                    "src": "default_username.png"
                },
                "ResetOrEnroll.imgUserOutline": {
                    "src": "user_reset_password_frame.png"
                },
                "ResetOrEnroll.imgViewCVV": {
                    "src": "view.png"
                },
                "ResetOrEnroll.lblResetPassword": {
                    "text": "hg"
                },
                "ResetOrEnroll.lblWrongCvv": {
                    "text": "E"
                },
                "ResetOrEnroll.orline.imgOr": {
                    "src": "or_circle.png"
                },
                "ResetOrEnroll.rtxEnterCVV": {
                    "height": kony.flex.USE_PREFFERED_SIZE
                },
                "ResetOrEnroll.tbxCVV": {
                    "height": "100%",
                    "left": "0%",
                    "width": "100%"
                },
                "SignInAs": {
                    "height": "14%",
                    "top": "8.80%"
                },
                "SignInAs.fontIconOption": {
                    "centerY": "50%",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "0dp",
                    "text": "L",
                    "top": "",
                    "width": "100%"
                },
                "SignInAs.imgOptionKA": {
                    "src": "active_cvv_icon.png"
                },
                "SignInAs.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "SignInAs.rtxCVV": {
                    "left": "85dp",
                    "width": "61.90%"
                },
                "OrLineForSelectUsername.imgOr": {
                    "src": "or_circle.png"
                },
                "OrLineForSelectUsername": {
                    "centerX": "50%",
                    "height": "30dp",
                    "top": "5.28%",
                    "width": "85%"
                },
                "ResetMyPassword": {
                    "height": "14%",
                    "top": "5.28%",
                    "width": "85%"
                },
                "ResetMyPassword.fontIconOption": {
                    "centerY": "50%",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "0dp",
                    "maxHeight": "",
                    "text": "r",
                    "top": "",
                    "width": "100%"
                },
                "ResetMyPassword.imgOptionKA": {
                    "src": "active_send_pin.png"
                },
                "ResetMyPassword.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "newpasswordsetting.btnNext": {
                    "width": "68%"
                },
                "newpasswordsetting.flxMain": {
                    "height": "610dp"
                },
                "newpasswordsetting.flxMatchPassword": {
                    "width": "68%"
                },
                "newpasswordsetting.flxNewPassword": {
                    "width": "68%"
                },
                "newpasswordsetting.flxRulesPassword": {
                    "centerX": "50%",
                    "width": "68%"
                },
                "newpasswordsetting.imgPasswordMatched": {
                    "src": "success_icon.png"
                },
                "newpasswordsetting.imgRules": {
                    "src": "info.png"
                },
                "newpasswordsetting.imgUser": {
                    "src": "default_username.png"
                },
                "newpasswordsetting.imgUserOutline": {
                    "src": "user_reset_password_frame.png"
                },
                "newpasswordsetting.imgValidPassword": {
                    "src": "success_icon.png"
                },
                "newpasswordsetting.rtxRulesPassword": {
                    "height": kony.flex.USE_PREFFERED_SIZE
                },
                "MFAFlow": {
                    "height": "550dp"
                },
                "MFAFlow.btnProceed": {
                    "top": "30dp"
                },
                "MFAFlow.flxCheckboxPhone": {
                    "top": "10dp"
                },
                "MFAFlow.flxRegisteredPhone": {
                    "width": "100%"
                },
                "MFAFlow.imgCheckboxEmailId": {
                    "src": "checked_box.png"
                },
                "MFAFlow.imgCheckboxPhone": {
                    "src": "checked_box.png"
                },
                "MFAFlow.imgNewBrowserDetection": {
                    "src": "mfa_new_brower_detection.png"
                },
                "MFAFlow.lblCloseBracePhone": {
                    "top": -6
                },
                "MFAFlow.lblOpenBracePhone": {
                    "top": -7
                },
                "MFAFlow.lblRegisteredPhone": {
                    "top": 7
                },
                "MFAFlow.lblRegisteredPhoneNo": {
                    "top": 8
                },
                "MFA.imgNeweBrowserDetection": {
                    "src": "mfa_new_brower_detection.png"
                },
                "MFA.imgViewSACCode": {
                    "src": "view.png"
                },
                "passwordresetsuccess.imgTickFrame": {
                    "src": "user_verify_success_frame.png"
                },
                "passwordresetsuccess.imgUserwithoutTick": {
                    "src": "default_username.png"
                },
                "passwordresetsuccess.lblReserSuccessMsg": {
                    "width": "75%"
                },
                "passwordresetsuccess.orlineSuccess.imgOr": {
                    "src": "or_circle.png"
                },
                "blocked.imgTakeHelpTime": {
                    "src": "help_large.png"
                },
                "EnrollAlert.imgEnroll": {
                    "src": "server_error.png"
                },
                "EnrollPromptScreen": {
                    "height": "100%"
                },
                "EnrollPromptScreen.btnBackToLogin": {
                    "zIndex": 1
                },
                "EnrollPromptScreen.imgEnroll": {
                    "src": "server_error.png"
                },
                "logOutMsg.AlterneteActionsLoginNow": {
                    "left": "87dp",
                    "top": "430dp"
                },
                "logOutMsg.AlterneteActionsLoginNow.fontIconOption": {
                    "text": "V"
                },
                "logOutMsg.AlterneteActionsLoginNow.imgOptionKA": {
                    "src": "login_signin.png"
                },
                "logOutMsg.AlterneteActionsLoginNow.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "logOutMsg.imgLogoutSuccess": {
                    "centerY": "30.560000000000002%",
                    "height": "32dp",
                    "src": "success_green.png",
                    "width": "32dp"
                },
                "logOutMsg.lblLoggedOut": {
                    "centerY": "30.560000000000002%",
                    "left": "100dp",
                    "width": "65%"
                },
                "logOutMsg.lblSuccessIcon": {
                    "left": "87dp",
                    "top": "234dp",
                    "width": "70%"
                },
                "OTPModule.flxCVV": {
                    "width": "350dp"
                },
                "OTPModule.flxDescription": {
                    "centerX": ""
                },
                "OTPModule.flxImgTxt": {
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "OTPModule.flximgrtx": {
                    "centerX": "53%",
                    "height": "120dp",
                    "left": "80dp",
                    "top": "140dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "OTPModule.imgPhoneOTP": {
                    "src": "send_pin.png"
                },
                "OTPModule.imgRememberMe": {
                    "src": "unchecked_box.png"
                },
                "OTPModule.lblOTP": {
                    "centerX": "",
                    "height": "66dp"
                },
                "OTPModule.lblPhoneOTP": {
                    "centerX": ""
                },
                "OTPModule.lblResendOTPMessage": {
                    "bottom": "0%",
                    "text": "If you have not recieved the secure access code on your phone, please use the resend option.",
                    "top": "",
                    "width": "90%"
                },
                "OTPModule.lblWrongOTP": {
                    "text": "Sorry, this secure code is incorrect. Try again."
                },
                "OTPModule.rtxEnterCVVCode": {
                    "centerX": "54%",
                    "centerY": "30%"
                },
                "OTPModule.tbxCVV": {
                    "centerY": "53%"
                },
                "EnrollNow": {
                    "top": 0
                },
                "EnrollNow.fontIconOption": {
                    "centerY": ""
                },
                "EnrollNow.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "EnrollNow.lblInfo": {
                    "top": "5dp"
                },
                "EnrollNow.lblName": {
                    "text": "Label"
                },
                "lblSeperator.imgOr": {
                    "src": "or_circle.png"
                },
                "lblSeperator": {
                    "centerX": "50%",
                    "top": "20dp",
                    "width": "70%"
                },
                "ActivateNow": {
                    "top": 0
                },
                "ActivateNow.fontIconOption": {
                    "centerY": "",
                    "text": "c"
                },
                "ActivateNow.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "ActivateNow.lblInfo": {
                    "top": "0dp"
                },
                "enrollActivateComponent": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                },
                "TermsAndConditionLegalEntity.TermsAndConditionBody": {
                    "left": "0dp"
                },
                "TermsAndConditionLegalEntity": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "left": "0dp",
                    "top": "",
                    "width": "50%"
                },
                "TermsAndConditionLegalEntity.btnAcceptTAndC": {
                    "width": "30%"
                },
                "TermsAndConditionLegalEntity.btnCancelTAndC": {
                    "bottom": "0",
                    "right": "200dp",
                    "top": "",
                    "width": "30%"
                },
                "TermsAndConditionLegalEntity.flxLegalEntityBtn": {
                    "left": "0",
                    "top": "10dp"
                },
                "TermsAndConditionLegalEntity.flxTermsAndConditionDetails": {
                    "left": "0dp",
                    "top": "50dp"
                },
                "TermsAndConditionLegalEntity.flxTermsAndCondtionBody": {
                    "centerX": "50%",
                    "centerY": "",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "top": "0dp",
                    "width": "94%"
                },
                "TermsAndConditionLegalEntity.imgCloseTC": {
                    "src": "blue_close_icon.png"
                },
                "CustomFeedbackPopup": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "top": "",
                    "width": "60%"
                },
                "CustomFeedbackPopup.btnNo": {
                    "width": "40%"
                },
                "CustomFeedbackPopup.btnYes": {
                    "width": "40%"
                },
                "CustomFeedbackPopup.lblPopupMessage": {
                    "width": "90%"
                },
                "CustomFeedbackPopup.lblPopupmsg": {
                    "width": "90%"
                },
                "CustomChangeLanguagePopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "70%",
                    "zIndex": 1100
                },
                "CustomChangeLanguagePopup.btnYes": {
                    "left": ""
                },
                "CustomChangeLanguagePopup.lblHeading": {
                    "text": "Language"
                },
                "BrowserCheckPopup": {
                    "left": "0dp"
                },
                "DiffLanguagePopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "70%",
                    "zIndex": 1100
                },
                "DiffLanguagePopup.btnYes": {
                    "left": ""
                },
                "DiffLanguagePopup.lblHeading": {
                    "text": "Language"
                },
                "DiffLanguagePopup.lblPopupMessage": {
                    "text": "Are you sure you want to change the language?"
                }
            }
            this.add(tbxAutopopulateIssueFix, flxMain, flxLoading, flxLoadingChangeLanguage, flxFeedbackTakeSurvey, flxChangeLanguage, BrowserCheckPopup, flxDiffLanguage, flxBG);
        };
        return [{
            "addWidgets": addWidgetsfrmLogin,
            "enabledForIdleTimeout": false,
            "id": "frmLogin",
            "init": controller.AS_Form_g3cb493f4556464f917fe3924464890b,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_df5e80bd9a794da2b4e45afaa435f2e4,
            "preShow": function(eventobject) {
                controller.AS_Form_a00d69b6a6fe4e8f982b0de8159a5f3b(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "title": "Login",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 768, 1024, 1400],
            "onBreakpointChange": controller.AS_Form_c9b1074774c146c49c05e5e3e32857c9,
            "appName": "AuthenticationMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_c876da882d124a0aa022ca5dc35ec6d6,
            "retainScrollPosition": false
        }]
    }
});