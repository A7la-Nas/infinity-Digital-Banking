define("ArrangementsMA/MortgageServicesUIModule/frmSimulateEarlyPayOff", function() {
    return function(controller) {
        function addWidgetsfrmSimulateEarlyPayOff() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSKnFlxffffff",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "headermenu.imgUserReset": {
                        "src": "profileheadernew.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "topmenu.btnHamburger": {
                        "left": "83dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "54dp",
                "id": "flxHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 205,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeading.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "height": "24dp",
                "id": "lblHeader",
                "isVisible": true,
                "left": "6%",
                "skin": "sknSSPSemiBold42424220px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.SimulateEarlyPayOff\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBackNavigation = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20dp",
                "id": "flxBackNavigation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "49dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackNavigation.setDefaultUnit(kony.flex.DP);
            var flxImgBackNavigation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    },
                    "a11yLabel": "Back navigation link: Back to Accounts Overview"
                },
                "clipBounds": true,
                "focusSkin": "flxHoverSkinPointer",
                "height": "100%",
                "id": "flxImgBackNavigation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "360dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxImgBackNavigation.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20dp",
                "id": "imgBack",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknImgPointer5vs",
                "src": "arrow_left.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            var lblBack = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblBack",
                "isVisible": true,
                "left": "4dp",
                "skin": "sknSSP4176a415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgBackNavigation.add(imgBack, lblBack);
            flxBackNavigation.add(flxImgBackNavigation);
            flxHeading.add(lblHeader, flxBackNavigation);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "90%",
                "zIndex": 2,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxBackNavigationMobile = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "30dp",
                "id": "flxBackNavigationMobile",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackNavigationMobile.setDefaultUnit(kony.flex.DP);
            var flxImgBackNav = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    },
                    "a11yLabel": "Back navigation link: Back to Accounts Overview"
                },
                "clipBounds": true,
                "focusSkin": "flxHoverSkinPointer",
                "height": "100%",
                "id": "flxImgBackNav",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "360dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxImgBackNav.setDefaultUnit(kony.flex.DP);
            var imgBackMobile = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgBackMobile",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknImgPointer5vs",
                "src": "arrow_right_blue.png",
                "width": "17dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            var lblBackMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblBackMobile",
                "isVisible": true,
                "left": "14dp",
                "skin": "sknSSP4176a415px",
                "text": "Back to Mortgage Facility",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgBackNav.add(imgBackMobile, lblBackMobile);
            flxBackNavigationMobile.add(flxImgBackNav);
            var flxActionsMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxActionsMobile",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "72.5%",
                "skin": "slFbox",
                "top": "118dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActionsMobile.setDefaultUnit(kony.flex.DP);
            flxActionsMobile.add();
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "786dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var lblLoanDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblLoanDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLabelSSP42424217pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.loans.LoanDetails\")",
                "top": "30dp",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flx1 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flx1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx1.setDefaultUnit(kony.flex.DP);
            var lblFacility = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblFacility",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.Facility\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblFacilityValue",
                "isVisible": true,
                "left": "24dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Mortgage Facility 1 - 4556",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx1.add(lblFacility, lblFacilityValue);
            var flx2 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flx2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx2.setDefaultUnit(kony.flex.DP);
            var lblLoanAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblLoanAccount",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.LoanAccount\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoanAccountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblLoanAccountValue",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Primary Loan Account - 8760",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx2.add(lblLoanAccount, lblLoanAccountValue);
            var flx3 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flx3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx3.setDefaultUnit(kony.flex.DP);
            var lblCurrOutstandingBal = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblCurrOutstandingBal",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.CurrentOutstandingbalance\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrOutstandingBalValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblCurrOutstandingBalValue",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "150,054.00",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx3.add(lblCurrOutstandingBal, lblCurrOutstandingBalValue);
            var flx4 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flx4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx4.setDefaultUnit(kony.flex.DP);
            var lblCurrMaturityDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblCurrMaturityDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.CurrentMaturityDateWithColon\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrMaturityDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblCurrMaturityDateValue",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "12/02/2023",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx4.add(lblCurrMaturityDate, lblCurrMaturityDateValue);
            var lblHeader2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblHeader2",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLabelSSP42424217pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.Settlementfigure\")",
                "top": "10dp",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flx5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flx5",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx5.setDefaultUnit(kony.flex.DP);
            var lblPayOffSimDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblPayOffSimDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.PayoffsimulationDateWithColon\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayOffSimDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblPayOffSimDateValue",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "12/02/2023",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx5.add(lblPayOffSimDate, lblPayOffSimDateValue);
            var flx6 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flx6",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx6.setDefaultUnit(kony.flex.DP);
            var lbl6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl6",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.TotalPrincipalOutstandingAmount\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbl6Value = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl6Value",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$104.00",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx6.add(lbl6, lbl6Value);
            var flx7 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flx7",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx7.setDefaultUnit(kony.flex.DP);
            var lbl7 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl7",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.PrincipalInterestWithColon\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbl7Value = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl7Value",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$104.00",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx7.add(lbl7, lbl7Value);
            var flx8 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flx8",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx8.setDefaultUnit(kony.flex.DP);
            var lbl8 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl8",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.loans.Tax\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbl8Value = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl8Value",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$104.00",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx8.add(lbl8, lbl8Value);
            var flx9 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flx9",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx9.setDefaultUnit(kony.flex.DP);
            var lbl9 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl9",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.Earlypayofffee\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbl9Value = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl9Value",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$1500",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx9.add(lbl9, lbl9Value);
            var flx10 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flx10",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx10.setDefaultUnit(kony.flex.DP);
            var lbl10 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl10",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.Othercharges\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbl10Value = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl10Value",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$1500",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx10.add(lbl10, lbl10Value);
            var flx11 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flx11",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx11.setDefaultUnit(kony.flex.DP);
            var lbl11 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl11",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.Totaloutstandingamountpayable\")",
                "top": "0dp",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbl11Value = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lbl11Value",
                "isVisible": true,
                "left": "24dp",
                "skin": "sknSSPSemiBold42424220px",
                "text": "$150,250",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx11.add(lbl11, lbl11Value);
            var flxNote = new kony.ui.FlexContainer({
                "bottom": "20dp",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxNote",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "skbflx293276O5",
                "top": "0dp",
                "width": "746dp",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNote.setDefaultUnit(kony.flex.DP);
            var flxPoint1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPoint1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "706dp",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPoint1.setDefaultUnit(kony.flex.DP);
            var imgPoint1 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgPoint1",
                "isVisible": true,
                "left": "20dp",
                "src": "roadmap_info.png",
                "top": "20dp",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNote = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "id": "lblNote",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.PayoffNote\")",
                "top": "15dp",
                "width": "95%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPoint1.add(imgPoint1, lblNote);
            flxNote.add(flxPoint1);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxButtons = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "left": "0",
                "right": "20dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.BacktoFacilitydetails\")",
                "width": "250dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxButtons.add(btnContinue);
            flxContainer.add(lblLoanDetails, flx1, flx2, flx3, flx4, lblHeader2, flx5, flx6, flx7, flx8, flx9, flx10, flx11, flxNote, flxSeparator, flxButtons);
            var flxContact = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContact",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "24dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "390dp",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContact.setDefaultUnit(kony.flex.DP);
            var lblSupport1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "id": "lblSupport1",
                "isVisible": true,
                "left": "21dp",
                "right": "20dp",
                "skin": "ICSknbbSknLbl424242SSP17Px",
                "text": "To proceed with your Mortgage Payoff , please get in touch with our call centre or visit the nearest branch.",
                "top": "30dp",
                "width": "349dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPhone = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPhone",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "21dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "33dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhone.setDefaultUnit(kony.flex.DP);
            var imgPhone = new kony.ui.Image2({
                "height": "18dp",
                "id": "imgPhone",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "call.png",
                "top": "2dp",
                "width": "18dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPhNo1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "24dp",
                "id": "lblPhNo1",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLblSSP000d1915Px",
                "text": "+1 2876904387",
                "top": "0dp",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPhNo2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "height": "24dp",
                "id": "lblPhNo2",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLblSSP000d1915Px",
                "text": "+1 2876904387",
                "top": "20dp",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhone.add(imgPhone, lblPhNo1, lblPhNo2);
            var flxSupport2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSupport2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "21dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "41dp",
                "width": "94.70%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupport2.setDefaultUnit(kony.flex.DP);
            var imgSupport2 = new kony.ui.Image2({
                "height": "14dp",
                "id": "imgSupport2",
                "isVisible": true,
                "left": "0dp",
                "src": "message.png",
                "top": "3dp",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSupport2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "id": "lblSupport2",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknLblSSP004BB115Px",
                "text": "customer_support@infinitybank.com",
                "top": "0dp",
                "width": "88%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSupport2.add(imgSupport2, lblSupport2);
            var flxSupport3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSupport3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "21dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "19dp",
                "width": "95%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupport3.setDefaultUnit(kony.flex.DP);
            var imgSupport3 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgSupport3",
                "isVisible": true,
                "left": "0dp",
                "src": "location.png",
                "top": "0dp",
                "width": "18dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSupport3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "id": "lblSupport3",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknLblSSP000d1915Px",
                "text": "Theodore Lowe Ap #867-859 Sit Rd. Azusa New York - 39531United States-Theodore Lowe Ap #867-859 Sit Rd. Azusa New York - 39531United States-",
                "top": "0dp",
                "width": "321dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 50],
                "paddingInPixel": false
            }, {});
            flxSupport3.add(imgSupport3, lblSupport3);
            flxContact.add(lblSupport1, flxPhone, flxSupport2, flxSupport3);
            flxMain.add(flxBackNavigationMobile, flxActionsMobile, flxContainer, flxContact);
            flxMainWrapper.add(flxHeading, flxMain);
            var flxFooter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "height": "150dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "maxWidth": "1200dp",
                        "top": "75dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMainWrapper, flxFooter);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxPopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "800dp",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopupNew = new com.InfinityOLB.ArrangementsMA.CustomPopupNew({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopupNew",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ArrangementsMA",
                "viewType": "CustomPopupNew",
                "overrides": {
                    "CustomPopupNew": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var CustomPopupNew_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmSimulateEarlyPayOff"] && appConfig.componentMetadata["ArrangementsMA"]["frmSimulateEarlyPayOff"]["CustomPopupNew"]) || {};
            CustomPopupNew.lblMsg = CustomPopupNew_data.lblMsg || "Account Closure";
            flxPopup.add(CustomPopupNew);
            var flxDownloadTransaction = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxDownloadTransaction",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadTransaction.setDefaultUnit(kony.flex.DP);
            var downloadTransction = new com.InfinityOLB.ArrangementsMA.downloadTransction({
                "height": "100%",
                "id": "downloadTransction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0c69b7ae145714d",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "btnCancel": {
                        "centerX": "viz.val_cleared",
                        "left": "0",
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "btnClose": {
                        "bottom": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "top": "20dp"
                    },
                    "btnDownload": {
                        "centerX": "viz.val_cleared",
                        "height": "50dp",
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "downloadTransction": {
                        "width": "100%"
                    },
                    "flxButtons": {
                        "bottom": "viz.val_cleared",
                        "height": "80dp",
                        "responsiveConfig": {
                            "offset": {
                                "640": 0,
                                "1024": 0,
                                "1366": 0,
                                "1380": 0
                            },
                            "span": {
                                "640": 12,
                                "1024": 12,
                                "1366": 12,
                                "1380": 12
                            }
                        },
                        "reverseLayoutDirection": true,
                        "top": "0dp",
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "flxDisclaimer": {
                        "centerX": "viz.val_cleared",
                        "height": "100%",
                        "left": "20dp",
                        "top": "20dp",
                        "width": "460dp"
                    },
                    "flxDisclaimerInfo": {
                        "bottom": "viz.val_cleared",
                        "height": "80px"
                    },
                    "flxFromDate": {
                        "isVisible": false
                    },
                    "flxHeader": {
                        "height": "50px"
                    },
                    "flxInfoIcon": {
                        "height": "14dp",
                        "left": "10dp",
                        "top": "10dp",
                        "width": "14dp"
                    },
                    "flxMiddle": {
                        "height": "92dp",
                        "responsiveConfig": {
                            "offset": {
                                "640": 0,
                                "1024": 0,
                                "1366": 0,
                                "1380": 0
                            },
                            "span": {
                                "640": 12,
                                "1024": 12,
                                "1366": 12,
                                "1380": 12
                            }
                        },
                        "top": "20dp"
                    },
                    "flxPopup": {
                        "centerX": "47.58%",
                        "height": "310dp",
                        "top": "310px",
                        "width": "500dp"
                    },
                    "flxSelectFormat": {
                        "isVisible": false
                    },
                    "flxSeperator2": {
                        "top": "97%"
                    },
                    "flxToDate": {
                        "isVisible": false
                    },
                    "imgArrow": {
                        "centerY": 64,
                        "left": "viz.val_cleared",
                        "right": "11dp",
                        "top": "20dp",
                        "width": "15px"
                    },
                    "infoIcon": {
                        "height": "100%",
                        "left": 0,
                        "src": "exclaim_info.png",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "lblDisclaimer": {
                        "bottom": "8dp",
                        "height": "90%",
                        "isVisible": true,
                        "left": "32dp",
                        "top": "10dp",
                        "width": "412dp"
                    },
                    "lblHeader": {
                        "height": "20px",
                        "left": "20dp",
                        "text": "DOWNLOAD TRANSACTIONS",
                        "top": "20dp"
                    },
                    "lblPickDateRange": {
                        "isVisible": false
                    },
                    "lblSelectFormat": {
                        "left": "20dp",
                        "top": "25px"
                    },
                    "lblSelectImg": {
                        "isVisible": false,
                        "text": "O"
                    },
                    "lblTo": {
                        "isVisible": false
                    },
                    "lbxSelectFormat": {
                        "left": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "20dp",
                        "top": "20px",
                        "width": "230dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDownloadTransaction.add(downloadTransction);
            var flxClearSearchError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "150%",
                "id": "flxClearSearchError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClearSearchError.setDefaultUnit(kony.flex.DP);
            var flxClearSearchErrorPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "centerX": "47.58%",
                "clipBounds": true,
                "height": "269dp",
                "id": "flxClearSearchErrorPopup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": true,
                "skin": "Copysknflxffffff",
                "top": "330px",
                "width": "500dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClearSearchErrorPopup.setDefaultUnit(kony.flex.DP);
            var flxSEHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxSEHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSEHeader.setDefaultUnit(kony.flex.DP);
            var lblSEHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "20px",
                "id": "lblSEHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.settings.accessibility.error\")",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSEClose = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "btnSEClose",
                "isVisible": false,
                "right": "20dp",
                "skin": "btnOLBFontIcon15px",
                "text": "g",
                "width": "20px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSEHeader.add(lblSEHeader, btnSEClose);
            var flxSESeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSESeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSESeparator.setDefaultUnit(kony.flex.DP);
            flxSESeparator.add();
            var lblSEDisclaimer = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSEDisclaimer",
                "isVisible": true,
                "left": "23dp",
                "right": "20dp",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.deleteSearchErrorMsg\")",
                "top": "19dp",
                "width": "457dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSESeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSESeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "80dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSESeparator1.setDefaultUnit(kony.flex.DP);
            flxSESeparator1.add();
            var flxSEButton = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxSEButton",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSEButton.setDefaultUnit(kony.flex.DP);
            var btnSEOk = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnSEOk",
                "isVisible": true,
                "left": "0",
                "right": "20dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.ok\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnSECancel = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnSECancel",
                "isVisible": false,
                "right": "20dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxSEButton.add(btnSEOk, btnSECancel);
            flxClearSearchErrorPopup.add(flxSEHeader, flxSESeparator, lblSEDisclaimer, flxSESeparator1, flxSEButton);
            flxClearSearchError.add(flxClearSearchErrorPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yLabel": "Loading"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxInformationText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "131dp",
                "id": "flxInformationText",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "185dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "388dp",
                "width": "300dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformationText.setDefaultUnit(kony.flex.DP);
            var flxInformation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "46dp",
                "id": "flxInformation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformation.setDefaultUnit(kony.flex.DP);
            var lblInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblInfo",
                "isVisible": true,
                "left": "7.44%",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Payoff simulation date",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCross = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "btnCross",
                "isVisible": true,
                "right": "20dp",
                "skin": "btnOLBFontIcon15px",
                "text": "g",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInformation.add(lblInfo, btnCross);
            var flxSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            var flxAccountType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "85dp",
                "id": "flxAccountType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountType.setDefaultUnit(kony.flex.DP);
            var RichTextInfo = new kony.ui.RichText({
                "bottom": "20dp",
                "id": "RichTextInfo",
                "isVisible": true,
                "left": "20dp",
                "right": "20dp",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.PayoffsimulationDateInfo\")",
                "top": "5dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountType.add(RichTextInfo);
            flxInformationText.add(flxInformation, flxSeparator1, flxAccountType);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "customheader.topmenu.btnHamburger": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "segmentProps": []
                    },
                    "flxHeading": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigation": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNavigation": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "s018b592f2be4ccf98f6e95b092c9c4c",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgBack": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "segmentProps": []
                    },
                    "lblBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigationMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNav": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "s018b592f2be4ccf98f6e95b092c9c4c",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgBackMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackMobile": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxActionsMobile": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblLoanDetails": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flx1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblFacility": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblFacilityValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flx2": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblLoanAccount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblLoanAccountValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flx3": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBal": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBalValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flx4": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrMaturityDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrMaturityDateValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeader2": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flx5": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayOffSimDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayOffSimDateValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flx6": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lbl6": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbl6Value": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flx7": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lbl7": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbl7Value": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flx8": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lbl8": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbl8Value": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flx9": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lbl9": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbl9Value": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flx10": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lbl10": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbl10Value": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flx11": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lbl11": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lbl11Value": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxNote": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "segmentProps": []
                    },
                    "flxPoint1": {
                        "width": {
                            "type": "string",
                            "value": "530dp"
                        },
                        "segmentProps": []
                    },
                    "imgPoint1": {
                        "segmentProps": []
                    },
                    "lblNote": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "i18n_text": "i18n.Accounts.PayoffNote",
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "327dp"
                        },
                        "segmentProps": []
                    },
                    "flxContact": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100.25%"
                        },
                        "segmentProps": []
                    },
                    "lblSupport1": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxPhone": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgPhone": {
                        "segmentProps": []
                    },
                    "lblPhNo1": {
                        "segmentProps": []
                    },
                    "lblPhNo2": {
                        "segmentProps": []
                    },
                    "flxSupport2": {
                        "top": {
                            "type": "string",
                            "value": "41dp"
                        },
                        "segmentProps": []
                    },
                    "imgSupport2": {
                        "segmentProps": []
                    },
                    "lblSupport2": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSupport3": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgSupport3": {
                        "segmentProps": []
                    },
                    "lblSupport3": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupNew": {
                        "segmentProps": []
                    },
                    "flxDownloadTransaction": {
                        "height": {
                            "type": "string",
                            "value": "250%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnCancel": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnDownload": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "82%"
                        },
                        "width": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimerInfo": {
                        "height": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.infoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lbxSelectFormat": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearchError": {
                        "height": {
                            "type": "string",
                            "value": "150%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearchErrorPopup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "390dp"
                        },
                        "segmentProps": []
                    },
                    "btnSEClose": {
                        "segmentProps": []
                    },
                    "lblSEDisclaimer": {
                        "skin": "sknLblSSP42424213px",
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxSEButton": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnSEOk": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnSECancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxInformationText": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "36dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "273dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.btnHamburger": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigation": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxImgBackNavigation": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "728dp"
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigationMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNav": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackMobile": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxActionsMobile": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "727dp"
                        },
                        "segmentProps": []
                    },
                    "lblLoanDetails": {
                        "segmentProps": []
                    },
                    "flx1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblFacility": {
                        "segmentProps": []
                    },
                    "lblFacilityValue": {
                        "segmentProps": []
                    },
                    "flx2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblLoanAccount": {
                        "segmentProps": []
                    },
                    "lblLoanAccountValue": {
                        "segmentProps": []
                    },
                    "flx3": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBal": {
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBalValue": {
                        "segmentProps": []
                    },
                    "flx4": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCurrMaturityDate": {
                        "segmentProps": []
                    },
                    "lblCurrMaturityDateValue": {
                        "segmentProps": []
                    },
                    "lblHeader2": {
                        "segmentProps": []
                    },
                    "flx5": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblPayOffSimDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblPayOffSimDateValue": {
                        "segmentProps": []
                    },
                    "flx6": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl6": {
                        "segmentProps": []
                    },
                    "lbl6Value": {
                        "segmentProps": []
                    },
                    "flx7": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl7": {
                        "segmentProps": []
                    },
                    "lbl7Value": {
                        "segmentProps": []
                    },
                    "flx8": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl8": {
                        "segmentProps": []
                    },
                    "lbl8Value": {
                        "segmentProps": []
                    },
                    "flx9": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl9": {
                        "segmentProps": []
                    },
                    "lbl9Value": {
                        "segmentProps": []
                    },
                    "flx10": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl10": {
                        "segmentProps": []
                    },
                    "lbl10Value": {
                        "segmentProps": []
                    },
                    "flx11": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl11": {
                        "segmentProps": []
                    },
                    "lbl11Value": {
                        "segmentProps": []
                    },
                    "flxNote": {
                        "width": {
                            "type": "string",
                            "value": "686dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPoint1": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgPoint1": {
                        "segmentProps": []
                    },
                    "lblNote": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "segmentProps": []
                    },
                    "flxContact": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblSupport1": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "702dp"
                        },
                        "segmentProps": []
                    },
                    "flxPhone": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgPhone": {
                        "segmentProps": []
                    },
                    "lblPhNo1": {
                        "segmentProps": []
                    },
                    "lblPhNo2": {
                        "segmentProps": []
                    },
                    "flxSupport2": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "41dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgSupport2": {
                        "segmentProps": []
                    },
                    "lblSupport2": {
                        "segmentProps": []
                    },
                    "flxSupport3": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgSupport3": {
                        "segmentProps": []
                    },
                    "lblSupport3": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupNew": {
                        "height": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnClose": {
                        "text": "",
                        "segmentProps": []
                    },
                    "downloadTransction.btnDownload": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "78%"
                        },
                        "width": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimerInfo": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "97px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.infoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearchError": {
                        "segmentProps": []
                    },
                    "flxClearSearchErrorPopup": {
                        "segmentProps": []
                    },
                    "lblSEDisclaimer": {
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxSEButton": {
                        "segmentProps": []
                    },
                    "btnSEOk": {
                        "segmentProps": []
                    },
                    "flxInformationText": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxBackNavigation": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "58%"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNavigation": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblBack": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "flxBackNavigationMobile": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "58%"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNav": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblBackMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxActionsMobile": {
                        "top": {
                            "type": "string",
                            "value": "106dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "segmentProps": []
                    },
                    "lblLoanDetails": {
                        "segmentProps": []
                    },
                    "flx1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblFacility": {
                        "segmentProps": []
                    },
                    "lblFacilityValue": {
                        "segmentProps": []
                    },
                    "flx2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblLoanAccount": {
                        "segmentProps": []
                    },
                    "lblLoanAccountValue": {
                        "segmentProps": []
                    },
                    "flx3": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBal": {
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBalValue": {
                        "segmentProps": []
                    },
                    "flx4": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCurrMaturityDate": {
                        "segmentProps": []
                    },
                    "lblCurrMaturityDateValue": {
                        "segmentProps": []
                    },
                    "lblHeader2": {
                        "segmentProps": []
                    },
                    "flx5": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblPayOffSimDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblPayOffSimDateValue": {
                        "segmentProps": []
                    },
                    "flx6": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl6": {
                        "segmentProps": []
                    },
                    "lbl6Value": {
                        "segmentProps": []
                    },
                    "flx7": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl7": {
                        "segmentProps": []
                    },
                    "lbl7Value": {
                        "segmentProps": []
                    },
                    "flx8": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl8": {
                        "segmentProps": []
                    },
                    "lbl8Value": {
                        "segmentProps": []
                    },
                    "flx9": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl9": {
                        "segmentProps": []
                    },
                    "lbl9Value": {
                        "segmentProps": []
                    },
                    "flx10": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl10": {
                        "segmentProps": []
                    },
                    "lbl10Value": {
                        "segmentProps": []
                    },
                    "flx11": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lbl11": {
                        "segmentProps": []
                    },
                    "lbl11Value": {
                        "segmentProps": []
                    },
                    "flxNote": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPoint1": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgPoint1": {
                        "segmentProps": []
                    },
                    "lblNote": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "segmentProps": []
                    },
                    "flxContact": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblSupport1": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPhone": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgPhone": {
                        "segmentProps": []
                    },
                    "lblPhNo1": {
                        "segmentProps": []
                    },
                    "lblPhNo2": {
                        "segmentProps": []
                    },
                    "flxSupport2": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgSupport2": {
                        "segmentProps": []
                    },
                    "lblSupport2": {
                        "segmentProps": []
                    },
                    "flxSupport3": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgSupport3": {
                        "segmentProps": []
                    },
                    "lblSupport3": {
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "78%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimerInfo": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "325dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.infoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearchError": {
                        "segmentProps": []
                    },
                    "flxClearSearchErrorPopup": {
                        "segmentProps": []
                    },
                    "lblSEDisclaimer": {
                        "i18n_text": "i18n.ViewStatements.DisclaimerInfo",
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxSEButton": {
                        "segmentProps": []
                    },
                    "btnSEOk": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheader.topmenu.btnHamburger": {
                        "left": {
                            "type": "string",
                            "value": "-12dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxActionsMobile": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "118dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "segmentProps": []
                    },
                    "flx1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx3": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx4": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx5": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx6": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx7": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx8": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx9": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx10": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx11": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxNote": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPoint1": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "segmentProps": []
                    },
                    "flxContact": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPhone": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxSupport2": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxSupport3": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimerInfo": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "325dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearchError": {
                        "segmentProps": []
                    },
                    "flxClearSearchErrorPopup": {
                        "segmentProps": []
                    },
                    "btnSEClose": {
                        "segmentProps": []
                    },
                    "lblSEDisclaimer": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxSEButton": {
                        "segmentProps": []
                    },
                    "btnSEOk": {
                        "segmentProps": []
                    },
                    "btnSECancel": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.headermenu.imgUserReset": {
                    "src": "profileheadernew.png"
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheader.topmenu.btnHamburger": {
                    "left": "83dp"
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "150dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "maxWidth": "1200dp",
                    "top": "75dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopupNew": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": ""
                },
                "downloadTransction.btnCancel": {
                    "centerX": "",
                    "left": "0",
                    "right": "20dp",
                    "width": "150dp"
                },
                "downloadTransction.btnClose": {
                    "bottom": "",
                    "left": "",
                    "right": "20dp",
                    "top": "20dp"
                },
                "downloadTransction.btnDownload": {
                    "centerX": "",
                    "height": "50dp",
                    "left": "",
                    "right": "20dp",
                    "width": "150dp"
                },
                "downloadTransction": {
                    "width": "100%"
                },
                "downloadTransction.flxButtons": {
                    "bottom": "",
                    "height": "80dp",
                    "reverseLayoutDirection": true,
                    "top": "0dp",
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "downloadTransction.flxDisclaimer": {
                    "centerX": "",
                    "height": "100%",
                    "left": "20dp",
                    "top": "20dp",
                    "width": "460dp"
                },
                "downloadTransction.flxDisclaimerInfo": {
                    "bottom": "",
                    "height": "80px"
                },
                "downloadTransction.flxHeader": {
                    "height": "50px"
                },
                "downloadTransction.flxInfoIcon": {
                    "height": "14dp",
                    "left": "10dp",
                    "top": "10dp",
                    "width": "14dp"
                },
                "downloadTransction.flxMiddle": {
                    "height": "92dp",
                    "top": "20dp"
                },
                "downloadTransction.flxPopup": {
                    "centerX": "47.58%",
                    "height": "310dp",
                    "top": "310px",
                    "width": "500dp"
                },
                "downloadTransction.flxSeperator2": {
                    "top": "97%"
                },
                "downloadTransction.imgArrow": {
                    "centerY": 64,
                    "left": "",
                    "right": "11dp",
                    "top": "20dp",
                    "width": "15px"
                },
                "downloadTransction.infoIcon": {
                    "height": "100%",
                    "left": 0,
                    "src": "exclaim_info.png",
                    "top": "0dp",
                    "width": "100%"
                },
                "downloadTransction.lblDisclaimer": {
                    "bottom": "8dp",
                    "height": "90%",
                    "left": "32dp",
                    "top": "10dp",
                    "width": "412dp"
                },
                "downloadTransction.lblHeader": {
                    "height": "20px",
                    "left": "20dp",
                    "text": "DOWNLOAD TRANSACTIONS",
                    "top": "20dp"
                },
                "downloadTransction.lblSelectFormat": {
                    "left": "20dp",
                    "top": "25px"
                },
                "downloadTransction.lblSelectImg": {
                    "text": "O"
                },
                "downloadTransction.lbxSelectFormat": {
                    "left": "",
                    "minWidth": "",
                    "right": "20dp",
                    "top": "20px",
                    "width": "230dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxLogout, flxPopup, flxDownloadTransaction, flxClearSearchError, flxLoading, flxInformationText);
        };
        return [{
            "addWidgets": addWidgetsfrmSimulateEarlyPayOff,
            "enabledForIdleTimeout": true,
            "id": "frmSimulateEarlyPayOff",
            "init": controller.AS_Form_fa90aa5f3d09486f976b738bcfacc8af,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_jd1aab1dbcf849659ec5b1b6f1619a9b,
            "preShow": function(eventobject) {
                controller.AS_Form_hdfc7a0933934ad5a0e62f4b928e22ca(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Simulate Early payoff",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_afc599f5f0094e4a94192fc597e85d7b,
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": true
        }]
    }
});