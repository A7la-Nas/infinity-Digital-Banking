define("ApprovalRequestMA/ApprovalsReqUIModule/frmApprovalAcknowledgement", function() {
    return function(controller) {
        function addWidgetsfrmApprovalAcknowledgement() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderMain.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "headermenu": {
                        "height": "70dp",
                        "right": "6%",
                        "top": "0dp",
                        "width": "94%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderMain.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": 310,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            var flxOverdraftWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxOverdraftWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverdraftWarning.setDefaultUnit(kony.flex.DP);
            var imgOverDraft = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgOverDraft",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverdraftWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOverdraftWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.OverDraftWarning\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOverdraftWarning.add(imgOverDraft, lblOverdraftWarning, imgCloseWarning);
            var flxOutageWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxOutageWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOutageWarning.setDefaultUnit(kony.flex.DP);
            var imgInfoIconWarning = new kony.ui.Image2({
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgInfoIconWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutageWarning = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblOutageWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "13dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseOutageWarning = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgCloseOutageWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOutageWarning.add(imgInfoIconWarning, lblOutageWarning, imgCloseOutageWarning);
            flxMainWrapper.add(flxDowntimeWarning, flxOverdraftWarning, flxOutageWarning);
            var flxskncontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "-10dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "0",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            var flxContentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxContentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "1366dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainer.setDefaultUnit(kony.flex.DP);
            var flxContentHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "60dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "120dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.Acknowledgement\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentHeader.add(lblContentHeader);
            var flxAcknowledgementContainer = new kony.ui.FlexContainer({
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "110dp",
                "id": "flxAcknowledgementContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgement = new com.InfinityOLB.Resources.flxAcknowledgement({
                "centerY": "50%",
                "height": "100%",
                "id": "flxAcknowledgement",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ResourcesMA",
                "viewType": "flxAcknowledgement",
                "overrides": {
                    "flxTickImage": {
                        "width": "4.44%"
                    },
                    "rTextSuccess": {
                        "text": "Your transaction has been successfully submitted\nReference Number 45423792753"
                    },
                    "flxAcknowledgement": {
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAcknowledgement_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmApprovalAcknowledgement"] && appConfig.componentMetadata["ResourcesMA"]["frmApprovalAcknowledgement"]["flxAcknowledgement"]) || {};
            var flxAcknowledgementNew = new com.InfinityOLB.Resources.flxAcknowledgementNew({
                "height": "100%",
                "id": "flxAcknowledgementNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxAckContainer": {
                        "height": "115dp"
                    },
                    "flxAcknowledgementNew": {
                        "left": "0dp",
                        "width": "100%"
                    },
                    "flxImgPrint": {
                        "isVisible": false
                    },
                    "flxImgdownload": {
                        "isVisible": false
                    },
                    "flxTickImage": {
                        "height": "50dp"
                    },
                    "imgDownload": {
                        "src": "bbdownloadicon.png"
                    },
                    "imgPrint": {
                        "src": "bbprint.png"
                    },
                    "imgTick": {
                        "src": "bulk_billpay_success.png",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {
                    "imgTick": {
                        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS
                    }
                }
            }, {
                "overrides": {}
            });
            flxAcknowledgementContainer.add(flxAcknowledgement, flxAcknowledgementNew);
            var flxAcknowledgementMobile = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxAcknowledgementMobile",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementMobile.setDefaultUnit(kony.flex.DP);
            var lblAcknowledgement = new kony.ui.Label({
                "id": "lblAcknowledgement",
                "isVisible": true,
                "left": "0",
                "skin": "defLabel",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperatorMob = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSeperatorMob",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorMob.setDefaultUnit(kony.flex.DP);
            flxSeperatorMob.add();
            var lblSuccessMessage = new kony.ui.Label({
                "id": "lblSuccessMessage",
                "isVisible": true,
                "left": "0",
                "skin": "defLabel",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTickImage = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxTickImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTickImage.setDefaultUnit(kony.flex.DP);
            var imgTick = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgTick",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTickImage.add(imgTick);
            var flxRequestId = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxRequestId",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestId.setDefaultUnit(kony.flex.DP);
            var lblRequestId = new kony.ui.Label({
                "id": "lblRequestId",
                "isVisible": true,
                "left": "0",
                "skin": "defLabel",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRequestIdValue = new kony.ui.Label({
                "id": "lblRequestIdValue",
                "isVisible": true,
                "left": "0",
                "skin": "defLabel",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRequestId.add(lblRequestId, lblRequestIdValue);
            flxAcknowledgementMobile.add(lblAcknowledgement, flxSeperatorMob, lblSuccessMessage, flxTickImage, flxRequestId);
            var flxAuthenticator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "24dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAuthenticator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "4dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAuthenticator.setDefaultUnit(kony.flex.DP);
            var OTPAuthenticator = new com.InfinityOLB.ApprovalRequestMA.OTPAuthenticator({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "OTPAuthenticator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadowBlur8Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "OTPAuthenticator": {
                        "isVisible": true
                    },
                    "OTPCode.imgViewCVVCode": {
                        "src": "view.png"
                    },
                    "OTPCode.imgWarning": {
                        "src": "error_yellow.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAuthenticator.add(OTPAuthenticator);
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var flxContentContainerLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContentContainerLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "83dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "782dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainerLeft.setDefaultUnit(kony.flex.DP);
            var flxSummaryWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSummaryWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryWrapper.setDefaultUnit(kony.flex.DP);
            var flxSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "8dp",
                "isModalContainer": false,
                "right": "8dp",
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummary.setDefaultUnit(kony.flex.DP);
            var flxSummaryTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxSummaryTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "755dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryTitle.setDefaultUnit(kony.flex.DP);
            var lblSummaryTitle = new kony.ui.Label({
                "height": "20dp",
                "id": "lblSummaryTitle",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.summary\")",
                "top": "7dp",
                "width": "63dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSummaryTitle.add(lblSummaryTitle);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxSummaryDetailsWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSummaryDetailsWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryDetailsWrapper.setDefaultUnit(kony.flex.DP);
            var flxSummaryDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSummaryDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20dp",
                "top": "0dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryDetails.setDefaultUnit(kony.flex.DP);
            var flxTotal = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "17dp",
                "id": "flxTotal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotal.setDefaultUnit(kony.flex.DP);
            var lblTotalRequest = new kony.ui.Label({
                "height": "17dp",
                "id": "lblTotalRequest",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ApprovalRequests.AckNumRequest\")",
                "top": "0",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalRequestVal = new kony.ui.Label({
                "height": "17dp",
                "id": "lblTotalRequestVal",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblSSP46464615pxbold",
                "top": "0",
                "width": "68%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotal.add(lblTotalRequest, lblTotalRequestVal);
            var flxTotalApproved = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "18dp",
                "id": "flxTotalApproved",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalApproved.setDefaultUnit(kony.flex.DP);
            var lblTotalApproved = new kony.ui.Label({
                "height": "17dp",
                "id": "lblTotalApproved",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ApprovalRequests.AckTotalApproved\")",
                "top": "0",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalApprovedVal = new kony.ui.Label({
                "height": "18dp",
                "id": "lblTotalApprovedVal",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblSSP46464615pxbold",
                "top": "0",
                "width": "68%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalApproved.add(lblTotalApproved, lblTotalApprovedVal);
            var flxTotalRejected = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "18dp",
                "id": "flxTotalRejected",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalRejected.setDefaultUnit(kony.flex.DP);
            var lblTotalRejected = new kony.ui.Label({
                "height": "17dp",
                "id": "lblTotalRejected",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ApprovalRequests.AckTotalRejected\")",
                "top": "0",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalRejectedVal = new kony.ui.Label({
                "height": "17dp",
                "id": "lblTotalRejectedVal",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblSSP46464615pxbold",
                "top": "0",
                "width": "68%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalRejected.add(lblTotalRejected, lblTotalRejectedVal);
            var flxSkipped = new kony.ui.FlexContainer({
                "bottom": "15dp",
                "clipBounds": false,
                "height": "18dp",
                "id": "flxSkipped",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSkipped.setDefaultUnit(kony.flex.DP);
            var lblSkipped = new kony.ui.Label({
                "height": "17dp",
                "id": "lblSkipped",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ApprovalRequests.AckSkipped\")",
                "top": "0",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSkippedVal = new kony.ui.Label({
                "height": "17dp",
                "id": "lblSkippedVal",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblSSP46464615pxbold",
                "top": "0",
                "width": "68%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSkipped.add(lblSkipped, lblSkippedVal);
            flxSummaryDetails.add(flxTotal, flxTotalApproved, flxTotalRejected, flxSkipped);
            flxSummaryDetailsWrapper.add(flxSummaryDetails);
            flxSummary.add(flxSummaryTitle, flxSeparator, flxSummaryDetailsWrapper);
            flxSummaryWrapper.add(flxSummary);
            var flxTransactionDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "focusSkin": "slfBoxffffffB1R5",
                "id": "flxTransactionDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionDetails.setDefaultUnit(kony.flex.DP);
            var segTransactionDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgStatus": "success.png",
                    "lblAccNum": "Account Number:",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "Amount:",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "Benificiary:",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "From:",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceID": "Reference ID:",
                    "lblReferenceIDValue": "12637569",
                    "lblReqSum": "Label",
                    "lblStatus": "Status:",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "Transaction Type:",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "View Details"
                }],
                "groupCells": false,
                "id": "segTransactionDetails",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "segTransparant",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxAckSummary"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccNum": "flxAccNum",
                    "flxAckSummary": "flxAckSummary",
                    "flxAmount": "flxAmount",
                    "flxBeneficiary": "flxBeneficiary",
                    "flxFrom": "flxFrom",
                    "flxHeader": "flxHeader",
                    "flxMain": "flxMain",
                    "flxReferenceID": "flxReferenceID",
                    "flxSeparator": "flxSeparator",
                    "flxStatus": "flxStatus",
                    "flxTemp1": "flxTemp1",
                    "flxTemp2": "flxTemp2",
                    "flxTemp3": "flxTemp3",
                    "flxTransactionType": "flxTransactionType",
                    "flxViewDetails": "flxViewDetails",
                    "imgStatus": "imgStatus",
                    "lblAccNum": "lblAccNum",
                    "lblAccNumValue": "lblAccNumValue",
                    "lblAmount": "lblAmount",
                    "lblAmountValue": "lblAmountValue",
                    "lblBeneficiary": "lblBeneficiary",
                    "lblBeneficiaryValue": "lblBeneficiaryValue",
                    "lblFrom": "lblFrom",
                    "lblFromValue": "lblFromValue",
                    "lblReferenceID": "lblReferenceID",
                    "lblReferenceIDValue": "lblReferenceIDValue",
                    "lblReqSum": "lblReqSum",
                    "lblStatus": "lblStatus",
                    "lblStatusValue": "lblStatusValue",
                    "lblTemp1": "lblTemp1",
                    "lblTemp1Val": "lblTemp1Val",
                    "lblTemp2": "lblTemp2",
                    "lblTemp2Val": "lblTemp2Val",
                    "lblTemp3": "lblTemp3",
                    "lblTemp3Val": "lblTemp3Val",
                    "lblTransactionType": "lblTransactionType",
                    "lblTransactionValue": "lblTransactionValue",
                    "lblViewDetails": "lblViewDetails"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTransactionDetails.add(segTransactionDetails);
            var flxTransactionDetailsMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTransactionDetailsMobile",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionDetailsMobile.setDefaultUnit(kony.flex.DP);
            var segTransactionDetailsMobile = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgStatus": "success.png",
                    "lblAccNum": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Amount\")",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.BeneficiaryWithColon\")",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceId": "kony.i18n.getLocalizedString(\"kony.mb.transfers.ReferenceID\")",
                    "lblReferenceIdValue": "12637569",
                    "lblReqSum": "Request 1 Summary",
                    "lblStatus": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "kony.i18n.getLocalizedString(\"i18n.stopChecks.TransactionType:\")",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")"
                }, {
                    "imgStatus": "success.png",
                    "lblAccNum": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Amount\")",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.BeneficiaryWithColon\")",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceId": "kony.i18n.getLocalizedString(\"kony.mb.transfers.ReferenceID\")",
                    "lblReferenceIdValue": "12637569",
                    "lblReqSum": "Request 1 Summary",
                    "lblStatus": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "kony.i18n.getLocalizedString(\"i18n.stopChecks.TransactionType:\")",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")"
                }, {
                    "imgStatus": "success.png",
                    "lblAccNum": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Amount\")",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.BeneficiaryWithColon\")",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceId": "kony.i18n.getLocalizedString(\"kony.mb.transfers.ReferenceID\")",
                    "lblReferenceIdValue": "12637569",
                    "lblReqSum": "Request 1 Summary",
                    "lblStatus": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "kony.i18n.getLocalizedString(\"i18n.stopChecks.TransactionType:\")",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")"
                }, {
                    "imgStatus": "success.png",
                    "lblAccNum": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Amount\")",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.BeneficiaryWithColon\")",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceId": "kony.i18n.getLocalizedString(\"kony.mb.transfers.ReferenceID\")",
                    "lblReferenceIdValue": "12637569",
                    "lblReqSum": "Request 1 Summary",
                    "lblStatus": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "kony.i18n.getLocalizedString(\"i18n.stopChecks.TransactionType:\")",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")"
                }, {
                    "imgStatus": "success.png",
                    "lblAccNum": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Amount\")",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.BeneficiaryWithColon\")",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceId": "kony.i18n.getLocalizedString(\"kony.mb.transfers.ReferenceID\")",
                    "lblReferenceIdValue": "12637569",
                    "lblReqSum": "Request 1 Summary",
                    "lblStatus": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "kony.i18n.getLocalizedString(\"i18n.stopChecks.TransactionType:\")",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")"
                }, {
                    "imgStatus": "success.png",
                    "lblAccNum": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Amount\")",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.BeneficiaryWithColon\")",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceId": "kony.i18n.getLocalizedString(\"kony.mb.transfers.ReferenceID\")",
                    "lblReferenceIdValue": "12637569",
                    "lblReqSum": "Request 1 Summary",
                    "lblStatus": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "kony.i18n.getLocalizedString(\"i18n.stopChecks.TransactionType:\")",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")"
                }, {
                    "imgStatus": "success.png",
                    "lblAccNum": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Amount\")",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.BeneficiaryWithColon\")",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceId": "kony.i18n.getLocalizedString(\"kony.mb.transfers.ReferenceID\")",
                    "lblReferenceIdValue": "12637569",
                    "lblReqSum": "Request 1 Summary",
                    "lblStatus": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "kony.i18n.getLocalizedString(\"i18n.stopChecks.TransactionType:\")",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")"
                }, {
                    "imgStatus": "success.png",
                    "lblAccNum": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Amount\")",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.BeneficiaryWithColon\")",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceId": "kony.i18n.getLocalizedString(\"kony.mb.transfers.ReferenceID\")",
                    "lblReferenceIdValue": "12637569",
                    "lblReqSum": "Request 1 Summary",
                    "lblStatus": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "kony.i18n.getLocalizedString(\"i18n.stopChecks.TransactionType:\")",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")"
                }, {
                    "imgStatus": "success.png",
                    "lblAccNum": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Amount\")",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.BeneficiaryWithColon\")",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceId": "kony.i18n.getLocalizedString(\"kony.mb.transfers.ReferenceID\")",
                    "lblReferenceIdValue": "12637569",
                    "lblReqSum": "Request 1 Summary",
                    "lblStatus": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "kony.i18n.getLocalizedString(\"i18n.stopChecks.TransactionType:\")",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")"
                }, {
                    "imgStatus": "success.png",
                    "lblAccNum": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                    "lblAccNumValue": "1212345",
                    "lblAmount": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Amount\")",
                    "lblAmountValue": "5000",
                    "lblBeneficiary": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.BeneficiaryWithColon\")",
                    "lblBeneficiaryValue": "John Adams",
                    "lblFrom": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "lblFromValue": "Current Account 2439908",
                    "lblReferenceId": "kony.i18n.getLocalizedString(\"kony.mb.transfers.ReferenceID\")",
                    "lblReferenceIdValue": "12637569",
                    "lblReqSum": "Request 1 Summary",
                    "lblStatus": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.Status:\")",
                    "lblStatusValue": "Approved",
                    "lblTemp1": "Label",
                    "lblTemp1Val": "Label",
                    "lblTemp2": "Label",
                    "lblTemp2Val": "Label",
                    "lblTemp3": "Label",
                    "lblTemp3Val": "Label",
                    "lblTransactionType": "kony.i18n.getLocalizedString(\"i18n.stopChecks.TransactionType:\")",
                    "lblTransactionValue": "Ach Payment",
                    "lblViewDetails": "kony.i18n.getLocalizedString(\"i18n.common.ViewDetails\")"
                }],
                "groupCells": false,
                "id": "segTransactionDetailsMobile",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxACKSummaryMobile"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxACKSummaryMobile": "flxACKSummaryMobile",
                    "flxAccNum": "flxAccNum",
                    "flxAmount": "flxAmount",
                    "flxBeneficiary": "flxBeneficiary",
                    "flxFrom": "flxFrom",
                    "flxHeader": "flxHeader",
                    "flxMain": "flxMain",
                    "flxReferenceId": "flxReferenceId",
                    "flxSeparator": "flxSeparator",
                    "flxStatus": "flxStatus",
                    "flxTemp1": "flxTemp1",
                    "flxTemp2": "flxTemp2",
                    "flxTemp3": "flxTemp3",
                    "flxTransactionType": "flxTransactionType",
                    "flxViewDetails": "flxViewDetails",
                    "imgStatus": "imgStatus",
                    "lblAccNum": "lblAccNum",
                    "lblAccNumValue": "lblAccNumValue",
                    "lblAmount": "lblAmount",
                    "lblAmountValue": "lblAmountValue",
                    "lblBeneficiary": "lblBeneficiary",
                    "lblBeneficiaryValue": "lblBeneficiaryValue",
                    "lblFrom": "lblFrom",
                    "lblFromValue": "lblFromValue",
                    "lblReferenceId": "lblReferenceId",
                    "lblReferenceIdValue": "lblReferenceIdValue",
                    "lblReqSum": "lblReqSum",
                    "lblStatus": "lblStatus",
                    "lblStatusValue": "lblStatusValue",
                    "lblTemp1": "lblTemp1",
                    "lblTemp1Val": "lblTemp1Val",
                    "lblTemp2": "lblTemp2",
                    "lblTemp2Val": "lblTemp2Val",
                    "lblTemp3": "lblTemp3",
                    "lblTemp3Val": "lblTemp3Val",
                    "lblTransactionType": "lblTransactionType",
                    "lblTransactionValue": "lblTransactionValue",
                    "lblViewDetails": "lblViewDetails"
                },
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTransactionDetailsMobile.add(segTransactionDetailsMobile);
            var flxButton = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxButton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "11dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButton.setDefaultUnit(kony.flex.DP);
            var btnBackToPending = new kony.ui.Button({
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnBackToPending",
                "isVisible": true,
                "left": "2dp",
                "right": "2dp",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "text": "Back To Pending",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [20, 4, 20, 4],
                "paddingInPixel": true
            }, {});
            flxButton.add(btnBackToPending);
            flxContentContainerLeft.add(flxSummaryWrapper, flxTransactionDetails, flxTransactionDetailsMobile, flxButton);
            var flxBackToPendingTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxBackToPendingTop",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "55dp",
                "width": "185dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackToPendingTop.setDefaultUnit(kony.flex.DP);
            var imgBackToPendingTop = new kony.ui.Image2({
                "centerY": "50%",
                "height": "19dp",
                "id": "imgBackToPendingTop",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "arrow_left.png",
                "top": "10dp",
                "width": "5dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBackToPendingTop = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "lblBackToPendingTop",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknSSP4176a415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.approval.backToPending\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackToPendingTop.add(imgBackToPendingTop, lblBackToPendingTop);
            var flxContentContainerRight = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "800dp",
                "id": "flxContentContainerRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "390dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainerRight.setDefaultUnit(kony.flex.DP);
            var flxApprovalRoadMapContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovalRoadMapContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8dp",
                "isModalContainer": false,
                "right": "8dp",
                "top": "0dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalRoadMapContainer.setDefaultUnit(kony.flex.DP);
            var ApprovalRoadMapElement = new com.InfinityOLB.Resources.ApprovalRoadMapElement({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "ApprovalRoadMapElement",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxApprovalRoadMapContainer.add(ApprovalRoadMapElement);
            flxContentContainerRight.add(flxApprovalRoadMapContainer);
            flxDashboard.add(flxContentContainerLeft, flxBackToPendingTop, flxContentContainerRight);
            var flxTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTerms",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "87.85%",
                "zIndex": 3,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTerms.setDefaultUnit(kony.flex.DP);
            var lblTitleTerms = new kony.ui.Label({
                "id": "lblTitleTerms",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var browserTnC = new kony.ui.Browser({
                "bottom": "10dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "browserTnC",
                "isVisible": true,
                "left": "0dp",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxTerms.add(lblTitleTerms, browserTnC);
            flxContentContainer.add(flxContentHeader, flxAcknowledgementContainer, flxAcknowledgementMobile, flxAuthenticator, flxDashboard, flxTerms);
            flxMain.add(flxMainWrapper, flxskncontainer, flxContentContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "100dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    },
                    "customfooter": {
                        "centerX": "50%",
                        "height": "100dp",
                        "left": "0%",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "top": "26.60%",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "top": "75dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "155%",
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "760dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxfbfbfbBorder0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.08%",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "icon_close_grey.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\nDescription of eStatements\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\nRegistration for eStatements\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\nEligible Accounts For eStatements\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\nEnrollment For eStatement Delivery\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\nChange In Terms and Conditions\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\nTermination\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\nMiscellaneous\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC);
            var flxTCCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTCCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCCheckBox.setDefaultUnit(kony.flex.DP);
            var lblIAccept = new kony.ui.Label({
                "id": "lblIAccept",
                "isVisible": true,
                "left": "6%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IAcceptTC\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTCContentsCheckbox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTCContentsCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": "23dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContentsCheckbox.setDefaultUnit(kony.flex.DP);
            var lblTCContentsCheckBox = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "22dp",
                "id": "lblTCContentsCheckBox",
                "isVisible": true,
                "skin": "sknlblOLBFonts3343A820pxOlbFontIcons",
                "text": "C",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Terms & Conditions"
            });
            flxTCContentsCheckbox.add(lblTCContentsCheckBox);
            flxTCCheckBox.add(lblIAccept, flxTCContentsCheckbox);
            var flxSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxContentsButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "90px",
                "id": "flxContentsButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "-1dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentsButtons.setDefaultUnit(kony.flex.DP);
            var btnCancel = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder3343a81pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            var btnSave = new kony.ui.Button({
                "bottom": 20,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnSave",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Save"
            });
            flxContentsButtons.add(btnCancel, btnSave);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxTCCheckBox, flxSeperator2, flxContentsButtons);
            flxTermsAndConditions.add(flxTC);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxPopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 6000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxClose": {
                        "isVisible": true,
                        "right": "0dp"
                    },
                    "flxComments": {
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxPopupContainer": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "280dp"
                    },
                    "flxPopupNew": {
                        "isVisible": false,
                        "zIndex": 6000
                    },
                    "formActionsNew.btnCancel": {
                        "left": "viz.val_cleared",
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "formActionsNew.btnNext": {
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "imgClose": {
                        "right": "20dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblCommnets": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.myRequests.comments\")"
                    },
                    "trComments": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.trComments\")",
                        "left": "30dp",
                        "right": "viz.val_cleared",
                        "top": "12dp",
                        "width": "88.70%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAckPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAckPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 901,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckPopup.setDefaultUnit(kony.flex.DP);
            var flxPopupContainer = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxPopupContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupContainer.setDefaultUnit(kony.flex.DP);
            var ApprovalViewDetails = new com.Infinity.Approvals.ApprovalViewDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "id": "ApprovalViewDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "maxWidth": "1200dp",
                "isModalContainer": false,
                "skin": "slFboxFFFFFFBgNoBorder3C3C3CShadow4Px4PxBlur20Px",
                "top": "50dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "ApprovalViewDetails": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "maxWidth": "1200dp",
                        "top": "50dp",
                        "width": "90%"
                    },
                    "imgClose": {
                        "src": "blue_close_icon.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAckPopupPadding = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAckPopupPadding",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckPopupPadding.setDefaultUnit(kony.flex.DP);
            flxAckPopupPadding.add();
            flxPopupContainer.add(ApprovalViewDetails, flxAckPopupPadding);
            flxAckPopup.add(flxPopupContainer);
            var flxOverlay = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxOverlay",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Opacity40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverlay.setDefaultUnit(kony.flex.DP);
            flxOverlay.add();
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20px",
                        "width": "150dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgPrint": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgdownload": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "success_green.png",
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "70px"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMobile": {
                        "height": {
                            "type": "string",
                            "value": "231dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgement": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknLblSSP46464615pxbold",
                        "text": "Acknowledgement",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorMob": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "skin": "sknflxe9ebee",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "text": "You have successfully approved this request.",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "flxTickImage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgTick": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "src": "confirmation_tick.png",
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "flxRequestId": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "lblRequestId": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "text": "Request ID",
                        "width": {
                            "type": "string",
                            "value": "124dp"
                        },
                        "segmentProps": []
                    },
                    "lblRequestIdValue": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "text": "456789734787",
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "flxAuthenticator": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.btnProceed": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.lblSecureAccessCode": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.flxOTPContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "flxContentContainerLeft": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxSummary": {
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTotal": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblTotalRequest": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalRequestVal": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalApproved": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblTotalApproved": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalApprovedVal": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalRejected": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblTotalRejected": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalRejectedVal": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSkipped": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblSkipped": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblSkippedVal": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "focusSkin": "slfBoxffffffB1R5",
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "segTransactionDetails": {
                        "segmentProps": []
                    },
                    "flxTransactionDetailsMobile": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "segTransactionDetailsMobile": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "rowSkin": "segTransparant",
                        "segmentProps": []
                    },
                    "flxButton": {
                        "segmentProps": []
                    },
                    "btnBackToPending": {
                        "segmentProps": []
                    },
                    "flxBackToPendingTop": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPendingTop": {
                        "i18n_text": "kony.approval.backToPending",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxContentContainerRight": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "text": "© Copyright Infinity Retail Banking. All rights reserved.",
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "btnSave": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxClose": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "flxPopup"
                    },
                    "flxPopup.formActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.formActionsNew.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxAckPopup": {
                        "zIndex": 1502,
                        "segmentProps": []
                    },
                    "flxPopupContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader.headermenu": {
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxAckContainer": {
                        "height": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "10.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMobile": {
                        "segmentProps": []
                    },
                    "flxAuthenticator": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "flxContentContainerLeft": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxSummary": {
                        "segmentProps": []
                    },
                    "lblSummaryTitle": {
                        "width": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalRequest": {
                        "segmentProps": []
                    },
                    "lblTotalApproved": {
                        "segmentProps": []
                    },
                    "lblTotalRejected": {
                        "segmentProps": []
                    },
                    "lblSkipped": {
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "focusSkin": "slfBoxffffffB1R5",
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "segTransactionDetails": {
                        "segmentProps": []
                    },
                    "segTransactionDetailsMobile": {
                        "rowSkin": "segTransparant",
                        "segmentProps": []
                    },
                    "flxButton": {
                        "segmentProps": []
                    },
                    "btnBackToPending": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPendingTop": {
                        "segmentProps": []
                    },
                    "flxContentContainerRight": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblTitleTerms": {
                        "left": {
                            "type": "string",
                            "value": "27px"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "top": {
                            "type": "string",
                            "value": "378px"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "segmentProps": [],
                        "instanceId": "flxPopup"
                    },
                    "flxAckPopup": {
                        "zIndex": 1502,
                        "segmentProps": []
                    },
                    "flxPopupContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxOverlay": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader.headermenu": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementMobile": {
                        "segmentProps": []
                    },
                    "lblAcknowledgement": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainerLeft": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "62%"
                        },
                        "segmentProps": []
                    },
                    "flxSummary": {
                        "segmentProps": []
                    },
                    "lblSummaryTitle": {
                        "width": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalRequest": {
                        "segmentProps": []
                    },
                    "lblTotalApproved": {
                        "segmentProps": []
                    },
                    "lblTotalRejected": {
                        "segmentProps": []
                    },
                    "lblSkipped": {
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "focusSkin": "slfBoxffffffB1R5",
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "segTransactionDetails": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxTransactionDetailsMobile": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "segTransactionDetailsMobile": {
                        "rowSkin": "segTransparant",
                        "segmentProps": []
                    },
                    "flxButton": {
                        "segmentProps": []
                    },
                    "btnBackToPending": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPendingTop": {
                        "segmentProps": []
                    },
                    "flxContentContainerRight": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "flxAckPopup": {
                        "zIndex": 1502,
                        "segmentProps": []
                    },
                    "flxPopupContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheader.headermenu": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "focusSkin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "btnBackToPending": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPendingTop": {
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "top": {
                            "type": "string",
                            "value": "378px"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.headermenu": {
                    "height": "70dp",
                    "right": "6%",
                    "top": "0dp",
                    "width": "94%"
                },
                "flxAcknowledgement": {
                    "successImgWidth": "4.44%",
                    "successMsg": "Your transaction has been successfully submitted\nReference Number 45423792753",
                    "right": "",
                    "top": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": ""
                },
                "flxAcknowledgementNew.flxAckContainer": {
                    "height": "115dp"
                },
                "flxAcknowledgementNew": {
                    "left": "0dp",
                    "width": "100%"
                },
                "flxAcknowledgementNew.flxTickImage": {
                    "height": "50dp"
                },
                "flxAcknowledgementNew.imgDownload": {
                    "src": "bbdownloadicon.png"
                },
                "flxAcknowledgementNew.imgPrint": {
                    "src": "bbprint.png"
                },
                "flxAcknowledgementNew.imgTick": {
                    "src": "bulk_billpay_success.png",
                    "width": "100%"
                },
                "OTPAuthenticator.OTPCode.imgViewCVVCode": {
                    "src": "view.png"
                },
                "OTPAuthenticator.OTPCode.imgWarning": {
                    "src": "error_yellow.png"
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "100dp",
                    "left": "0%",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "top": "26.60%",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "top": "75dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "flxPopup.flxClose": {
                    "right": "0dp"
                },
                "flxPopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "flxPopup.flxPopupContainer": {
                    "centerY": "",
                    "left": "",
                    "right": "",
                    "top": "280dp"
                },
                "flxPopup": {
                    "zIndex": 6000
                },
                "flxPopup.formActionsNew.btnCancel": {
                    "left": "",
                    "right": "190dp",
                    "width": "150dp"
                },
                "flxPopup.formActionsNew.btnNext": {
                    "left": "",
                    "right": "20dp",
                    "width": "150dp"
                },
                "flxPopup.imgClose": {
                    "right": "20dp",
                    "src": "bbcloseicon.png"
                },
                "flxPopup.trComments": {
                    "left": "30dp",
                    "right": "",
                    "top": "12dp",
                    "width": "88.70%"
                },
                "ApprovalViewDetails": {
                    "centerX": "50%",
                    "left": "",
                    "maxWidth": "1200dp",
                    "top": "50dp",
                    "width": "90%"
                },
                "ApprovalViewDetails.imgClose": {
                    "src": "blue_close_icon.png"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20px",
                    "width": "150dp"
                }
            }
            this.add(flxHeaderMain, flxFormContent, flxTermsAndConditions, flxLoading, flxPopup, flxAckPopup, flxOverlay, flxLogout);
        };
        return [{
            "addWidgets": addWidgetsfrmApprovalAcknowledgement,
            "enabledForIdleTimeout": true,
            "id": "frmApprovalAcknowledgement",
            "init": controller.AS_Form_fef224d4787d42c08dfa22961a00b02a,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_i32bd06805cc429aa905334a1bdf4f94,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ApprovalRequestMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_c933e2aeed0c48c6be905a7a553d6ead,
            "retainScrollPosition": true
        }]
    }
});