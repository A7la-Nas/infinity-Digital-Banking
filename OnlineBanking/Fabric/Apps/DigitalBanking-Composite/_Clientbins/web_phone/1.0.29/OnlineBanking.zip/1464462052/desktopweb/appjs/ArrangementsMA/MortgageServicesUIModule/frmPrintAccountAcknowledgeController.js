define("ArrangementsMA/MortgageServicesUIModule/userfrmPrintAccountAcknowledgeController", ['CommonUtilities', 'OLBConstants'], function(CommonUtilities, OLBConstants) {
    return {
        accountList: {},
        payLoad: {},
        account: {},
        preShow: function() {
            var navMan = applicationManager.getNavigationManager();
            var scopeObj = this;
            this.accountList = navMan.getCustomInfo("frmPrintAccountAcknowledge");
            this.payLoad = navMan.getCustomInfo("frmPrintAccountAcknowledge");
            this.account = navMan.getCustomInfo("frmPrintAccountAcknowledge");
            this.setUpFormData();
        },
        setUpFormData: function() {
            this.view.lblMyCheckingAccount.text = scopeObj.payLoad.loanName + "..." + scopeObj.payLoad.loanAccountNumber.slice(-4);
            this.view.lblKonyBank.text = scopeObj.payLoad.loanName + "..." + scopeObj.payLoad.loanAccountNumber.slice(-4);
            var navMan = applicationManager.getNavigationManager();
            this.view.lblReferenceValue.text = navMan.getCustomInfo("frmPrintAccountAcknowledge1")
            this.view.lblValLoan.text = scopeObj.payLoad.loanName;
            this.view.lblValNewRepaymentAcctHoldName.text = scopeObj.payLoad.requestDetails[0].newValue;
            this.view.lblValNewRepaymentAcctNo.text = "************" + scopeObj.payLoad.requestDetails[1].newValue.slice(-4);
            //this.view.lblValBICSWIFT.text = scopeObj.payLoad.requestDetails[2].newValue;
            this.view.lblValBankName.text = scopeObj.payLoad.requestDetails[2].newValue;
            //kony.application.dismissLoadingScreen();
        },
        postShow: function() {
            //this.printCall();
            scope = this;
            setTimeout(function() {
                scope.printCall();
            }, "17ms");
            applicationManager.getNavigationManager().applyUpdates(this);
        },
        printCall: function() {
            var scope = this;
            //kony.os.print();
            kony.os.print();
            //timeout is required to allow print popup to be visible.
            setTimeout(function() {
                scope.loadAccountsDetails();
            }, "17ms");
        },
        /**
         * loadAccountsDetails : Method to accounts details
         * @member of {frmPrintTransactionController}
         * @param {}
         * @return {}
         * @throws {}
         */
        loadAccountsDetails: function() {
            var navMan = applicationManager.getNavigationManager();
            navMan.navigateTo({
                "appName": "ArrangementsMA",
                "friendlyName": "MortgageServicesUIModule/frmChangeRepaymentAccountAcknowledge"
            });
            kony.application.dismissLoadingScreen();
        }
    }
});
define("ArrangementsMA/MortgageServicesUIModule/frmPrintAccountAcknowledgeControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for frmPrintAccountAcknowledge **/
    AS_Form_a7afd6b7b5de4d6294fb87ba0be54b81: function AS_Form_a7afd6b7b5de4d6294fb87ba0be54b81(eventobject) {
        var self = this;
        this.preShow();
    },
    /** postShow defined for frmPrintAccountAcknowledge **/
    AS_Form_i4d1d253f9754b06b0dc7ed8522e6074: function AS_Form_i4d1d253f9754b06b0dc7ed8522e6074(eventobject) {
        var self = this;
        this.postShow();
    }
});
define("ArrangementsMA/MortgageServicesUIModule/frmPrintAccountAcknowledgeController", ["ArrangementsMA/MortgageServicesUIModule/userfrmPrintAccountAcknowledgeController", "ArrangementsMA/MortgageServicesUIModule/frmPrintAccountAcknowledgeControllerActions"], function() {
    var controller = require("ArrangementsMA/MortgageServicesUIModule/userfrmPrintAccountAcknowledgeController");
    var controllerActions = ["ArrangementsMA/MortgageServicesUIModule/frmPrintAccountAcknowledgeControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
