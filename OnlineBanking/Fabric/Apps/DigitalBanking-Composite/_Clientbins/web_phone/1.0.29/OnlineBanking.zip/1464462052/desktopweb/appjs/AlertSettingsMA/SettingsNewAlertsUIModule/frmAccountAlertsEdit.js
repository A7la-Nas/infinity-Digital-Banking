define("AlertSettingsMA/SettingsNewAlertsUIModule/frmAccountAlertsEdit", function() {
    return function(controller) {
        function addWidgetsfrmAccountAlertsEdit() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblHeading",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.Hamburger.Settings\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxProfileError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxProfileError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileError.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgError",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxError = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxError",
                "isVisible": true,
                "left": "76dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.WecouldntfindanexactmatchPleaseenteryourpayeeinformationasitappearsonyourbill\")",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileError.add(imgError, rtxError);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "27dp",
                "width": "87.80%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "sknLblSSP42424215px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "262dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var accountAlerts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "accountAlerts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            accountAlerts.setDefaultUnit(kony.flex.DP);
            var flxAlertsHeaderContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAlertsHeaderContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30%",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder0b7491d9b1d7c4e",
                "top": "0dp",
                "width": "70.08%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsHeaderContainer.setDefaultUnit(kony.flex.DP);
            var flxAlertsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxAlertsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "sknFFFFFFnoBor",
                "top": "0dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsHeader.setDefaultUnit(kony.flex.DP);
            var flxAlertsSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAlertsSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3op60",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsSeperator.setDefaultUnit(kony.flex.DP);
            flxAlertsSeperator.add();
            var lblAlertsHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblAlertsHeading",
                "isVisible": true,
                "left": "0px",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PersonalDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEditAlerts = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "id": "btnEditAlerts",
                "isVisible": true,
                "right": "0px",
                "skin": "sknBtnSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertsHeader.add(flxAlertsSeperator, lblAlertsHeading, btnEditAlerts);
            var flxAlertsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAlertsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "50dp",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsBody.setDefaultUnit(kony.flex.DP);
            var flxInvalidAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxInvalidAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInvalidAmount.setDefaultUnit(kony.flex.DP);
            var lblInvalidAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "70%",
                "id": "lblInvalidAmount",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLabelSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Profilemanagement.lblInvalidAmount\")",
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInvalidAmount.add(lblInvalidAmount);
            var flxEnableAlertsSwitch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "50px",
                "id": "flxEnableAlertsSwitch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnableAlertsSwitch.setDefaultUnit(kony.flex.DP);
            var flxEnableSwitch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxEnableSwitch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50px",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnableSwitch.setDefaultUnit(kony.flex.DP);
            var ToggleSwitch = new kony.ui.Switch({
                "height": "20dp",
                "id": "ToggleSwitch",
                "isVisible": false,
                "left": "0dp",
                "leftSideText": "ON",
                "rightSideText": "OFF",
                "selectedIndex": 0,
                "skin": "sknSwitchToggle",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwitch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblSwitch",
                "isVisible": true,
                "left": "0",
                "skin": "skna0a0a0fonticon45px",
                "text": "n",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEnableSwitch.add(ToggleSwitch, lblSwitch);
            var lblEnableAlerts = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblEnableAlerts",
                "isVisible": true,
                "left": "10px",
                "skin": "sknLblSSP42424215px",
                "text": "Enable Alerts",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEnableAlertsSwitch.add(flxEnableSwitch, lblEnableAlerts);
            var flxAlertsStatus = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "25dp",
                "id": "flxAlertsStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsStatus.setDefaultUnit(kony.flex.DP);
            var flxAlertsStatusIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAlertsStatusIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "-5dp",
                "width": "30px",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsStatusIcon.setDefaultUnit(kony.flex.DP);
            var lblAlertStatusIndicator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "51%",
                "height": "10dp",
                "id": "lblAlertStatusIndicator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknStatusActivatedUM",
                "width": "10dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertsStatusIcon.add(lblAlertStatusIndicator);
            var lblAlertsStatus = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "39%",
                "height": "20dp",
                "id": "lblAlertsStatus",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Alerts.Enabled\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertsStatus.add(flxAlertsStatusIcon, lblAlertsStatus);
            var flxAlertsWarningDW = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "125px",
                "id": "flxAlertsWarningDW",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsWarningDW.setDefaultUnit(kony.flex.DP);
            var flxAlertsWarningWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": true,
                "id": "flxAlertsWarningWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsWarningWrapper.setDefaultUnit(kony.flex.DP);
            var flxWarningMsg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxWarningMsg",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarningMsg.setDefaultUnit(kony.flex.DP);
            var lblAlertsWarningImage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblAlertsWarningImage",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknlbl4a90e230OLBFontIconsPx",
                "text": "K",
                "top": "10px",
                "width": "32px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxAlertsWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "rtxAlertsWarning",
                "isVisible": true,
                "left": "10dp",
                "right": "5%",
                "skin": "sknRtx42424215px",
                "text": "Get notified as per alert preference ",
                "top": "15px",
                "width": "93%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarningMsg.add(lblAlertsWarningImage, rtxAlertsWarning);
            var flxChannelIconsInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10px",
                "clipBounds": true,
                "id": "flxChannelIconsInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannelIconsInfo.setDefaultUnit(kony.flex.DP);
            var flxSMSIconInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSMSIconInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "7%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "10%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSMSIconInfo.setDefaultUnit(kony.flex.DP);
            var lblSMSIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "20px",
                "id": "lblSMSIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSMS727272FontIcon",
                "text": "v",
                "top": "0px",
                "width": "20px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSMSInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSMSInfo",
                "isVisible": true,
                "left": "10px",
                "skin": "sknLblSSP42424215px",
                "text": "SMS",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSMSIconInfo.add(lblSMSIcon, lblSMSInfo);
            var flxEmailIconInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEmailIconInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "17%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "11%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailIconInfo.setDefaultUnit(kony.flex.DP);
            var lblEmailIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "20px",
                "id": "lblEmailIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblEmail727272FontIcon",
                "text": "w",
                "top": "0px",
                "width": "20px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEmailInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEmailInfo",
                "isVisible": true,
                "left": "10px",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.EmailId\")",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEmailIconInfo.add(lblEmailIcon, lblEmailInfo);
            var flxPushIconInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPushIconInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "28%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "23%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPushIconInfo.setDefaultUnit(kony.flex.DP);
            var lblPushIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "20px",
                "id": "lblPushIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblPush727272FontIcon",
                "text": "x",
                "top": "0px",
                "width": "20px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPushInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPushInfo",
                "isVisible": true,
                "left": "10px",
                "skin": "sknLblSSP42424215px",
                "text": "Push Notifications",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPushIconInfo.add(lblPushIcon, lblPushInfo);
            var flxNotifIconInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNotifIconInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNotifIconInfo.setDefaultUnit(kony.flex.DP);
            var lblNotifIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "20px",
                "id": "lblNotifIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblNotification727272FontIcon",
                "text": "y",
                "top": "0px",
                "width": "20px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNotifInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNotifInfo",
                "isVisible": true,
                "left": "10px",
                "skin": "sknLblSSP42424215px",
                "text": "Notification Center",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNotifIconInfo.add(lblNotifIcon, lblNotifInfo);
            flxChannelIconsInfo.add(flxSMSIconInfo, flxEmailIconInfo, flxPushIconInfo, flxNotifIconInfo);
            flxAlertsWarningWrapper.add(flxWarningMsg, flxChannelIconsInfo);
            flxAlertsWarningDW.add(flxAlertsWarningWrapper);
            var flxAlertsWarningTab = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "155px",
                "id": "flxAlertsWarningTab",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsWarningTab.setDefaultUnit(kony.flex.DP);
            var flxAlertsWarningWrapper2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "id": "flxAlertsWarningWrapper2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsWarningWrapper2.setDefaultUnit(kony.flex.DP);
            var flxWarningMsg2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarningMsg2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarningMsg2.setDefaultUnit(kony.flex.DP);
            var rtxAlertsWarning2 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "rtxAlertsWarning2",
                "isVisible": true,
                "left": "50dp",
                "right": "5%",
                "skin": "sknRtx42424215px",
                "text": "Get notified as per alert preference ",
                "top": "15px",
                "width": "93%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAlertsWarningImage2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblAlertsWarningImage2",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknlbl4a90e230OLBFontIconsPx",
                "text": "K",
                "top": "10px",
                "width": "32px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarningMsg2.add(rtxAlertsWarning2, lblAlertsWarningImage2);
            var flxChannelIconsInfo2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "25px",
                "id": "flxChannelIconsInfo2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannelIconsInfo2.setDefaultUnit(kony.flex.DP);
            var flxSMSIconInfo2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSMSIconInfo2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "7%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "10%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSMSIconInfo2.setDefaultUnit(kony.flex.DP);
            var lblSMSIcon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20px",
                "id": "lblSMSIcon2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSMS727272FontIcon",
                "text": "K",
                "top": "0px",
                "width": "20px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSMSInfo2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSMSInfo2",
                "isVisible": true,
                "left": "5px",
                "skin": "sknLblSSP42424215px",
                "text": "SMS",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSMSIconInfo2.add(lblSMSIcon2, lblSMSInfo2);
            var flxEmailIconInfo2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEmailIconInfo2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "10%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailIconInfo2.setDefaultUnit(kony.flex.DP);
            var lblEmailIcon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20px",
                "id": "lblEmailIcon2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblEmail727272FontIcon",
                "text": "w",
                "top": "0px",
                "width": "20px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEmailInfo2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEmailInfo2",
                "isVisible": true,
                "left": "5px",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.EmailId\")",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEmailIconInfo2.add(lblEmailIcon2, lblEmailInfo2);
            var flxPushIconInfo2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPushIconInfo2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPushIconInfo2.setDefaultUnit(kony.flex.DP);
            var lblPushIcon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20px",
                "id": "lblPushIcon2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblPush727272FontIcon",
                "text": "K",
                "top": "0px",
                "width": "20px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPushInfo2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPushInfo2",
                "isVisible": true,
                "left": "5px",
                "skin": "sknLblSSP42424215px",
                "text": "Push Notifications",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPushIconInfo2.add(lblPushIcon2, lblPushInfo2);
            flxChannelIconsInfo2.add(flxSMSIconInfo2, flxEmailIconInfo2, flxPushIconInfo2);
            var flxNotifIconInfo2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10px",
                "clipBounds": true,
                "id": "flxNotifIconInfo2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "7%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "50%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNotifIconInfo2.setDefaultUnit(kony.flex.DP);
            var lblNotifIcon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20px",
                "id": "lblNotifIcon2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblNotification727272FontIcon",
                "text": "y",
                "top": "0px",
                "width": "20px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNotifInfo2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNotifInfo2",
                "isVisible": true,
                "left": "5px",
                "skin": "sknLblSSP42424215px",
                "text": "Notification Center",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNotifIconInfo2.add(lblNotifIcon2, lblNotifInfo2);
            flxAlertsWarningWrapper2.add(flxWarningMsg2, flxChannelIconsInfo2, flxNotifIconInfo2);
            flxAlertsWarningTab.add(flxAlertsWarningWrapper2);
            var flxChannelsFrequency = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "80px",
                "id": "flxChannelsFrequency",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannelsFrequency.setDefaultUnit(kony.flex.DP);
            var flxCategoryChannels = new kony.ui.FlexContainer({
                "bottom": "20px",
                "clipBounds": false,
                "height": "40px",
                "id": "flxCategoryChannels",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "20px",
                "skin": "slFbox",
                "top": "20dp",
                "width": "40%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCategoryChannels.setDefaultUnit(kony.flex.DP);
            var lblChannelsTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblChannelsTitle",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSP72727215Px",
                "text": "Select Channels:",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxChannels = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxChannels",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "0dp",
                "width": "224px",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannels.setDefaultUnit(kony.flex.DP);
            var flxChannel1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Message Channel"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "blur": {
                    "enabled": false,
                    "value": 10
                },
                "clipBounds": false,
                "height": "38dp",
                "id": "flxChannel1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "55px",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannel1.setDefaultUnit(kony.flex.DP);
            var lblChannel1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25px",
                "id": "lblChannel1",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblSMS727272FontIcon",
                "text": "v",
                "width": "25px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChannel1.add(lblChannel1);
            var flxVerticalSeparator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxVerticalSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0",
                "width": "1px",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalSeparator1.setDefaultUnit(kony.flex.DP);
            flxVerticalSeparator1.add();
            var flxChannel2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Email Channel"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "38dp",
                "id": "flxChannel2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0dp",
                "width": "55px",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannel2.setDefaultUnit(kony.flex.DP);
            var lblChannel2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25px",
                "id": "lblChannel2",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblEmail727272FontIcon",
                "text": "w",
                "width": "25px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChannel2.add(lblChannel2);
            var flxVerticalSeparator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxVerticalSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0",
                "width": "1px",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalSeparator2.setDefaultUnit(kony.flex.DP);
            flxVerticalSeparator2.add();
            var flxChannel3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Push Notification channel"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "38dp",
                "id": "flxChannel3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow2",
                "top": "0dp",
                "width": "55px",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannel3.setDefaultUnit(kony.flex.DP);
            var lblChannel3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25px",
                "id": "lblChannel3",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblPush727272FontIcon",
                "text": "x",
                "width": "25px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChannel3.add(lblChannel3);
            var flxVerticalSeparator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxVerticalSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0",
                "width": "1px",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalSeparator3.setDefaultUnit(kony.flex.DP);
            flxVerticalSeparator3.add();
            var flxChannel4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Notifications channel"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "38dp",
                "id": "flxChannel4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0dp",
                "width": "55px",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannel4.setDefaultUnit(kony.flex.DP);
            var lblChannel4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25px",
                "id": "lblChannel4",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblNotification727272FontIcon",
                "text": "y",
                "width": "25px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChannel4.add(lblChannel4);
            flxChannels.add(flxChannel1, flxVerticalSeparator1, flxChannel2, flxVerticalSeparator2, flxChannel3, flxVerticalSeparator3, flxChannel4);
            flxCategoryChannels.add(lblChannelsTitle, flxChannels);
            var flxCategoryFrequency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": false,
                "height": "40px",
                "id": "flxCategoryFrequency",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "45%",
                "isModalContainer": false,
                "right": "20px",
                "skin": "slFbox",
                "top": "20dp",
                "width": "53%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCategoryFrequency.setDefaultUnit(kony.flex.DP);
            var lblFrequencyTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblFrequencyTitle",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSP72727215Px",
                "text": "Frequency:",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFrequency1 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFrequency1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency1.setDefaultUnit(kony.flex.DP);
            var lstBoxFrequency1 = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "100%",
                "id": "lstBoxFrequency1",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFrequency1.add(lstBoxFrequency1);
            var flxFrequency2 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFrequency2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency2.setDefaultUnit(kony.flex.DP);
            var lstBoxFrequency2 = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "100%",
                "id": "lstBoxFrequency2",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFrequency2.add(lstBoxFrequency2);
            var flxFrequency3 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFrequency3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "22%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency3.setDefaultUnit(kony.flex.DP);
            var lstBoxFrequency3 = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "100%",
                "id": "lstBoxFrequency3",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFrequency3.add(lstBoxFrequency3);
            flxCategoryFrequency.add(lblFrequencyTitle, flxFrequency1, flxFrequency2, flxFrequency3);
            flxChannelsFrequency.add(flxCategoryChannels, flxCategoryFrequency);
            var flxChannelsFrequencyTab = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "120px",
                "id": "flxChannelsFrequencyTab",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannelsFrequencyTab.setDefaultUnit(kony.flex.DP);
            var flxCategoryChannelsTab = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": false,
                "height": "40px",
                "id": "flxCategoryChannelsTab",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "20px",
                "skin": "slFbox",
                "top": "10dp",
                "width": "40%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCategoryChannelsTab.setDefaultUnit(kony.flex.DP);
            var lblChannelsTitleTab = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblChannelsTitleTab",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSP72727215Px",
                "text": "Select Channels:",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxChannelsTab = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "40dp",
                "id": "flxChannelsTab",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowe3e3e3Rad3Px",
                "top": "0dp",
                "width": "224px",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannelsTab.setDefaultUnit(kony.flex.DP);
            var flxChannel1Tab = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Messages Channel"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxChannel1Tab",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "55px",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannel1Tab.setDefaultUnit(kony.flex.DP);
            var lblChannel1Tab = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20px",
                "id": "lblChannel1Tab",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblSMS003e75FontIcon",
                "text": "v",
                "width": "20px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChannel1Tab.add(lblChannel1Tab);
            var flxVerticalSeparator1Tab = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxVerticalSeparator1Tab",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0",
                "width": "1px",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalSeparator1Tab.setDefaultUnit(kony.flex.DP);
            flxVerticalSeparator1Tab.add();
            var flxChannel2Tab = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Email Channel"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxChannel2Tab",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "55px",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannel2Tab.setDefaultUnit(kony.flex.DP);
            var lblChannel2Tab = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20px",
                "id": "lblChannel2Tab",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblEmail003e75FontIcon",
                "text": "w",
                "width": "20px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChannel2Tab.add(lblChannel2Tab);
            var flxVerticalSeparator2Tab = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxVerticalSeparator2Tab",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0",
                "width": "1px",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalSeparator2Tab.setDefaultUnit(kony.flex.DP);
            flxVerticalSeparator2Tab.add();
            var flxChannel3Tab = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Push Notifications Channel"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxChannel3Tab",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "55px",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannel3Tab.setDefaultUnit(kony.flex.DP);
            var lblChannel3Tab = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25px",
                "id": "lblChannel3Tab",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblPush003e75FontIcon",
                "text": "x",
                "width": "25px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChannel3Tab.add(lblChannel3Tab);
            var flxVerticalSeparator3Tab = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxVerticalSeparator3Tab",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0",
                "width": "1px",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalSeparator3Tab.setDefaultUnit(kony.flex.DP);
            flxVerticalSeparator3Tab.add();
            var flxChannel4Tab = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Notifications Channel"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxChannel4Tab",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.00%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-1dp",
                "width": "55px",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChannel4Tab.setDefaultUnit(kony.flex.DP);
            var lblChannel4Tab = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25px",
                "id": "lblChannel4Tab",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblNotification003e75FontIcon",
                "text": "y",
                "width": "25px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChannel4Tab.add(lblChannel4Tab);
            flxChannelsTab.add(flxChannel1Tab, flxVerticalSeparator1Tab, flxChannel2Tab, flxVerticalSeparator2Tab, flxChannel3Tab, flxVerticalSeparator3Tab, flxChannel4Tab);
            flxCategoryChannelsTab.add(lblChannelsTitleTab, flxChannelsTab);
            var flxCategoryFrequencyTab = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": false,
                "height": "40px",
                "id": "flxCategoryFrequencyTab",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "right": "20px",
                "skin": "slFbox",
                "top": "70dp",
                "width": "55%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCategoryFrequencyTab.setDefaultUnit(kony.flex.DP);
            var lblFrequencyTitleTab = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblFrequencyTitleTab",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSP72727215Px",
                "text": "Frequency:",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFrequency1Tab = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFrequency1Tab",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency1Tab.setDefaultUnit(kony.flex.DP);
            var lstBoxFrequency1Tab = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "100%",
                "id": "lstBoxFrequency1Tab",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFrequency1Tab.add(lstBoxFrequency1Tab);
            var flxFrequency2Tab = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFrequency2Tab",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency2Tab.setDefaultUnit(kony.flex.DP);
            var lstBoxFrequency2Tab = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "100%",
                "id": "lstBoxFrequency2Tab",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFrequency2Tab.add(lstBoxFrequency2Tab);
            var flxFrequency3Tab = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFrequency3Tab",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "22%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency3Tab.setDefaultUnit(kony.flex.DP);
            var lstBoxFrequency3Tab = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "100%",
                "id": "lstBoxFrequency3Tab",
                "isVisible": true,
                "left": "0",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFrequency3Tab.add(lstBoxFrequency3Tab);
            flxCategoryFrequencyTab.add(lblFrequencyTitleTab, flxFrequency1Tab, flxFrequency2Tab, flxFrequency3Tab);
            flxChannelsFrequencyTab.add(flxCategoryChannelsTab, flxCategoryFrequencyTab);
            var flxAlertsSegment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAlertsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "minHeight": "500dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsSegment.setDefaultUnit(kony.flex.DP);
            var segAlertsListing = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segAlertsListing",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AlertSettingsMA",
                    "friendlyName": "flxCategoryAlertRow"
                }),
                "sectionHeaderSkin": "seg2Normal",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AlertSettingsMA",
                    "friendlyName": "flxCategoryAlertsHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAlert": "flxAlert",
                    "flxAlertAttribute1": "flxAlertAttribute1",
                    "flxAlertAttribute2": "flxAlertAttribute2",
                    "flxAlertAttribute3": "flxAlertAttribute3",
                    "flxAmount1": "flxAmount1",
                    "flxAmount2": "flxAmount2",
                    "flxAmount3": "flxAmount3",
                    "flxAttributeValues": "flxAttributeValues",
                    "flxAttributes": "flxAttributes",
                    "flxCategoryAlertRow": "flxCategoryAlertRow",
                    "flxCategoryAlertsContainer": "flxCategoryAlertsContainer",
                    "flxCategoryAlertsHeader": "flxCategoryAlertsHeader",
                    "flxFullSeperator": "flxFullSeperator",
                    "flxGroupCheckBox": "flxGroupCheckBox",
                    "flxSeperator": "flxSeperator",
                    "lblAlertName": "lblAlertName",
                    "lblAttributeTitle1": "lblAttributeTitle1",
                    "lblCurrencySymbol1": "lblCurrencySymbol1",
                    "lblCurrencySymbol2": "lblCurrencySymbol2",
                    "lblCurrencySymbol3": "lblCurrencySymbol3",
                    "lblFromValue": "lblFromValue",
                    "lblGroupAlertsCount": "lblGroupAlertsCount",
                    "lblGroupCheckBoxIcon": "lblGroupCheckBoxIcon",
                    "lblGroupName": "lblGroupName",
                    "lblToValue": "lblToValue",
                    "lblToValue2": "lblToValue2",
                    "tbxAmount1": "tbxAmount1",
                    "tbxAmount2": "tbxAmount2",
                    "tbxAmount3": "tbxAmount3"
                },
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertsSegment.add(segAlertsListing);
            var flxNoAlertsFound = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "110px",
                "id": "flxNoAlertsFound",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAlertsFound.setDefaultUnit(kony.flex.DP);
            var flxMessage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "status"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70px",
                "id": "flxMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.77%",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3border",
                "top": "30px",
                "width": "92.44%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessage.setDefaultUnit(kony.flex.DP);
            var imgAlertErrorIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "presentation",
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40px",
                "id": "imgAlertErrorIcon",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "2.18%",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "22dp",
                "width": "40px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoAlertsWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblNoAlertsWarning",
                "isVisible": true,
                "left": "3.77%",
                "skin": "skntxtSSPff000015pxlbl",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.alerts.noAlertsToDisplay\")",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMessage.add(imgAlertErrorIcon, lblNoAlertsWarning);
            flxNoAlertsFound.add(flxMessage);
            var flxAlertButtons = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "80dp",
                "id": "flxAlertButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertButtons.setDefaultUnit(kony.flex.DP);
            var btnAlertSave = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "height": "40dp",
                "id": "btnAlertSave",
                "isVisible": true,
                "right": 20,
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "top": "20dp",
                "width": "150px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Save"
            });
            var btnAlertCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "height": "40dp",
                "id": "btnAlertCancel",
                "isVisible": true,
                "right": "190px",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "top": "20dp",
                "width": "150px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            var flxAlertBtnSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxAlertBtnSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxe3e3e3bg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertBtnSeperator.setDefaultUnit(kony.flex.DP);
            flxAlertBtnSeperator.add();
            flxAlertButtons.add(btnAlertSave, btnAlertCancel, flxAlertBtnSeperator);
            flxAlertsBody.add(flxInvalidAmount, flxEnableAlertsSwitch, flxAlertsStatus, flxAlertsWarningDW, flxAlertsWarningTab, flxChannelsFrequency, flxChannelsFrequencyTab, flxAlertsSegment, flxNoAlertsFound, flxAlertButtons);
            flxAlertsHeaderContainer.add(flxAlertsHeader, flxAlertsBody);
            accountAlerts.add(flxAlertsHeaderContainer);
            flxRight.add(accountAlerts);
            flxContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxMainContainer.add(flxContainer);
            flxMain.add(lblHeading, flxProfileError, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "height": "100dp"
                    },
                    "flxFooterMenu": {
                        "top": "26.60%"
                    },
                    "lblCopyright": {
                        "top": "75dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10000,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxProfileDeletePopUp = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "102%",
                "id": "flxProfileDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxProfileDelete = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "268dp",
                "id": "flxProfileDelete",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDelete.setDefaultUnit(kony.flex.DP);
            var flxprofileDeleteHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxprofileDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofileDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Delete"
                },
                "id": "lblProfileDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknLblSSP42424215px",
                "text": "Delete Picture",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxprofiledeleteClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxprofiledeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "CopyslFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.setDefaultUnit(kony.flex.DP);
            var imgProfileDeleteClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgProfileDeleteClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.add(imgProfileDeleteClose);
            flxprofileDeleteHeader.add(lblProfileDeleteHeader, flxprofiledeleteClose);
            var flxProfileDeleteSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxProfileDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxProfileDeleteSeperator.add();
            var flxProfileDeleteContent = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "65dp",
                "id": "flxProfileDeleteContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteContent = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Are you sure you want to Delete this Phone Number?"
                },
                "id": "lblProfileDeleteContent",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknSupportedFileTypes",
                "text": "Are you sure you want to remove your profile picture?",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.add(lblProfileDeleteContent);
            var flxWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "0%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var flxDisablWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxDisablWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20px",
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "20dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisablWarning.setDefaultUnit(kony.flex.DP);
            flxDisablWarning.add();
            flxWarning.add(flxDisablWarning);
            var flxProfileDeleteButtons = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": true,
                "height": "109px",
                "id": "flxProfileDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnDeletePopupNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "No"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupNo",
                "isVisible": true,
                "left": "35.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "28.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "No"
            });
            var btnDeletePopupYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Yes"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupYes",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "28.44%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Yes"
            });
            flxProfileDeleteButtons.add(btnDeletePopupNo, btnDeletePopupYes);
            flxProfileDelete.add(flxprofileDeleteHeader, flxProfileDeleteSeperator, flxProfileDeleteContent, flxWarning, flxProfileDeleteButtons);
            flxProfileDeletePopUp.add(flxProfileDelete);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 10000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxProfileDeletePopUp, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmAccountAlertsEdit": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Profile Settings",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxf8f7f8",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "rtxError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "We couldn't find an exact match.Please enter your payee information as it appears on your bill.",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "minHeight": {
                            "type": "string",
                            "value": "540dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91.20%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsHeaderContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "bbSknFlxffffffWithShadow",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsHeading": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "btnEditAlerts": {
                        "height": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxInvalidAmount": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "ToggleSwitch": {
                        "skin": "sknSwitchToggle1",
                        "segmentProps": []
                    },
                    "flxAlertsWarningDW": {
                        "height": {
                            "type": "string",
                            "value": "230px"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarningWrapper": {
                        "bottom": {
                            "type": "string",
                            "value": "0px"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "rtxAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxChannelIconsInfo": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxSMSIconInfo": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblSMSInfo": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxEmailIconInfo": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblEmailInfo": {
                        "i18n_text": "i18n.ProfileManagement.EmailId",
                        "text": "",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxPushIconInfo": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxNotifIconInfo": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarningTab": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxChannelsFrequency": {
                        "height": {
                            "type": "string",
                            "value": "250px"
                        },
                        "segmentProps": []
                    },
                    "flxCategoryChannels": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblChannelsTitle": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "text": "Select Channels",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxChannels": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxCategoryFrequency": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxFrequency1": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lstBoxFrequency1": {
                        "width": {
                            "type": "string",
                            "value": "103%"
                        },
                        "segmentProps": []
                    },
                    "flxFrequency2": {
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxFrequency3": {
                        "left": {
                            "type": "string",
                            "value": "66%"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "flxChannelsFrequencyTab": {
                        "segmentProps": []
                    },
                    "flxAlertsSegment": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "segAlertsListing": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoAlertsFound": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMessage": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertButtons": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnAlertSave": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "btnAlertCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertBtnSeperator": {
                        "left": {
                            "type": "string",
                            "value": "-100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "segmentProps": []
                    },
                    "customfooternew.flxFooterMenu": {
                        "top": {
                            "type": "string",
                            "value": "10.60%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.lblCopyright": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "i18n_text": "kony.mb.Hamburger.Settings",
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "segmentProps": []
                    },
                    "flxRight": {
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsHeaderContainer": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnEditAlerts": {
                        "height": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxInvalidAmount": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxEnableAlertsSwitch": {
                        "segmentProps": []
                    },
                    "ToggleSwitch": {
                        "skin": "sknSwitchToggle1",
                        "segmentProps": []
                    },
                    "lblSwitch": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAlertsStatus": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsStatusIcon": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsStatus": {
                        "centerY": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarningDW": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAlertsWarningTab": {
                        "height": {
                            "type": "string",
                            "value": "175px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarningWrapper2": {
                        "height": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "rtxAlertsWarning2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSMSIconInfo2": {
                        "left": {
                            "type": "string",
                            "value": "4.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailIconInfo2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblEmailInfo2": {
                        "i18n_text": "i18n.ProfileManagement.EmailId",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxPushIconInfo2": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "37%"
                        },
                        "segmentProps": []
                    },
                    "flxNotifIconInfo2": {
                        "left": {
                            "type": "string",
                            "value": "4.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxChannelsFrequency": {
                        "segmentProps": []
                    },
                    "flxChannelsFrequencyTab": {
                        "height": {
                            "type": "string",
                            "value": "130px"
                        },
                        "segmentProps": []
                    },
                    "flxCategoryChannelsTab": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxCategoryFrequencyTab": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFrequency1Tab": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxFrequency2Tab": {
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxFrequency3Tab": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsSegment": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxNoAlertsFound": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMessage": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnAlertSave": {
                        "right": {
                            "type": "number",
                            "value": "5"
                        },
                        "segmentProps": []
                    },
                    "btnAlertCancel": {
                        "right": {
                            "type": "string",
                            "value": "175px"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteContent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Are you sure you want to remove your profile picture?",
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "skin": "sknSupportedFileTypes",
                        "text": "Settings",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "number",
                            "value": "10"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "skin": "bbSKnFlxffffff",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "skin": "bbSKnFlxffffff",
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsHeaderContainer": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnEditAlerts": {
                        "height": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxInvalidAmount": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "ToggleSwitch": {
                        "skin": "sknSwitchToggle1",
                        "segmentProps": []
                    },
                    "rtxAlertsWarning": {
                        "segmentProps": []
                    },
                    "flxSMSIconInfo": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxEmailIconInfo": {
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxPushIconInfo": {
                        "left": {
                            "type": "string",
                            "value": "34%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxNotifIconInfo": {
                        "left": {
                            "type": "string",
                            "value": "57%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxChannelsFrequency": {
                        "segmentProps": []
                    },
                    "flxCategoryChannels": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCategoryFrequency": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAlertsSegment": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxNoAlertsFound": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMessage": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnAlertSave": {
                        "right": {
                            "type": "number",
                            "value": "5"
                        },
                        "segmentProps": []
                    },
                    "btnAlertCancel": {
                        "right": {
                            "type": "string",
                            "value": "175px"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmAccountAlertsEdit": {
                        "segmentProps": []
                    },
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsHeaderContainer": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnEditAlerts": {
                        "height": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxInvalidAmount": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "ToggleSwitch": {
                        "skin": "sknSwitchToggle1",
                        "segmentProps": []
                    },
                    "rtxAlertsWarning": {
                        "segmentProps": []
                    },
                    "flxSMSIconInfo": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxEmailIconInfo": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxPushIconInfo": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxNotifIconInfo": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxChannelsFrequency": {
                        "segmentProps": []
                    },
                    "flxCategoryChannels": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCategoryFrequency": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxChannelsFrequencyTab": {
                        "segmentProps": []
                    },
                    "flxAlertsSegment": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "segAlertsListing": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoAlertsFound": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMessage": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnAlertSave": {
                        "right": {
                            "type": "number",
                            "value": "5"
                        },
                        "segmentProps": []
                    },
                    "btnAlertCancel": {
                        "right": {
                            "type": "string",
                            "value": "175px"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxprofileDeleteHeader": {
                        "skin": "CopyslFbox",
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customfooternew": {
                    "height": "100dp"
                },
                "customfooternew.flxFooterMenu": {
                    "top": "26.60%"
                },
                "customfooternew.lblCopyright": {
                    "top": "75dp"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmAccountAlertsEdit,
            "enabledForIdleTimeout": true,
            "id": "frmAccountAlertsEdit",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_e3cb0e68fe06450bba1440830ec197ff(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AlertSettingsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});