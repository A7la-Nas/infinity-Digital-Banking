define("ArrangementsMA/MortgageServicesUIModule/frmRepaymentSimulation", function() {
    return function(controller) {
        function addWidgetsfrmRepaymentSimulation() {
            this.setDefaultUnit(kony.flex.DP);
            var formTemplate12 = new com.InfinityOLB.Resources.formTemplate12({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "100%",
                "id": "formTemplate12",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "ICSknFlxF7F8F7Border",
                "top": "-2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formTemplate12",
                "overrides": {
                    "flxContentPopup": {
                        "isVisible": false
                    },
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formTemplate12_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmRepaymentSimulation"] && appConfig.componentMetadata["ResourcesMA"]["frmRepaymentSimulation"]["formTemplate12"]) || {};
            formTemplate12.serviceParameters = formTemplate12_data.serviceParameters || {};
            formTemplate12.customPopupData = formTemplate12_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formTemplate12.dataFormatting = formTemplate12_data.dataFormatting || {};
            formTemplate12.dataMapping = formTemplate12_data.dataMapping || {};
            formTemplate12.conditionalMappingKey = formTemplate12_data.conditionalMappingKey || "";
            formTemplate12.conditionalMapping = formTemplate12_data.conditionalMapping || {};
            formTemplate12.pageTitle = formTemplate12_data.pageTitle || "Partial Repayment";
            formTemplate12.pageTitlei18n = formTemplate12_data.pageTitlei18n || "i18n.accounts.PartialRepayment";
            formTemplate12.primaryLinks = formTemplate12_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formTemplate12.flxMainWrapperzIndex = formTemplate12_data.flxMainWrapperzIndex || 2;
            formTemplate12.secondaryLinks = formTemplate12_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formTemplate12.supplementaryLinks = formTemplate12_data.supplementaryLinks || [];
            formTemplate12.pageTitleVisibility = formTemplate12_data.pageTitleVisibility || true;
            formTemplate12.logoConfig = formTemplate12_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formTemplate12.accountText = formTemplate12_data.accountText || "";
            formTemplate12.logoutConfig = formTemplate12_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formTemplate12.profileConfig = formTemplate12_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formTemplate12.activeMenuID = formTemplate12_data.activeMenuID || "";
            formTemplate12.activeSubMenuID = formTemplate12_data.activeSubMenuID || "";
            formTemplate12.backFlag = formTemplate12_data.backFlag || false;
            formTemplate12.hamburgerConfig = formTemplate12_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formTemplate12.backProperties = formTemplate12_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.breadCrumbProperties = formTemplate12_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.genricMessage = formTemplate12_data.genricMessage || {};
            formTemplate12.sessionTimeOutData = formTemplate12_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formTemplate12.footerProperties = formTemplate12_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formTemplate12.copyRight = formTemplate12_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 100
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopup1 = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup1",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxTC = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "460dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": true,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "150dp",
                "width": "60%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8Border0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this popup"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "sknImgPointer5vs",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeparator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\n • The simulated result which is being displayed is valid till 27-03-2027.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC);
            var flxTCCheckBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTCCheckBox",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCCheckBox.setDefaultUnit(kony.flex.DP);
            var lblIAccept = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblIAccept",
                "isVisible": true,
                "left": "6%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IAcceptTC\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTCContentsCheckbox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTCContentsCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxTCContentsCheckbox.setDefaultUnit(kony.flex.DP);
            var imgTCContentsCheckbox = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20dp",
                "id": "imgTCContentsCheckbox",
                "isVisible": false,
                "left": "0dp",
                "skin": "slImage",
                "src": "unchecked_box.png",
                "top": "0px",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Terms And Conditions"
            });
            var lblTCContentsCheckbox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTCContentsCheckbox",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblOLBFontsE3E3E320pxOlbFontIcons",
                "text": "D",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContentsCheckbox.add(imgTCContentsCheckbox, lblTCContentsCheckbox);
            flxTCCheckBox.add(lblIAccept, flxTCContentsCheckbox);
            var flxSeparator4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeparator4",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator4.setDefaultUnit(kony.flex.DP);
            flxSeparator4.add();
            var flxContentsButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "90px",
                "id": "flxContentsButtons",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "-1dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentsButtons.setDefaultUnit(kony.flex.DP);
            var btnCancelTnC = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "50dp",
                "id": "btnCancelTnC",
                "isVisible": true,
                "left": "35%",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "29.74%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            var btnSaveTnC = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "bottom": 30,
                "centerY": "50%",
                "height": "50dp",
                "id": "btnSaveTnC",
                "isVisible": true,
                "left": "67%",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "width": "29.74%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Save"
            });
            flxContentsButtons.add(btnCancelTnC, btnSaveTnC);
            var flxScrollDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxScrollDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetails.setDefaultUnit(kony.flex.DP);
            var flxDummy1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxDummy1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy1.setDefaultUnit(kony.flex.DP);
            flxDummy1.add();
            var flxBodyTnC = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxBodyTnC",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyTnC.setDefaultUnit(kony.flex.DP);
            flxBodyTnC.add();
            var flxSpacing = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxScrollDetails.add(flxDummy1, flxBodyTnC, flxSpacing);
            flxTC.add(flxTermsAndConditionsHeader, flxSeparator3, flxTCContents, flxTCCheckBox, flxSeparator4, flxContentsButtons, flxScrollDetails);
            flxPopup.add(CustomPopup1, flxTC);
            formTemplate12.flxContentPopup.add(flxPopup);
            var flxContentMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContentMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentMain.setDefaultUnit(kony.flex.DP);
            var flxBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var flxError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var lblError = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblError",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblErrorEE0005SSP15px",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError.add(lblError);
            var flxFacilityDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "id": "flxFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFboxshadow1rad4px",
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityDetails.setDefaultUnit(kony.flex.DP);
            var flxFacilityHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "id": "flxFacilityHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityHeader.setDefaultUnit(kony.flex.DP);
            var lblFacilityDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblFacilityDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.displayMortgageFacilityDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxFacilityContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "id": "flxFacilityContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "50",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityContent.setDefaultUnit(kony.flex.DP);
            var lblFacilityName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFacilityName",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.faciltyNameWithColon\")",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityNameVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFacilityNameVal",
                "isVisible": true,
                "left": "255dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "Mortgage Facility Account - 1234 ",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBal",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.outstandingBalanceWithColon\")",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBalVal",
                "isVisible": true,
                "left": "255dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$38,000.00",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoans = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoOfLoans",
                "isVisible": true,
                "left": "55%",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.NoOfLoansWithColon\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoansVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoOfLoansVal",
                "isVisible": true,
                "left": "75%",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "2",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountPaidToDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAmountPaidToDate",
                "isVisible": true,
                "left": "55%",
                "skin": "ICSknLblSSP72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.amountPaidtoDate\")",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountPaidToDateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAmountPaidToDateVal",
                "isVisible": true,
                "left": "75%",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "$3255.00",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFacilityContent.add(lblFacilityName, lblFacilityNameVal, lblOutstandingBal, lblOutstandingBalVal, lblNoOfLoans, lblNoOfLoansVal, lblAmountPaidToDate, lblAmountPaidToDateVal);
            flxFacilityHeader.add(lblFacilityDetails, flxSeparator, flxFacilityContent);
            flxFacilityDetails.add(flxFacilityHeader);
            var flxRepaymentAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRepaymentAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFboxshadow1rad4px",
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRepaymentAmount.setDefaultUnit(kony.flex.DP);
            var lblRepaymentAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblRepaymentAmount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Please enter the repayment amount for the loans selected and simulate to get new repayment values",
                "top": "15dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSegLoanReductionSimulation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "5dp",
                "clipBounds": false,
                "id": "flxSegLoanReductionSimulation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegLoanReductionSimulation.setDefaultUnit(kony.flex.DP);
            var segLoanReductionSimulation = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "btnSimulate": "Simulate",
                    "imgRadioBtn1": "M",
                    "imgRadioBtn2": "L",
                    "lblAmount": "Amount:",
                    "lblBalanceAmount": "Balance Amount: $135,250.00",
                    "lblCurrencyAccessibility": "Label",
                    "lblInstallments": "Installments",
                    "lblLoan": "Loan 1:",
                    "lblLoanAccount": "Primary Loan Account Name - 8760",
                    "lblReduction": "Reduction in:",
                    "lblTenure": "Tenure",
                    "tbxAmount": {
                        "placeholder": "",
                        "text": ""
                    },
                    "tbxCurrency": {
                        "placeholder": "",
                        "text": ""
                    }
                }],
                "groupCells": false,
                "id": "segLoanReductionSimulation",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxSimulation"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnSimulate": "btnSimulate",
                    "flxAmount": "flxAmount",
                    "flxContent": "flxContent",
                    "flxLoan": "flxLoan",
                    "flxLoanAmount": "flxLoanAmount",
                    "flxRadioBtn1": "flxRadioBtn1",
                    "flxRadioBtn2": "flxRadioBtn2",
                    "flxRadioButtons": "flxRadioButtons",
                    "flxReduction": "flxReduction",
                    "flxSimulation": "flxSimulation",
                    "flxSpace": "flxSpace",
                    "flxSpace2": "flxSpace2",
                    "flxTextButton": "flxTextButton",
                    "imgRadioBtn1": "imgRadioBtn1",
                    "imgRadioBtn2": "imgRadioBtn2",
                    "lblAmount": "lblAmount",
                    "lblBalanceAmount": "lblBalanceAmount",
                    "lblCurrencyAccessibility": "lblCurrencyAccessibility",
                    "lblInstallments": "lblInstallments",
                    "lblLoan": "lblLoan",
                    "lblLoanAccount": "lblLoanAccount",
                    "lblReduction": "lblReduction",
                    "lblTenure": "lblTenure",
                    "tbxAmount": "tbxAmount",
                    "tbxCurrency": "tbxCurrency"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegLoanReductionSimulation.add(segLoanReductionSimulation);
            var flxSimullation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxSimullation",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "30dp",
                "isModalContainer": false,
                "right": "0",
                "top": "20dp",
                "width": "95%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimullation.setDefaultUnit(kony.flex.DP);
            var flxSpace = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSpace",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpace.setDefaultUnit(kony.flex.DP);
            flxSpace.add();
            var flxReduction = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxReduction",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "44%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReduction.setDefaultUnit(kony.flex.DP);
            var lblReduction = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblReduction",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Reduction in:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRadioButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "radiogroup",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxRadioButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRadioButtons.setDefaultUnit(kony.flex.DP);
            var flxRadioBtn1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "radio",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxRadioBtn1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRadioBtn1.setDefaultUnit(kony.flex.DP);
            var imgRadioBtn1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgRadioBtn1",
                "isVisible": true,
                "left": "0",
                "skin": "sknRadioselectedFonticon",
                "text": "M",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRadioBtn1.add(imgRadioBtn1);
            var lblTenure = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "51%",
                "id": "lblTenure",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Tenure",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRadioBtn2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "radio",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxRadioBtn2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50dp",
                "isModalContainer": false,
                "top": "0",
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRadioBtn2.setDefaultUnit(kony.flex.DP);
            var imgRadioBtn2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgRadioBtn2",
                "isVisible": true,
                "left": "0",
                "skin": "sknRadioselectedFonticon",
                "text": "L",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRadioBtn2.add(imgRadioBtn2);
            var lblInstallments = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "51%",
                "id": "lblInstallments",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Installments",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRadioButtons.add(flxRadioBtn1, lblTenure, flxRadioBtn2, lblInstallments);
            flxReduction.add(lblReduction, flxRadioButtons);
            var flxLoanAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLoanAmount",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "right": "-10dp",
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAmount.setDefaultUnit(kony.flex.DP);
            var flxLoan = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLoan",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "44%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoan.setDefaultUnit(kony.flex.DP);
            var lblLoan = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLoan",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Loan 1:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoanAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLoanAccount",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Primary Loan Account Name - 8760",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBalanceAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblBalanceAmount",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Balance Amount: $135,250.00",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoan.add(lblLoan, lblLoanAccount, lblBalanceAmount);
            var flxAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "44%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var lblAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAmount",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "text": "Amount:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTextButton = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTextButton",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "30dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTextButton.setDefaultUnit(kony.flex.DP);
            var tbxAmount = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxAmount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "secureTextEntry": false,
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "60%",
                "isSensitiveText": false
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var btnSimulate = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "40dp",
                "id": "btnSimulate",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnBlockedSSPFFFFFF15Px",
                "text": "Simulate",
                "top": "0",
                "width": "40%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTextButton.add(tbxAmount, btnSimulate);
            flxAmount.add(lblAmount, flxTextButton);
            flxLoanAmount.add(flxLoan, flxAmount);
            var flxSpace2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSpace2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpace2.setDefaultUnit(kony.flex.DP);
            flxSpace2.add();
            flxSimullation.add(flxSpace, flxReduction, flxLoanAmount, flxSpace2);
            var flxSep = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSep.setDefaultUnit(kony.flex.DP);
            flxSep.add();
            var flxSimulatedResults = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSimulatedResults",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulatedResults.setDefaultUnit(kony.flex.DP);
            var flxResultsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45dp",
                "id": "flxResultsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxResultsHeader.setDefaultUnit(kony.flex.DP);
            var lblSimulatedResults = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblSimulatedResults",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Simulated Results",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxResultsHeader.add(lblSimulatedResults);
            var flxLoanValues = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLoanValues",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanValues.setDefaultUnit(kony.flex.DP);
            var flxSegLoanValues = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegLoanValues",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegLoanValues.setDefaultUnit(kony.flex.DP);
            var segLoanNamenValues = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "table"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "lblAccountName2": "Primary Loan Account Name - 8760"
                        },
                        [{
                            "lblCurrAmt": "$3000",
                            "lblCurrAmtAccessibility": "$3000",
                            "lblCurrEndDate": "31/12/2023",
                            "lblCurrEndDateAccessibility": "31/12/2023",
                            "lblCurrRepayDate": "31/12/2022",
                            "lblCurrRepayDateAccessibility": "31/12/2022",
                            "lblCurrentValues": "Current Value",
                            "lblEndDate": "End Date (Maturity Date):",
                            "lblInstallmentAmt": "Installment Amount:",
                            "lblRepayDate": "Next Repayment Date:",
                            "lblSimuAmt": "$3000",
                            "lblSimuAmtAccessibility": "$3000",
                            "lblSimuEndDate": "31/12/2023",
                            "lblSimuEndDateAccessibility": "31/12/2023",
                            "lblSimuRepayDate": "31/12/2022",
                            "lblSimuRepayDateAccessibility": "31/12/2022",
                            "lblSimulatedValues": "Simulated Value"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segLoanNamenValues",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxLoanValues"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxLoanNameHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxEndDate": "flxEndDate",
                    "flxGroup": "flxGroup",
                    "flxGroup1Parent": "flxGroup1Parent",
                    "flxGroup2Parent": "flxGroup2Parent",
                    "flxInstallmentAmount": "flxInstallmentAmount",
                    "flxLoanName": "flxLoanName",
                    "flxLoanNameHeader": "flxLoanNameHeader",
                    "flxLoanValues": "flxLoanValues",
                    "flxRepaymentDate": "flxRepaymentDate",
                    "flxSeparator3": "flxSeparator3",
                    "flxSeparator4": "flxSeparator4",
                    "flxValueHeader": "flxValueHeader",
                    "flxValues": "flxValues",
                    "lblAccountName2": "lblAccountName2",
                    "lblCurrAmt": "lblCurrAmt",
                    "lblCurrAmtAccessibility": "lblCurrAmtAccessibility",
                    "lblCurrEndDate": "lblCurrEndDate",
                    "lblCurrEndDateAccessibility": "lblCurrEndDateAccessibility",
                    "lblCurrRepayDate": "lblCurrRepayDate",
                    "lblCurrRepayDateAccessibility": "lblCurrRepayDateAccessibility",
                    "lblCurrentValues": "lblCurrentValues",
                    "lblEndDate": "lblEndDate",
                    "lblInstallmentAmt": "lblInstallmentAmt",
                    "lblRepayDate": "lblRepayDate",
                    "lblSimuAmt": "lblSimuAmt",
                    "lblSimuAmtAccessibility": "lblSimuAmtAccessibility",
                    "lblSimuEndDate": "lblSimuEndDate",
                    "lblSimuEndDateAccessibility": "lblSimuEndDateAccessibility",
                    "lblSimuRepayDate": "lblSimuRepayDate",
                    "lblSimuRepayDateAccessibility": "lblSimuRepayDateAccessibility",
                    "lblSimulatedValues": "lblSimulatedValues"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegLoanValues.add(segLoanNamenValues);
            var flxSeparator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "30dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            flxLoanValues.add(flxSegLoanValues, flxSeparator2);
            var flxConfirmAndModify = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "90dp",
                "id": "flxConfirmAndModify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmAndModify.setDefaultUnit(kony.flex.DP);
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var flxCheckBoxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCheckBoxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBoxMain.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "30dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "0dp",
                "src": "info_icon_blue.png",
                "top": "0dp",
                "width": "30dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCheckMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCheckMsg",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Please read the simulation",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnTnC = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "30dp",
                "id": "btnTnC",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknBtnSSP0273E314Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Terms&Conditions\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBoxMain.add(imgInfo, lblCheckMsg, btnTnC);
            var btnSubmit = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Continue to enter payment details"
                },
                "bottom": "20dp",
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40dp",
                "id": "btnSubmit",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknbtnSSPffffff15px0273e3bg",
                "text": "Continue",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px"
            });
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel partial repayment"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "200dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "text": "Cancel",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxButtons.add(flxCheckBoxMain, btnSubmit, btnCancel);
            flxConfirmAndModify.add(flxButtons);
            flxSimulatedResults.add(flxResultsHeader, flxLoanValues, flxConfirmAndModify);
            flxRepaymentAmount.add(lblRepaymentAmount, flxSegLoanReductionSimulation, flxSimullation, flxSep, flxSimulatedResults);
            flxBody.add(flxError, flxFacilityDetails, flxRepaymentAmount);
            flxContentMain.add(flxBody);
            formTemplate12.flxContentTCCenter.add(flxContentMain);
            var flxDownloadOptions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDownloadOptions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "100dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadOptions.setDefaultUnit(kony.flex.DP);
            var flxDownload = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Download partial repayment details"
                },
                "bottom": "0dp",
                "clipBounds": false,
                "height": "25dp",
                "id": "flxDownload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "width": "40dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var lblDownload = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblDownload",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownload.add(lblDownload);
            flxDownloadOptions.add(flxDownload);
            formTemplate12.flxTCButtons.add(flxDownloadOptions);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formTemplate12": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup"]
                    },
                    "CustomPopup1": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxPopup"]
                    },
                    "flxTC": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "92.50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "lblError": {
                        "top": {
                            "type": "string",
                            "value": "-12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxError"]
                    },
                    "flxFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "285dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody"]
                    },
                    "flxFacilityHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails"]
                    },
                    "lblFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "235dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDateVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "flxRepaymentAmount": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody"]
                    },
                    "lblRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount"]
                    },
                    "flxSimullation": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount"]
                    },
                    "flxSep": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount"]
                    },
                    "flxSimulatedResults": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount"]
                    },
                    "lblSimulatedResults": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxResultsHeader"]
                    },
                    "flxSeparator2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxLoanValues"]
                    },
                    "flxConfirmAndModify": {
                        "height": {
                            "type": "string",
                            "value": "201dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults"]
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "161dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify"]
                    },
                    "flxCheckBoxMain": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "reverseLayoutDirection": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "imgInfo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons", "flxCheckBoxMain"]
                    },
                    "lblCheckMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons", "flxCheckBoxMain"]
                    },
                    "btnTnC": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons", "flxCheckBoxMain"]
                    },
                    "btnSubmit": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "flxDownloadOptions": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons"]
                    },
                    "flxDownload": {
                        "right": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "lblDownload": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICsknOlbFonts0273e317px",
                        "text": "D",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons", "flxDownloadOptions", "flxDownload"]
                    }
                },
                "1024": {
                    "CustomPopup1": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentPopup", "flxPopup"]
                    },
                    "flxTC": {
                        "segmentProps": []
                    },
                    "lblIAccept": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "btnCancelTnC": {
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "segmentProps": []
                    },
                    "btnSaveTnC": {
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "flxContentMain": {
                        "width": {
                            "type": "string",
                            "value": "98.80%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    },
                    "flxError": {
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody"]
                    },
                    "flxFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody"]
                    },
                    "flxFacilityHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails"]
                    },
                    "lblFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "left": {
                            "type": "string",
                            "value": "245dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "left": {
                            "type": "string",
                            "value": "245dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "left": {
                            "type": "string",
                            "value": "245dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDateVal": {
                        "left": {
                            "type": "string",
                            "value": "245dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "flxSegLoanReductionSimulation": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount"]
                    },
                    "flxSep": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount"]
                    },
                    "flxSimulatedResults": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount"]
                    },
                    "flxSeparator2": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxLoanValues"]
                    },
                    "flxConfirmAndModify": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults"]
                    },
                    "flxButtons": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify"]
                    },
                    "flxCheckBoxMain": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "lblCheckMsg": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons", "flxCheckBoxMain"]
                    },
                    "btnTnC": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons", "flxCheckBoxMain"]
                    },
                    "btnSubmit": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "flxDownloadOptions": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons"]
                    },
                    "flxDownload": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "lblDownload": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICsknOlbFonts0273e317px",
                        "text": "D",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons", "flxDownloadOptions", "flxDownload"]
                    }
                },
                "1366": {
                    "formTemplate12": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxTC": {
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "height": {
                            "type": "string",
                            "value": "460px"
                        },
                        "segmentProps": []
                    },
                    "btnCancelTnC": {
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "segmentProps": []
                    },
                    "btnSaveTnC": {
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "flxContentMain": {
                        "width": {
                            "type": "string",
                            "value": "101.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    },
                    "flxFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody"]
                    },
                    "flxFacilityHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails"]
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDate": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDateVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "flxSep": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount"]
                    },
                    "flxSeparator2": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxLoanValues"]
                    },
                    "flxConfirmAndModify": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults"]
                    },
                    "flxButtons": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify"]
                    },
                    "flxCheckBoxMain": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "lblCheckMsg": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons", "flxCheckBoxMain"]
                    },
                    "btnTnC": {
                        "left": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons", "flxCheckBoxMain"]
                    },
                    "btnSubmit": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "flxDownloadOptions": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons"]
                    },
                    "flxDownload": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "lblDownload": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICsknOlbFonts0273e317px",
                        "text": "D",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons", "flxDownloadOptions", "flxDownload"]
                    }
                },
                "1380": {
                    "flxTCContents": {
                        "height": {
                            "type": "string",
                            "value": "460px"
                        },
                        "segmentProps": []
                    },
                    "btnCancelTnC": {
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "segmentProps": []
                    },
                    "btnSaveTnC": {
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "flxFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody"]
                    },
                    "flxFacilityHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails"]
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDate": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "flxSep": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount"]
                    },
                    "flxSeparator2": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxLoanValues"]
                    },
                    "flxConfirmAndModify": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults"]
                    },
                    "flxButtons": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify"]
                    },
                    "flxCheckBoxMain": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "lblCheckMsg": {
                        "left": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons", "flxCheckBoxMain"]
                    },
                    "btnTnC": {
                        "left": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons", "flxCheckBoxMain"]
                    },
                    "btnSubmit": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxContentMain", "flxBody", "flxRepaymentAmount", "flxSimulatedResults", "flxConfirmAndModify", "flxButtons"]
                    },
                    "flxDownloadOptions": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons"]
                    },
                    "flxDownload": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "lblDownload": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICsknOlbFonts0273e317px",
                        "text": "D",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxTCButtons", "flxDownloadOptions", "flxDownload"]
                    }
                }
            }
            this.compInstData = {
                "formTemplate12": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formTemplate12);
        };
        return [{
            "addWidgets": addWidgetsfrmRepaymentSimulation,
            "enabledForIdleTimeout": true,
            "id": "frmRepaymentSimulation",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_i554eb7ccc7942f99b647c316858123f,
            "preShow": function(eventobject) {
                controller.AS_Form_j97180aff65543b385d961eedb3f2134(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "title": "Partial Repayment",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});