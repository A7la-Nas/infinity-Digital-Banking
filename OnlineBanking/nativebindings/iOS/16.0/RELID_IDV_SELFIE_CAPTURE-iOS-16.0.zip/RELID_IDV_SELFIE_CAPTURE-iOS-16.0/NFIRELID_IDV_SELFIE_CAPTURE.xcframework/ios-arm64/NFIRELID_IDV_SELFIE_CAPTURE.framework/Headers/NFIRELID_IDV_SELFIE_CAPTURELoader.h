#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIRELID_IDV_SELFIE_CAPTUREModules(JSContext* context);
JSValue* extractNFIRELID_IDV_SELFIE_CAPTUREStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIRELID_IDV_SELFIE_CAPTUREStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
