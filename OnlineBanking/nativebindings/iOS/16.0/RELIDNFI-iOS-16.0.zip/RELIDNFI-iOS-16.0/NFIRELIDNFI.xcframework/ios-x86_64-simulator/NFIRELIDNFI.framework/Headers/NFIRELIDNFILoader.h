#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIRELIDNFIModules(JSContext* context);
JSValue* extractNFIRELIDNFIStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIRELIDNFIStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
