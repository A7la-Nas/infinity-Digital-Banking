#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
	context[@"CGAffineTransformMake"] = ^CGAffineTransform(CGFloat arg0, CGFloat arg1, CGFloat arg2, CGFloat arg3, CGFloat arg4, CGFloat arg5) {
		return CGAffineTransformMake(arg0, arg1, arg2, arg3, arg4, arg5);
	};
	context[@"CGAffineTransformMakeTranslation"] = ^CGAffineTransform(CGFloat arg0, CGFloat arg1) {
		return CGAffineTransformMakeTranslation(arg0, arg1);
	};
	context[@"CGAffineTransformMakeScale"] = ^CGAffineTransform(CGFloat arg0, CGFloat arg1) {
		return CGAffineTransformMakeScale(arg0, arg1);
	};
	context[@"CGAffineTransformMakeRotation"] = ^CGAffineTransform(CGFloat arg0) {
		return CGAffineTransformMakeRotation(arg0);
	};
	context[@"CGAffineTransformIsIdentity"] = ^_Bool(CGAffineTransform arg0) {
		return CGAffineTransformIsIdentity(arg0);
	};
	context[@"CGAffineTransformTranslate"] = ^CGAffineTransform(CGAffineTransform arg0, CGFloat arg1, CGFloat arg2) {
		return CGAffineTransformTranslate(arg0, arg1, arg2);
	};
	context[@"CGAffineTransformScale"] = ^CGAffineTransform(CGAffineTransform arg0, CGFloat arg1, CGFloat arg2) {
		return CGAffineTransformScale(arg0, arg1, arg2);
	};
	context[@"CGAffineTransformRotate"] = ^CGAffineTransform(CGAffineTransform arg0, CGFloat arg1) {
		return CGAffineTransformRotate(arg0, arg1);
	};
	context[@"CGAffineTransformInvert"] = ^CGAffineTransform(CGAffineTransform arg0) {
		return CGAffineTransformInvert(arg0);
	};
	context[@"CGAffineTransformConcat"] = ^CGAffineTransform(CGAffineTransform arg0, CGAffineTransform arg1) {
		return CGAffineTransformConcat(arg0, arg1);
	};
	context[@"CGAffineTransformEqualToTransform"] = ^_Bool(CGAffineTransform arg0, CGAffineTransform arg1) {
		return CGAffineTransformEqualToTransform(arg0, arg1);
	};
	context[@"CGPointApplyAffineTransform"] = ^CGPoint(CGPoint arg0, CGAffineTransform arg1) {
		return CGPointApplyAffineTransform(arg0, arg1);
	};
	context[@"CGSizeApplyAffineTransform"] = ^CGSize(CGSize arg0, CGAffineTransform arg1) {
		return CGSizeApplyAffineTransform(arg0, arg1);
	};
	context[@"CGRectApplyAffineTransform"] = ^CGRect(CGRect arg0, CGAffineTransform arg1) {
		return CGRectApplyAffineTransform(arg0, arg1);
	};
	context[@"CGAffineTransformDecompose"] = ^CGAffineTransformComponents(CGAffineTransform arg0) {
		return CGAffineTransformDecompose(arg0);
	};
	context[@"CGAffineTransformMakeWithComponents"] = ^CGAffineTransform(CGAffineTransformComponents arg0) {
		return CGAffineTransformMakeWithComponents(arg0);
	};
	context[@"__CGAffineTransformMake"] = ^CGAffineTransform(CGFloat arg0, CGFloat arg1, CGFloat arg2, CGFloat arg3, CGFloat arg4, CGFloat arg5) {
		return __CGAffineTransformMake(arg0, arg1, arg2, arg3, arg4, arg5);
	};
	context[@"__CGPointApplyAffineTransform"] = ^CGPoint(CGPoint arg0, CGAffineTransform arg1) {
		return __CGPointApplyAffineTransform(arg0, arg1);
	};
	context[@"__CGSizeApplyAffineTransform"] = ^CGSize(CGSize arg0, CGAffineTransform arg1) {
		return __CGSizeApplyAffineTransform(arg0, arg1);
	};
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &CGAffineTransformIdentity;
	if (p != NULL) context[@"CGAffineTransformIdentity"] = [JSValue valueWithCGAffineTransform: CGAffineTransformIdentity inContext: context];
}
void load_CoreGraphics_CGAffineTransform_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
