#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation RDNAClient (Exports)
-(void) jsinitialize: (NSString *) agentInfo : (JSValue *) callbacks : (NSString *) gwHNIP : (uint16_t) gwPort : (NSString *) cipherSpec : (NSString *) cipherSalt : (NSString *) proxySettings : (NSString *) rdnaSSLCertificate : (int) loggingLevel : (JSValue *) syncCallback 
{
	[self initialize: agentInfo : callbacks : gwHNIP : gwPort : cipherSpec : cipherSalt : proxySettings : rdnaSSLCertificate : loggingLevel : syncCallback ];
}
-(NSString *) jsinitiateUpdateFlowForCredential: (NSString *) credentialName 
{
	NSString * resultVal__;
	resultVal__ = [self initiateUpdateFlowForCredential: credentialName ];
	return resultVal__;
}
-(NSString *) jsinitiateIDVServerBiometricAuthentication: (NSString *) reason : (int) retries 
{
	NSString * resultVal__;
	resultVal__ = [self initiateIDVServerBiometricAuthentication: reason : retries ];
	return resultVal__;
}
-(NSString *) jsinitiateIDVBiometricOptIn
{
	NSString * resultVal__;
	resultVal__ = [self initiateIDVBiometricOptIn];
	return resultVal__;
}
-(NSString *) jsinitiateIDVBiometricOptOut
{
	NSString * resultVal__;
	resultVal__ = [self initiateIDVBiometricOptOut];
	return resultVal__;
}
-(NSString *) jsinitiateIDVAdditionalDocumentScan: (NSString *) reason 
{
	NSString * resultVal__;
	resultVal__ = [self initiateIDVAdditionalDocumentScan: reason ];
	return resultVal__;
}
-(NSString *) jsinitiateActivatedCustomerKYC: (NSString *) reason 
{
	NSString * resultVal__;
	resultVal__ = [self initiateActivatedCustomerKYC: reason ];
	return resultVal__;
}
-(NSString *) jsinitiateAgentKYCforUser: (NSString *) userID : (NSString *) reason 
{
	NSString * resultVal__;
	resultVal__ = [self initiateAgentKYCforUser: userID : reason ];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([RDNAClient class], @protocol(RDNAClientInstanceExports));
	class_addProtocol([RDNAClient class], @protocol(RDNAClientClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_RELIDNFI_RDNAClient_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
