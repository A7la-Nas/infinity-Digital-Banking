#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_RELIDNFI_RDNAClient_symbols(JSContext*);
@protocol RDNAClientInstanceExports<JSExport>
-(void) updateRDNAClientCallback: (JSValue *) callbacks ;
-(void) updateRDNAClientIDVCallback: (JSValue *) callbacks ;
JSExportAs(initialize,
-(void) jsinitialize: (NSString *) agentInfo : (JSValue *) callbacks : (NSString *) gwHNIP : (uint16_t) gwPort : (NSString *) cipherSpec : (NSString *) cipherSalt : (NSString *) proxySettings : (NSString *) rdnaSSLCertificate : (int) loggingLevel : (JSValue *) syncCallback );
-(NSString *) logOff: (NSString *) userID ;
-(NSString *) terminate;
-(NSString *) pauseRuntime;
-(NSString *) resumeRuntime: (NSString *) state : (NSValue *) callbacks : (NSString *) proxySettings : (int) loggingLevel ;
-(NSString *) getAllChallenges: (NSString *) userID ;
-(NSString *) getNotifications: (int) recordCount : (NSString *) enterpriseID : (int) startIndex : (NSString *) startDate : (NSString *) endDate ;
-(NSString *) getNotificationHistory: (int) recordCount : (NSString *) enterpriseID : (int) startIndex : (NSString *) startDate : (NSString *) endDate : (NSString *) notificationStatus : (NSString *) actionPerformed : (NSString *) keywordSearch : (NSString *) deviceID ;
-(NSString *) updateNotification: (NSString *) notificationID : (NSString *) response ;
-(NSString *) getRegisteredDeviceDetails: (NSString *) deviceDetailsJson ;
-(NSString *) updateDeviceDetails: (NSString *) userID : (NSString *) devices ;
-(NSString *) setDeviceToken: (NSString *) deviceToken ;
-(NSString *) getSessionID;
-(NSString *) getAgentID;
-(NSString *) getDeviceID;
-(NSString *) getDefaultCipherSpec;
-(NSString *) getDefaultCipherSalt;
-(NSString *) getSDKVersion;
-(NSString *) getAllServices;
-(NSString *) getServiceByServiceName: (NSString *) serviceName ;
-(NSString *) getServiceByTargetCoordinate: (NSString *) targetHNIP : (uint16_t) targetPORT ;
-(NSString *) serviceAccessStart: (NSString *) service ;
-(NSString *) serviceAccessStop: (NSString *) service ;
-(NSString *) serviceAccessStartAll;
-(NSString *) serviceAccessStopAll;
-(NSString *) encryptDataPacket: (int) privacyScope : (NSString *) cipherSpec : (NSString *) cipherSalt : (NSString *) plainText ;
-(NSString *) decryptDataPacket: (int) privacyScope : (NSString *) cipherSpec : (NSString *) cipherSalt : (NSString *) cipherText ;
-(NSString *) encryptHttpRequest: (int) privacyScope CipherSpec: (NSString *) cipherSpec CipherSalt: (NSString *) cipherSalt From: (NSString *) request ;
-(NSString *) decryptHttpResponse: (int) privacyScope : (NSString *) cipherSpec : (NSString *) cipherSalt : (NSString *) transformedResponse ;
-(NSString *) getPostLoginChallenges: (NSString *) userID : (NSString *) useCaseName ;
-(NSString *) getConfig: (NSString *) configRequest ;
-(NSString *) setCredentials: (id) userID : (NSString *) password : (BOOL) authStatus ;
-(NSString *) openHttpConnection: (int) method : (NSString *) url : (NSString *) headers : (NSString *) body ;
-(NSString *) setUser: (NSString *) userID ;
-(NSString *) setActivationCode: (NSString *) activationCode ;
-(NSString *) activateUsing: (NSString *) choice ;
-(NSString *) setDeviceName: (NSString *) deviceName ;
-(NSString *) setPassword: (NSString *) password : (int) mode ;
-(NSString *) setUserConsentForLDA: (BOOL) shouldEnrollLDA : (int) challengeMode : (int) authenticationType ;
-(NSString *) updatePassword: (NSString *) currentPassword : (NSString *) newPassword : (int) mode ;
-(NSString *) setAccessCode: (NSString *) accessCode ;
-(NSString *) performVerifyAuth: (BOOL) status ;
-(NSString *) generateTOTP: (NSString *) userID ;
-(NSString *) setTOTPPassword: (NSString *) password ;
-(NSString *) fetchRegisteredTOTPUsers;
-(NSString *) resetAuthState;
-(NSString *) addAlternateLoginId: (NSString *) loginId ;
JSExportAs(initiateUpdateFlowForCredential,
-(NSString *) jsinitiateUpdateFlowForCredential: (NSString *) credentialName );
-(NSString *) setCustomChallengeResponse: (NSString *) challengeResponse ;
-(NSString *) fallbackNewDeviceActivationFlow;
-(NSString *) forgotLoginID: (NSString *) requestType : (NSString *) requestData ;
-(NSString *) getSecurityThreatLogs: (int) startIndex : (int) count ;
-(NSString *) takeActionOnThreats: (NSString *) userConsentThreats ;
-(NSString *) setSecretQuestionAnswer: (NSArray *) response : (int) mode ;
-(NSString *) forgotPassword;
-(NSString *) resendActivationCode;
-(NSString *) resendAccessCode;
-(NSString *) getDeviceAuthenticationDetails;
-(NSString *) manageDeviceAuthenticationModes: (BOOL) isEnabled : (int) authenticationType ;
-(NSString *) resetBlockedUserAccount;
-(NSString *) requestNewAccessToken: (NSString *) reasonForRefresh ;
-(NSString *) enrollUser: (NSString *) userID : (NSString *) firstName : (NSString *) lastName : (NSString *) email : (NSString *) mobileNumber : (NSString *) groupName ;
-(NSString *) authenticateUserAndSignData: (NSString *) payload : (int) authLevel : (int) authenticatorType : (NSString *) reason ;
-(NSString *) resetAuthenticateUserAndSignDataState;
-(NSString *) setIDVDocumentScanProcessStartConfirmation: (BOOL) isConfirm : (int) workflow ;
-(NSString *) setIDVSelfieProcessStartConfirmation: (BOOL) isConfirm : (BOOL) useDeviceBackCamera : (int) workflow ;
-(NSString *) setIDVConfirmDocumentDetails: (BOOL) isConfirm : (int) opMode ;
-(NSString *) setIDVSelfieConfirmation: (NSString *) action : (int) opMode ;
-(NSString *) setIDVBiometricOptInConsent: (BOOL) isOptIn : (int) opMode ;
-(NSString *) checkIDVUserBiometricTemplateStatus;
JSExportAs(initiateIDVServerBiometricAuthentication,
-(NSString *) jsinitiateIDVServerBiometricAuthentication: (NSString *) reason : (int) retries );
-(NSString *) jsinitiateIDVBiometricOptIn;
-(NSString *) setIDVBiometricOptInConfirmation: (int) status ;
-(NSString *) jsinitiateIDVBiometricOptOut;
JSExportAs(initiateIDVAdditionalDocumentScan,
-(NSString *) jsinitiateIDVAdditionalDocumentScan: (NSString *) reason );
JSExportAs(initiateActivatedCustomerKYC,
-(NSString *) jsinitiateActivatedCustomerKYC: (NSString *) reason );
JSExportAs(initiateAgentKYCforUser,
-(NSString *) jsinitiateAgentKYCforUser: (NSString *) userID : (NSString *) reason );
-(NSString *) getIDVConfig;
-(NSString *) setIDVConfig: (NSString *) configJson ;
@end
@protocol RDNAClientClassExports<JSExport>
+(id) sharedInstance;
@end
#pragma clang diagnostic pop