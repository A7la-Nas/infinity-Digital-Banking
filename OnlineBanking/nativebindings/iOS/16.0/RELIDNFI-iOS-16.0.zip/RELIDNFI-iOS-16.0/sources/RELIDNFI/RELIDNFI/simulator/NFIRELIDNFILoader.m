#import "allincludes.h"
#import <JavaScriptCore/JavaScriptCore.h>
void loadNFIRELIDNFIModules(JSContext* context)
{
	load_RELIDNFI_RDNAClient_symbols(context);
	load_RELIDNFI_RELIDNFI_symbols(context);
}

JSValue* extractNFIRELIDNFIStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context)
{
    
    return nil;
}

BOOL setNFIRELIDNFIStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation)
{
    
    return NO;
}

