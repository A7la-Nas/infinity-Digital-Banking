#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIRELIDModules(JSContext* context);
JSValue* extractNFIRELIDStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIRELIDStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
