#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLVisit_symbols(JSContext*);
@protocol CLVisitInstanceExports<JSExport, NSSecureCodingInstanceExports_, NSCopyingInstanceExports_>
@property (readonly,copy,nonatomic) NSDate * arrivalDate;
@property (readonly,copy,nonatomic) NSDate * departureDate;
@property (readonly,nonatomic) CLLocationCoordinate2D coordinate;
@property (readonly,nonatomic) CLLocationAccuracy horizontalAccuracy;
@end
@protocol CLVisitClassExports<JSExport, NSSecureCodingClassExports_, NSCopyingClassExports_>
@end
#pragma clang diagnostic pop