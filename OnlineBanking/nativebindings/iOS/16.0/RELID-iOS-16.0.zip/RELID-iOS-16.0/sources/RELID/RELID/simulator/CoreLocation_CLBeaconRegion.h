#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLBeaconRegion_symbols(JSContext*);
@protocol CLBeaconRegionInstanceExports<JSExport>
@property (readonly,copy,nonatomic) CLBeaconIdentityConstraint * beaconIdentityConstraint;
@property (readonly,copy,nonatomic) NSUUID * UUID;
@property (readonly,copy,nonatomic) NSUUID * proximityUUID;
@property (readonly,copy,nonatomic) NSNumber * major;
@property (readonly,copy,nonatomic) NSNumber * minor;
@property (assign,atomic) BOOL notifyEntryStateOnDisplay;
JSExportAs(initWithUUIDIdentifier,
-(id) jsinitWithUUID: (NSUUID *) uuid identifier: (NSString *) identifier );
JSExportAs(initWithProximityUUIDIdentifier,
-(id) jsinitWithProximityUUID: (NSUUID *) proximityUUID identifier: (NSString *) identifier );
JSExportAs(initWithUUIDMajorIdentifier,
-(id) jsinitWithUUID: (NSUUID *) uuid major: (CLBeaconMajorValue) major identifier: (NSString *) identifier );
JSExportAs(initWithProximityUUIDMajorIdentifier,
-(id) jsinitWithProximityUUID: (NSUUID *) proximityUUID major: (CLBeaconMajorValue) major identifier: (NSString *) identifier );
JSExportAs(initWithUUIDMajorMinorIdentifier,
-(id) jsinitWithUUID: (NSUUID *) uuid major: (CLBeaconMajorValue) major minor: (CLBeaconMinorValue) minor identifier: (NSString *) identifier );
JSExportAs(initWithProximityUUIDMajorMinorIdentifier,
-(id) jsinitWithProximityUUID: (NSUUID *) proximityUUID major: (CLBeaconMajorValue) major minor: (CLBeaconMinorValue) minor identifier: (NSString *) identifier );
JSExportAs(initWithBeaconIdentityConstraintIdentifier,
-(id) jsinitWithBeaconIdentityConstraint: (CLBeaconIdentityConstraint *) beaconIdentityConstraint identifier: (NSString *) identifier );
-(NSMutableDictionary *) peripheralDataWithMeasuredPower: (NSNumber *) measuredPower ;
@end
@protocol CLBeaconRegionClassExports<JSExport>
@end
@protocol CLBeaconInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSDate * timestamp;
@property (readonly,copy,nonatomic) NSUUID * UUID;
@property (readonly,copy,nonatomic) NSUUID * proximityUUID;
@property (readonly,copy,nonatomic) NSNumber * major;
@property (readonly,copy,nonatomic) NSNumber * minor;
@property (readonly,nonatomic) CLProximity proximity;
@property (readonly,nonatomic) CLLocationAccuracy accuracy;
@property (readonly,nonatomic) NSInteger rssi;
@end
@protocol CLBeaconClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop