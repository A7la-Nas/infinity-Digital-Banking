#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLHeading_symbols(JSContext*);
@protocol CLHeadingInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) CLLocationDirection magneticHeading;
@property (readonly,nonatomic) CLLocationDirection trueHeading;
@property (readonly,nonatomic) CLLocationDirection headingAccuracy;
@property (readonly,nonatomic) CLHeadingComponentValue x;
@property (readonly,nonatomic) CLHeadingComponentValue y;
@property (readonly,nonatomic) CLHeadingComponentValue z;
@property (readonly,copy,nonatomic) NSDate * timestamp;
@end
@protocol CLHeadingClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop