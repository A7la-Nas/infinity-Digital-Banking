#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
	class_addProtocol([RDNAPort class], @protocol(RDNAPortInstanceExports));
	class_addProtocol([RDNAPort class], @protocol(RDNAPortClassExports));
	class_addProtocol([RDNAService class], @protocol(RDNAServiceInstanceExports));
	class_addProtocol([RDNAService class], @protocol(RDNAServiceClassExports));
	class_addProtocol([RDNAResponseStatus class], @protocol(RDNAResponseStatusInstanceExports));
	class_addProtocol([RDNAResponseStatus class], @protocol(RDNAResponseStatusClassExports));
	class_addProtocol([RDNAStatusInit class], @protocol(RDNAStatusInitInstanceExports));
	class_addProtocol([RDNAStatusInit class], @protocol(RDNAStatusInitClassExports));
	class_addProtocol([RDNAStatusTerminate class], @protocol(RDNAStatusTerminateInstanceExports));
	class_addProtocol([RDNAStatusTerminate class], @protocol(RDNAStatusTerminateClassExports));
	class_addProtocol([RDNAStatusPauseRuntime class], @protocol(RDNAStatusPauseRuntimeInstanceExports));
	class_addProtocol([RDNAStatusPauseRuntime class], @protocol(RDNAStatusPauseRuntimeClassExports));
	class_addProtocol([RDNAStatusResumeRuntime class], @protocol(RDNAStatusResumeRuntimeInstanceExports));
	class_addProtocol([RDNAStatusResumeRuntime class], @protocol(RDNAStatusResumeRuntimeClassExports));
	class_addProtocol([RDNAStatusGetConfig class], @protocol(RDNAStatusGetConfigInstanceExports));
	class_addProtocol([RDNAStatusGetConfig class], @protocol(RDNAStatusGetConfigClassExports));
	class_addProtocol([RDNAProxySettings class], @protocol(RDNAProxySettingsInstanceExports));
	class_addProtocol([RDNAProxySettings class], @protocol(RDNAProxySettingsClassExports));
	class_addProtocol([RDNADeviceDetails class], @protocol(RDNADeviceDetailsInstanceExports));
	class_addProtocol([RDNADeviceDetails class], @protocol(RDNADeviceDetailsClassExports));
	class_addProtocol([RDNAStatusGetRegisteredDeviceDetails class], @protocol(RDNAStatusGetRegisteredDeviceDetailsInstanceExports));
	class_addProtocol([RDNAStatusGetRegisteredDeviceDetails class], @protocol(RDNAStatusGetRegisteredDeviceDetailsClassExports));
	class_addProtocol([RDNAStatusUpdateDeviceDetails class], @protocol(RDNAStatusUpdateDeviceDetailsInstanceExports));
	class_addProtocol([RDNAStatusUpdateDeviceDetails class], @protocol(RDNAStatusUpdateDeviceDetailsClassExports));
	class_addProtocol([RDNAExpectedResponse class], @protocol(RDNAExpectedResponseInstanceExports));
	class_addProtocol([RDNAExpectedResponse class], @protocol(RDNAExpectedResponseClassExports));
	class_addProtocol([RDNAResponseLabel class], @protocol(RDNAResponseLabelInstanceExports));
	class_addProtocol([RDNAResponseLabel class], @protocol(RDNAResponseLabelClassExports));
	class_addProtocol([RDNANotfBody class], @protocol(RDNANotfBodyInstanceExports));
	class_addProtocol([RDNANotfBody class], @protocol(RDNANotfBodyClassExports));
	class_addProtocol([RDNANotification class], @protocol(RDNANotificationInstanceExports));
	class_addProtocol([RDNANotification class], @protocol(RDNANotificationClassExports));
	class_addProtocol([RDNANotfHistBody class], @protocol(RDNANotfHistBodyInstanceExports));
	class_addProtocol([RDNANotfHistBody class], @protocol(RDNANotfHistBodyClassExports));
	class_addProtocol([RDNANotificationHistory class], @protocol(RDNANotificationHistoryInstanceExports));
	class_addProtocol([RDNANotificationHistory class], @protocol(RDNANotificationHistoryClassExports));
	class_addProtocol([RDNAStatusGetNotifications class], @protocol(RDNAStatusGetNotificationsInstanceExports));
	class_addProtocol([RDNAStatusGetNotifications class], @protocol(RDNAStatusGetNotificationsClassExports));
	class_addProtocol([RDNAStatusUpdateNotification class], @protocol(RDNAStatusUpdateNotificationInstanceExports));
	class_addProtocol([RDNAStatusUpdateNotification class], @protocol(RDNAStatusUpdateNotificationClassExports));
	class_addProtocol([RDNAStatusGetNotificationHistory class], @protocol(RDNAStatusGetNotificationHistoryInstanceExports));
	class_addProtocol([RDNAStatusGetNotificationHistory class], @protocol(RDNAStatusGetNotificationHistoryClassExports));
	class_addProtocol([RDNAStatusCheckChallengeResponse class], @protocol(RDNAStatusCheckChallengeResponseInstanceExports));
	class_addProtocol([RDNAStatusCheckChallengeResponse class], @protocol(RDNAStatusCheckChallengeResponseClassExports));
	class_addProtocol([RDNAStatusUpdateChallenges class], @protocol(RDNAStatusUpdateChallengesInstanceExports));
	class_addProtocol([RDNAStatusUpdateChallenges class], @protocol(RDNAStatusUpdateChallengesClassExports));
	class_addProtocol([RDNAStatusGetAllChallenges class], @protocol(RDNAStatusGetAllChallengesInstanceExports));
	class_addProtocol([RDNAStatusGetAllChallenges class], @protocol(RDNAStatusGetAllChallengesClassExports));
	class_addProtocol([RDNAStatusGetPostLoginChallenges class], @protocol(RDNAStatusGetPostLoginChallengesInstanceExports));
	class_addProtocol([RDNAStatusGetPostLoginChallenges class], @protocol(RDNAStatusGetPostLoginChallengesClassExports));
	class_addProtocol([RDNAStatusForgotPassword class], @protocol(RDNAStatusForgotPasswordInstanceExports));
	class_addProtocol([RDNAStatusForgotPassword class], @protocol(RDNAStatusForgotPasswordClassExports));
	class_addProtocol([RDNAStatusLogOff class], @protocol(RDNAStatusLogOffInstanceExports));
	class_addProtocol([RDNAStatusLogOff class], @protocol(RDNAStatusLogOffClassExports));
	class_addProtocol([RDNAIWACreds class], @protocol(RDNAIWACredsInstanceExports));
	class_addProtocol([RDNAIWACreds class], @protocol(RDNAIWACredsClassExports));
	class_addProtocol([RDNAHTTPRequest class], @protocol(RDNAHTTPRequestInstanceExports));
	class_addProtocol([RDNAHTTPRequest class], @protocol(RDNAHTTPRequestClassExports));
	class_addProtocol([RDNAHTTPResponse class], @protocol(RDNAHTTPResponseInstanceExports));
	class_addProtocol([RDNAHTTPResponse class], @protocol(RDNAHTTPResponseClassExports));
	class_addProtocol([RDNAHTTPStatus class], @protocol(RDNAHTTPStatusInstanceExports));
	class_addProtocol([RDNAHTTPStatus class], @protocol(RDNAHTTPStatusClassExports));
	class_addProtocol([RDNASSLCertificate class], @protocol(RDNASSLCertificateInstanceExports));
	class_addProtocol([RDNASSLCertificate class], @protocol(RDNASSLCertificateClassExports));
	class_addProtocol([RDNAChallengeInfo class], @protocol(RDNAChallengeInfoInstanceExports));
	class_addProtocol([RDNAChallengeInfo class], @protocol(RDNAChallengeInfoClassExports));
	class_addProtocol([RDNAChallenge class], @protocol(RDNAChallengeInstanceExports));
	class_addProtocol([RDNAChallenge class], @protocol(RDNAChallengeClassExports));
	class_addProtocol([RDNAError class], @protocol(RDNAErrorInstanceExports));
	class_addProtocol([RDNAError class], @protocol(RDNAErrorClassExports));
	class_addProtocol([RDNASession class], @protocol(RDNASessionInstanceExports));
	class_addProtocol([RDNASession class], @protocol(RDNASessionClassExports));
	class_addProtocol([RDNARequestStatus class], @protocol(RDNARequestStatusInstanceExports));
	class_addProtocol([RDNARequestStatus class], @protocol(RDNARequestStatusClassExports));
	class_addProtocol([RDNAGroupInfo class], @protocol(RDNAGroupInfoInstanceExports));
	class_addProtocol([RDNAGroupInfo class], @protocol(RDNAGroupInfoClassExports));
	class_addProtocol([RDNAAdditionalInfo class], @protocol(RDNAAdditionalInfoInstanceExports));
	class_addProtocol([RDNAAdditionalInfo class], @protocol(RDNAAdditionalInfoClassExports));
	class_addProtocol([RDNAChallengeResponse class], @protocol(RDNAChallengeResponseInstanceExports));
	class_addProtocol([RDNAChallengeResponse class], @protocol(RDNAChallengeResponseClassExports));
	class_addProtocol([RDNAAppInfo class], @protocol(RDNAAppInfoInstanceExports));
	class_addProtocol([RDNAAppInfo class], @protocol(RDNAAppInfoClassExports));
	class_addProtocol([RDNANetworkInfo class], @protocol(RDNANetworkInfoInstanceExports));
	class_addProtocol([RDNANetworkInfo class], @protocol(RDNANetworkInfoClassExports));
	class_addProtocol([RDNAThreat class], @protocol(RDNAThreatInstanceExports));
	class_addProtocol([RDNAThreat class], @protocol(RDNAThreatClassExports));
	class_addProtocol([RDNAThreatDetails class], @protocol(RDNAThreatDetailsInstanceExports));
	class_addProtocol([RDNAThreatDetails class], @protocol(RDNAThreatDetailsClassExports));
	class_addProtocol([RDNAThreatLog class], @protocol(RDNAThreatLogInstanceExports));
	class_addProtocol([RDNAThreatLog class], @protocol(RDNAThreatLogClassExports));
	class_addProtocol([RDNAInitProgressStatus class], @protocol(RDNAInitProgressStatusInstanceExports));
	class_addProtocol([RDNAInitProgressStatus class], @protocol(RDNAInitProgressStatusClassExports));
	class_addProtocol([RDNAThreatLogDetails class], @protocol(RDNAThreatLogDetailsInstanceExports));
	class_addProtocol([RDNAThreatLogDetails class], @protocol(RDNAThreatLogDetailsClassExports));
	class_addProtocol([RDNASecretQuestionAndAnswer class], @protocol(RDNASecretQuestionAndAnswerInstanceExports));
	class_addProtocol([RDNASecretQuestionAndAnswer class], @protocol(RDNASecretQuestionAndAnswerClassExports));
	class_addProtocol([RDNADeviceAuthenticationDetails class], @protocol(RDNADeviceAuthenticationDetailsInstanceExports));
	class_addProtocol([RDNADeviceAuthenticationDetails class], @protocol(RDNADeviceAuthenticationDetailsClassExports));
	class_addProtocol([RDNADataSigningDetails class], @protocol(RDNADataSigningDetailsInstanceExports));
	class_addProtocol([RDNADataSigningDetails class], @protocol(RDNADataSigningDetailsClassExports));
	class_addProtocol([RDNAPrivacyStream class], @protocol(RDNAPrivacyStreamInstanceExports));
	class_addProtocol([RDNAPrivacyStream class], @protocol(RDNAPrivacyStreamClassExports));
	class_addProtocol([RDNAStruct class], @protocol(RDNAStructInstanceExports));
	class_addProtocol([RDNAStruct class], @protocol(RDNAStructClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{

	context[@"RDNA_METH_NONE"] = @0L;
	context[@"RDNA_METH_INITIALIZE"] = @1L;
	context[@"RDNA_METH_TERMINATE"] = @2L;
	context[@"RDNA_METH_RESUME"] = @3L;
	context[@"RDNA_METH_PAUSE"] = @4L;
	context[@"RDNA_METH_GET_CONFIG"] = @5L;
	context[@"RDNA_METH_CHECK_CHALLENGE"] = @6L;
	context[@"RDNA_METH_UPDATE_CHALLENGE"] = @7L;
	context[@"RDNA_METH_GET_ALL_CHALLENGES"] = @8L;
	context[@"RDNA_METH_LOGOFF"] = @9L;
	context[@"RDNA_METH_FORGOT_PASSWORD"] = @10L;
	context[@"RDNA_METH_GET_POST_LOGIN_CHALLENGES"] = @11L;
	context[@"RDNA_METH_GET_DEVICE_DETAILS"] = @12L;
	context[@"RDNA_METH_UPDATE_DEVICE_DETAILS"] = @13L;
	context[@"RDNA_METH_GET_NOTIFICATIONS"] = @14L;
	context[@"RDNA_METH_UPDATE_NOTIFICATION"] = @15L;
	context[@"RDNA_METH_GET_NOTIFICATION_HISTORY"] = @16L;
	context[@"RDNA_METH_OPEN_HTTP_CONNECTION"] = @17L;
	context[@"RDNA_ADD_ALTERNATE_LOGIN_ID"] = @18L;
	context[@"RDNA_METH_DELETE_LOGIN_ID"] = @19L;
	context[@"RDNA_METH_EDIT_LOGIN_ID"] = @20L;
	context[@"RDNA_METH_GET_ALL_REGISTERED_LOGIN_IDS"] = @21L;
	context[@"RDNA_METH_GET_NOTIFICATIONS_EX"] = @22L;


	context[@"RDNA_NO_LOGS"] = @0L;
	context[@"RDNA_LOG_WARN"] = @1L;
	context[@"RDNA_LOG_NOTIFY"] = @2L;
	context[@"RDNA_LOG_NETWORK"] = @3L;
	context[@"RDNA_LOG_DNA"] = @4L;
	context[@"RDNA_LOG_DEBUG"] = @5L;
	context[@"RDNA_LOG_VERBOSE"] = @6L;


	context[@"RDNA_ERR_NONE"] = @0L;
	context[@"RDNA_ERR_NOT_INITIALIZED"] = @1L;
	context[@"RDNA_ERR_GENERIC_ERROR"] = @2L;
	context[@"RDNA_ERR_INVALID_VERSION"] = @3L;
	context[@"RDNA_ERR_INVALID_ARGS"] = @4L;
	context[@"RDNA_ERR_SESSION_EXPIRED"] = @5L;
	context[@"RDNA_ERR_PARENT_PROXY_CONNECT_FAILED"] = @6L;
	context[@"RDNA_ERR_NULL_CALLBACKS"] = @7L;
	context[@"RDNA_ERR_INVALID_HOST"] = @8L;
	context[@"RDNA_ERR_INVALID_PORTNUM"] = @9L;
	context[@"RDNA_ERR_INVALID_AGENT_INFO"] = @10L;
	context[@"RDNA_ERR_UNSUPPORTED_AGENT_RELID"] = @11L;
	context[@"RDNA_ERR_FAILED_TO_CONNECT_TO_SERVER"] = @12L;
	context[@"RDNA_ERR_INVALID_SAVED_CONTEXT"] = @13L;
	context[@"RDNA_ERR_INVALID_HTTP_REQUEST"] = @14L;
	context[@"RDNA_ERR_INVALID_HTTP_RESPONSE"] = @15L;
	context[@"RDNA_ERR_INVALID_CIPHERSPECS"] = @16L;
	context[@"RDNA_ERR_SERVICE_NOT_SUPPORTED"] = @17L;
	context[@"RDNA_ERR_FAILED_TO_GET_STREAM_PRIVACYSCOPE"] = @18L;
	context[@"RDNA_ERR_FAILED_TO_GET_STREAM_TYPE"] = @19L;
	context[@"RDNA_ERR_FAILED_TO_WRITE_INTO_STREAM"] = @20L;
	context[@"RDNA_ERR_FAILED_TO_END_STREAM"] = @21L;
	context[@"RDNA_ERR_FAILED_TO_DESTROY_STREAM"] = @22L;
	context[@"RDNA_ERR_FAILED_TO_INITIALIZE"] = @23L;
	context[@"RDNA_ERR_FAILED_TO_PAUSERUNTIME"] = @24L;
	context[@"RDNA_ERR_FAILED_TO_RESUMERUNTIME"] = @25L;
	context[@"RDNA_ERR_FAILED_TO_TERMINATE"] = @26L;
	context[@"RDNA_ERR_FAILED_TO_GET_CIPHERSALT"] = @27L;
	context[@"RDNA_ERR_FAILED_TO_GET_CIPHERSPECS"] = @28L;
	context[@"RDNA_ERR_FAILED_TO_GET_AGENT_ID"] = @29L;
	context[@"RDNA_ERR_FAILED_TO_GET_SESSION_ID"] = @30L;
	context[@"RDNA_ERR_FAILED_TO_GET_DEVICE_ID"] = @31L;
	context[@"RDNA_ERR_FAILED_TO_GET_SERVICE"] = @32L;
	context[@"RDNA_ERR_FAILED_TO_START_SERVICE"] = @33L;
	context[@"RDNA_ERR_FAILED_TO_STOP_SERVICE"] = @34L;
	context[@"RDNA_ERR_FAILED_TO_ENCRYPT_DATA_PACKET"] = @35L;
	context[@"RDNA_ERR_FAILED_TO_DECRYPT_DATA_PACKET"] = @36L;
	context[@"RDNA_ERR_FAILED_TO_ENCRYPT_HTTP_REQUEST"] = @37L;
	context[@"RDNA_ERR_FAILED_TO_DECRYPT_HTTP_RESPONSE"] = @38L;
	context[@"RDNA_ERR_FAILED_TO_CREATE_PRIVACY_STREAM"] = @39L;
	context[@"RDNA_ERR_FAILED_TO_CHECK_CHALLENGE"] = @40L;
	context[@"RDNA_ERR_FAILED_TO_UPDATE_CHALLENGE"] = @41L;
	context[@"RDNA_ERR_FAILED_TO_GET_CONFIG"] = @42L;
	context[@"RDNA_ERR_FAILED_TO_GET_ALL_CHALLENGES"] = @43L;
	context[@"RDNA_ERR_FAILED_TO_LOGOFF"] = @44L;
	context[@"RDNA_ERR_FAILED_TO_RESET_CHALLENGE"] = @45L;
	context[@"RDNA_ERR_FAILED_TO_DO_FORGOT_PASSWORD"] = @46L;
	context[@"RDNA_ERR_FAILED_TO_GET_POST_LOGIN_CHALLENGES"] = @47L;
	context[@"RDNA_ERR_FAILED_TO_GET_REGISTERD_DEVICE_DETAILS"] = @48L;
	context[@"RDNA_ERR_FAILED_TO_UPDATE_DEVICE_DETAILS"] = @49L;
	context[@"RDNA_ERR_FAILED_TO_GET_NOTIFICATIONS"] = @50L;
	context[@"RDNA_ERR_FAILED_TO_UPDATE_NOTIFICATION"] = @51L;
	context[@"RDNA_ERR_FAILED_TO_OPEN_HTTP_CONNECTION"] = @52L;
	context[@"RDNA_ERR_SSL_INIT_FAILED"] = @53L;
	context[@"RDNA_ERR_SSL_ACTIVITY_FAILED"] = @54L;
	context[@"RDNA_ERR_DNS_FAILED"] = @55L;
	context[@"RDNA_ERR_NET_DOWN"] = @56L;
	context[@"RDNA_ERR_SOCK_TIMEDOUT"] = @57L;
	context[@"RDNA_ERR_DNA_INTERNAL"] = @58L;
	context[@"RDNA_ERR_INVALID_USER_MR_STATE"] = @59L;
	context[@"RDNA_ERR_NOTF_SIGN_INTERNAL_FAILURE"] = @60L;
	context[@"RDNA_ERR_INVALID_PROXY_CREDS"] = @61L;
	context[@"RDNA_ERR_CONNECTION_TIMEDOUT"] = @62L;
	context[@"RDNA_ERR_DNS_TIMEDOUT"] = @63L;
	context[@"RDNA_ERR_RESPONSE_TIMEDOUT"] = @64L;
	context[@"RDNA_ERR_UNSUPPORTED_USER_RELID_VERSION"] = @65L;
	context[@"RDNA_ERR_RMAK_INCORRECT_TIMESTAMP"] = @66L;
	context[@"RDNA_ERR_FAILED_TO_GET_NOTF_HIST_USER_NOT_LOGGED_IN"] = @67L;
	context[@"RDNA_ERR_FAILED_TO_GET_NOTIFICATION_HISTORY"] = @68L;
	context[@"RDNA_ERR_INVALID_TUNNEL_CONFIGURATION"] = @69L;
	context[@"RDNA_ERR_FAILED_TO_PARSE_DEVICES"] = @70L;
	context[@"RDNA_ERR_INVALID_CHALLENGE_CONFIG"] = @71L;
	context[@"RDNA_ERR_INVALID_HTTP_API_REQ_URL"] = @72L;
	context[@"RDNA_ERR_NO_MEMORY"] = @73L;
	context[@"RDNA_ERR_INVALID_CONTEXT"] = @74L;
	context[@"RDNA_ERR_CIPHERTEXT_LENGTH_INVALID"] = @75L;
	context[@"RDNA_ERR_CIPHERTEXT_EMPTY"] = @76L;
	context[@"RDNA_ERR_PLAINTEXT_EMPTY"] = @77L;
	context[@"RDNA_ERR_PLAINTEXT_LENGTH_INVALID"] = @78L;
	context[@"RDNA_ERR_USERID_EMPTY"] = @79L;
	context[@"RDNA_ERR_CHALLENGE_EMPTY"] = @80L;
	context[@"RDNA_ERR_FAILED_TO_SERIALIZE_JSON"] = @81L;
	context[@"RDNA_ERR_USECASE_EMPTY"] = @82L;
	context[@"RDNA_ERR_NOTF_HISTORY_ARRAYLEN_MISMATCH"] = @83L;
	context[@"RDNA_ERR_INVALID_SERVICE_NAME"] = @84L;
	context[@"RDNA_ERR_DEVICE_DETAILS_EMPTY"] = @85L;
	context[@"RDNA_ERR_FAILED_TO_DESERIALIZE_JSON"] = @86L;
	context[@"RDNA_ERR_INVALID_CHALLENGE_JSON"] = @87L;
	context[@"RDNA_ERR_RDNA_ALREADY_INITIALIZED"] = @88L;
	context[@"RDNA_ERR_LDA_BIO_FINGERPRINT_CANCELLED_BY_USER"] = @89L;
	context[@"RDNA_ERR_LDA_BIO_FINGERPRINT_CANCELLED_BY_SYSTEM"] = @90L;
	context[@"RDNA_ERR_LDA_BIO_FINGERPRINT_LOCKED_OUT"] = @91L;
	context[@"RDNA_ERR_LDA_BIO_FACERECOGNITION_CANCELLED_BY_USER"] = @92L;
	context[@"RDNA_ERR_LDA_BIO_FACERECOGNITION_CANCELLED_BY_SYSTEM"] = @93L;
	context[@"RDNA_ERR_LDA_BIO_FACERECOGNITION_LOCKED_OUT"] = @94L;
	context[@"RDNA_ERR_LDA_PATTERN_CANCELLED_BY_USER"] = @95L;
	context[@"RDNA_ERR_ARCHITECTURE_NOT_SUPPORTED"] = @96L;
	context[@"RDNA_ERR_INVALID_DEVICE_CONTEXT"] = @97L;
	context[@"RDNA_ERR_INVALID_NOTIFICATION_ACTIVITY_CLASS"] = @98L;
	context[@"RDNA_ERR_LDA_FINGERPRINT_AUTH_DISABLED_DURING_LOGIN"] = @99L;
	context[@"RDNA_ERR_LDA_FACE_AUTH_DISABLED_DURING_LOGIN"] = @100L;
	context[@"RDNA_ERR_LDA_PATTERN_AUTH_DISABLED_DURING_LOGIN"] = @101L;
	context[@"RDNA_ERR_INCONSISTANT_USER_DEVICE_STATE"] = @102L;
	context[@"RDNA_ERR_CONFLICTING_CALLBACK_OBJECTS"] = @103L;
	context[@"RDNA_ERR_TOTP_INVALID_TOTP_CONTEXT"] = @104L;
	context[@"RDNA_ERR_INVALID_TOTP_CONFIG"] = @105L;
	context[@"RDNA_ERR_USER_REGISTERED_FOR_TOTP"] = @106L;
	context[@"RDNA_ERR_TOTP_INVALID_CHALLENGE_SEQUENCE"] = @107L;
	context[@"RDNA_ERR_INVALID_TOTP_CREDENTIAL"] = @108L;
	context[@"RDNA_ERR_TOTP_AUTHENTIATION_CANCELLED"] = @109L;
	context[@"RDNA_ERR_USER_NOT_REGISTERED_FOR_TOTP"] = @110L;
	context[@"RDNA_ERR_USERNAME_MISMATCH_WITH_LOGGED_IN_USER"] = @111L;
	context[@"RDNA_ERR_INCONSISTENT_CORE_STATE"] = @112L;
	context[@"RDNA_ERR_TOTP_GENERIC_ERROR"] = @113L;
	context[@"RDNA_ERR_TOTP_BLOCKED_FOR_USER_DUE_TO_EXHAUSTED_ATTEMPTS"] = @114L;
	context[@"RDNA_ERR_TOTP_FAILED_TO_REGISTER_USER"] = @115L;
	context[@"RDNA_ERR_CIS_CONFIGURATION_INVALID"] = @116L;
	context[@"RDNA_ERR_INVALID_INITIAL_CHLNG_JSON"] = @117L;
	context[@"RDNA_ERR_NO_OR_INVALID_UPDATE_CHLNG_SEQ"] = @118L;
	context[@"RDNA_ERR_CHALLENGE_NOT_SUPPORTED"] = @119L;
	context[@"RDNA_ERR_INVALID_API_EXECUTED"] = @120L;
	context[@"RDNA_ERR_USER_ACTIVATION_CHOICE_NOT_SUPPORTED"] = @121L;
	context[@"RDNA_ERR_INVALID_USER_AUTH_CHALLENGE_SEQUENCE"] = @122L;
	context[@"RDNA_ERR_UPDATING_UNSUPPORTED_CRED"] = @123L;
	context[@"RDNA_ERR_INVALID_SUPPORTED_AUTH"] = @124L;
	context[@"RDNA_ERR_UNABLE_TO_STORE_USER_AUTH_STATE_DURING_ACTIVATION"] = @125L;
	context[@"RDNA_ERR_USER_LDA_AUTH_FAILED_DURING_ACTIVATION"] = @126L;
	context[@"RDNA_ERR_TOTP_NOT_SUPPORTED_BY_APPLICATION_AGENT"] = @127L;
	context[@"RDNA_ERR_INVALID_INITIAL_CHALLENGE"] = @128L;
	context[@"RDNA_ERR_LOGIN_ID_ALREADY_EXISTS"] = @129L;
	context[@"RDNA_ERR_ADD_LOGIN_ID_GENERIC_ERROR"] = @130L;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_USER"] = @131L;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_SYSTEM"] = @132L;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FINGERPRINT_LOCKED_OUT"] = @133L;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_USER"] = @134L;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_SYSTEM"] = @135L;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_LOCKED_OUT"] = @136L;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_PATTERN_CANCELLED_BY_USER"] = @137L;
	context[@"RDNA_ERR_STEPUP_AUTH_VERIFICATION_FAILED"] = @138L;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_DISABLED"] = @139L;
	context[@"RDNA_ERR_PSWD_POLICY_CONFIGURED_INVALID"] = @140L;
	context[@"RDNA_ERR_PSWD_POLICY_VALIDATION_FAILED"] = @141L;
	context[@"RDNA_ERR_SET_LOGIN_ID_COUNT_EXHAUSTED"] = @142L;
	context[@"RDNA_ERR_USER_ACTIVATION_RELID_NOT_FOUND"] = @143L;
	context[@"RDNA_ERR_APP_INTEGRITY_COMPROMISED"] = @144L;
	context[@"RDNA_ERR_DEVICE_SECURITY_CHECKS_FAILED"] = @145L;
	context[@"RDNA_ERR_IDV_PROCESS_FAILED"] = @146L;
	context[@"RDNA_ERR_CREDENTIAL_UPDATE_FAILED_DUE_TO_AUTH_FAILURE"] = @147L;
	context[@"RDNA_ERR_DEVICE_BLOCKED_BY_ADMIN"] = @148L;
	context[@"RDNA_ERR_SESSION_CREATION_FAILED"] = @149L;
	context[@"RDNA_ERR_LDA_MGMT_ATTEMPTS_EXHAUSTED_LOGGIN_OFF"] = @150L;
	context[@"RDNA_ERR_LDA_MGMT_NOT_SUPPORTED_NOT_CONFIGURED_DEVICE_INSECURE"] = @151L;
	context[@"RDNA_ERR_LDA_MGMT_FAILED_USER_NOT_LOGGED_IN"] = @152L;
	context[@"RDNA_ERR_LDA_MGMT_LDA_ALREADY_MANAGED_NOTHING_TO_UPDATE"] = @153L;
	context[@"RDNA_ERR_LDA_MGMT_INTERNAL_STATE_INVALID"] = @154L;
	context[@"RDNA_ERR_LDA_MGMT_INVALID_CHOICE"] = @155L;
	context[@"RDNA_ERR_LDA_MGMT_FAILED_TO_INITIATE_AUTH_PROCESS_DATA_EXTRACTION_FAILED"] = @156L;
	context[@"RDNA_ERR_LDA_MGMT_OPERATION_FAILED_INVALID_ARGS"] = @157L;
	context[@"RDNA_ERR_LDA_MGMT_FAILED_DUE_TO_STEUP_AUTH_FAILURE"] = @158L;
	context[@"RDNA_ERR_LDA_MGMT_FAILURE_TO_ENABLE_PATTERN"] = @159L;
	context[@"RDNA_ERR_LDA_ACTIVATION_SKIPPED_OR_FAILED"] = @160L;
	context[@"RDNA_ERR_RELID_STATUS_INVALID"] = @161L;
	context[@"RDNA_ERR_DEVICE_LIMIT_EXCEEDED"] = @162L;
	context[@"RDNA_ERR_GENERIC_SERVER_ERROR"] = @163L;
	context[@"RDNA_ERR_JWT_REFRESH_NOT_SUPPORTED"] = @164L;
	context[@"RDNA_ERR_INVALID_JWT_RESPONSE"] = @165L;
	context[@"RDNA_ERR_USER_NOT_LOGGED_IN"] = @166L;
	context[@"RDNA_ERR_PSWD_UPDATE_FAILED_SAME_NEW_AND_CURRENT_PSWD"] = @167L;
	context[@"RDNA_ERR_BIO_DOMAIN_STATE_CHANGED"] = @168L;
	context[@"RDNA_ERR_SESSION_TERMINATED_BIO_DOMAIN_STATE_CHANGED"] = @169L;
	context[@"RDNA_ERR_FEATURE_OR_OPERATION_NOT_SUPPORTED"] = @170L;
	context[@"RDNA_ERR_PATTERN_UPDATE_FAILED_SAME_NEW_AND_CURRENT_PATTERN"] = @171L;
	context[@"RDNA_ERR_APP_DEBUG_MODE_DETECTED"] = @172L;
	context[@"RDNA_ERR_EMULATOR_DETECTED"] = @173L;
	context[@"RDNA_ERR_APP_INSTALLED_FROM_UNKNOWN_SOURCE"] = @174L;
	context[@"RDNA_ERR_PACKAGE_INVALID"] = @175L;
	context[@"RDNA_ERR_APPLICATION_REPACKAGED"] = @176L;
	context[@"RDNA_ERR_FGT_LOGIN_ID_INVALID_SEARCH_PARAM"] = @177L;
	context[@"RDNA_ERR_SET_LOGIN_ID_INVALID_LOGIN_ID"] = @178L;
	context[@"RDNA_ERR_INITIALIZE_ALREADY_IN_PROGRESS"] = @179L;
	context[@"RDNA_ERR_CONNECTION_REFUSED"] = @180L;
	context[@"RDNA_ERR_CHECK_USER_BIO_TEMPLATE_GENERIC_FAILURE"] = @181L;
	context[@"RDNA_ERR_INITIATE_SERVER_BIO_AUTH_INVALID_RETRIES"] = @182L;
	context[@"RDNA_ERR_STEPUP_AUTH_NOT_CONFIGURED"] = @183L;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_USER"] = @184L;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_SYSTEM"] = @185L;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FINGERPRINT_LOCKED_OUT"] = @186L;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_USER"] = @187L;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_SYSTEM"] = @188L;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_LOCKED_OUT"] = @189L;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_PATTERN_CANCELLED_BY_USER"] = @190L;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_VERIFICATION_FAILED"] = @191L;
	context[@"RDNA_ERR_GENEREIC_STEPUP_AUTH_LDA_DISABLED"] = @192L;
	context[@"RDNA_ERR_OPEN_HTTP_MALFORMED_REQUEST"] = @193L;
	context[@"RDNA_ERR_OPEN_HTTP_UNSUPPORTED_METHOD"] = @194L;
	context[@"RDNA_ERR_OPEN_HTTP_UNSUPPORTED_PROTOCOL"] = @195L;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_CANCELLED_BY_APPLICATION"] = @196L;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_CONTEXT_INVALIDATED"] = @197L;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_FAILED_BY_APPLE_WATCH"] = @198L;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_NONINTERACTIVE_USERINTERFACE_FORBIDDEN"] = @199L;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_ERROR_UNKNOWN"] = @200L;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_NO_FALLBACK_AVAILABLE"] = @201L;
	context[@"RDNA_ERR_LDA_PASSCODE_NOT_SET"] = @202L;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_NOT_SUPPORTED"] = @203L;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_BIOMETRIC_NOT_ENROLLED"] = @204L;
	context[@"RDNA_ERR_NOTF_STEP_UP_AUTH_NOT_SUPPORTED"] = @205L;
	context[@"RDNA_STEPUP_AUTH_ALREADY_IN_PROGRESS"] = @206L;
	context[@"RDNA_STEP_UP_AUTH_ATTEMPTS_EXHAUSTED"] = @207L;
	context[@"RDNA_ERR_APP_INSIGHT_KEY_NOT_FOUND_IN_MTD_CONFIG"] = @208L;
	context[@"RDNA_ERR_CONNECTION_BROKEN_OR_FORCIBLY_CLOSED"] = @209L;
	context[@"RDNA_ERR_GENERIC_SET_LOGIN_ID_FAILED"] = @210L;
	context[@"RDNA_ERR_INSUFFICIENT_PRIVILEGES"] = @211L;
	context[@"RDNA_ERR_LOGGED_IN_USER_AND_KYC_USER_SHOULD_BE_DIFFERENT"] = @212L;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_ALREADY_IN_PROGRESS"] = @213L;
	context[@"RDNA_ERR_GENERIC_STEP_UP_AUTH_NOT_SUPPORTED"] = @214L;
	context[@"RDNA_ERR_TOTP_REGISTRATION_IN_PROGRESS"] = @215L;
	context[@"RDNA_ERR_LOGINID_SAME_AS_PRIMARY_USERID"] = @216L;
	context[@"RDNA_ERR_LDA_CONSENT_REJECTED_BY_USER"] = @217L;


	context[@"RDNA_STREAM_TYPE_ENCRYPT"] = @0L;
	context[@"RDNA_STREAM_TYPE_DECRYPT"] = @1L;


	context[@"RDNA_PORT_TYPE_PROXY"] = @0L;
	context[@"RDNA_PORT_TYPE_PORTF"] = @1L;
	context[@"RDNA_PORT_TYPE_REST"] = @2L;


	context[@"RDNA_PRIVACY_SCOPE_SESSION"] = @1L;
	context[@"RDNA_PRIVACY_SCOPE_DEVICE"] = @2L;
	context[@"RDNA_PRIVACY_SCOPE_USER"] = @4L;
	context[@"RDNA_PRIVACY_SCOPE_AGENT"] = @8L;


	context[@"RDNA_PROMPT_BOOLEAN"] = @0L;
	context[@"RDNA_PROMPT_ONE_WAY"] = @1L;
	context[@"RDNA_PROMPT_TWO_WAY_READONLY"] = @2L;
	context[@"RDNA_PROMPT_TWO_WAY_READWRITE"] = @3L;


	context[@"RDNA_RESP_STATUS_SUCCESS"] = @0L;
	context[@"RDNA_RESP_STATUS_NO_USER_ID"] = @1L;
	context[@"RDNA_RESP_STATUS_AUTH_FAILED"] = @2L;
	context[@"RDNA_RESP_STATUS_SEC_QA_MATCH_FAILED"] = @3L;
	context[@"RDNA_RESP_STATUS_NO_SEC_QA_PRESENT"] = @4L;
	context[@"RDNA_RESP_STATUS_PWD_UPDATE_FAILED"] = @5L;
	context[@"RDNA_RESP_STATUS_OTP_MATCH_FAILED"] = @6L;
	context[@"RDNA_RESP_STATUS_SECONDARY_SEC_QA_MATCH_FAILED"] = @7L;
	context[@"RDNA_RESP_STATUS_ACT_CODE_MATCH_FAILED"] = @8L;
	context[@"RDNA_RESP_STATUS_ACT_CODE_EXPIRED"] = @9L;
	context[@"RDNA_RESP_STATUS_PASSWORD_EXPIRED"] = @10L;
	context[@"RDNA_RESP_STATUS_OTP_EXPIRED"] = @11L;
	context[@"RDNA_RESP_STATUS_OTP_ALREADY_USED"] = @12L;
	context[@"RDNA_RESP_STATUS_AUTO_RESET_USER"] = @13L;
	context[@"RDNA_RESP_STATUS_INTERNAL_SERVER_ERROR"] = @14L;
	context[@"RDNA_RESP_STATUS_POST_LOGIN_VERIFY_CREDS_FAILURE"] = @15L;
	context[@"RDNA_RESP_STATUS_DEVICE_UPDATE_FAILED"] = @16L;
	context[@"RDNA_RESP_STATUS_USER_UNENROLLED"] = @17L;
	context[@"RDNA_RESP_STATUS_INVALID_USE_CASE"] = @18L;
	context[@"RDNA_RESP_STATUS_USER_LOCKED"] = @19L;
	context[@"RDNA_RESP_STATUS_PERMANENT_DEVICE_LIMIT_EXCEEDED"] = @20L;
	context[@"RDNA_RESP_STATUS_CHALLENGE_NOT_FOUND"] = @21L;
	context[@"RDNA_RESP_STATUS_TOKEN_BASED_AUTH_FAILED"] = @22L;
	context[@"RDNA_RESP_STATUS_TOKEN_BASED_AUTH_UPDATED"] = @23L;
	context[@"RDNA_RESP_STATUS_AD_USER_DISABLE"] = @24L;
	context[@"RDNA_RESP_STATUS_AD_USER_DELETED"] = @25L;
	context[@"RDNA_RESP_STATUS_USER_DEVICE_NOT_REGISTERED"] = @26L;
	context[@"RDNA_RESP_STATUS_USER_BLOCKED"] = @27L;
	context[@"RDNA_RESP_STATUS_USER_SUSPENDED"] = @28L;
	context[@"RDNA_RESP_STATUS_INVALID_CHALLENGE_JSON"] = @29L;
	context[@"RDNA_RESP_STATUS_AD_PASSWORD_MISMATCH"] = @30L;
	context[@"RDNA_RESP_STATUS_DEVICE_VALIDATION_FAILED"] = @31L;
	context[@"RDNA_RESP_STATUS_USER_ALREADY_ACTIVE"] = @32L;
	context[@"RDNA_SECONDARY_USER_DEVICE_ACTIVATION_FLOW_REJECTED"] = @33L;
	context[@"RDNA_SECONDARY_USER_DEVICE_FRAUD_DETECTED"] = @34L;
	context[@"RDNA_SECONDARY_USER_DEVICE_ACTIVATION_NOTIFICATION_EXPIRED"] = @35L;
	context[@"RDNA_INTERNAL_VERIFY_SERVER_ERROR"] = @36L;
	context[@"RDNA_RESET_DEVICE_FAILED"] = @37L;
	context[@"RDNA_USER_DEVICE_BLOCKED"] = @38L;
	context[@"RDNA_RESP_STATUS_UNKNOWN_ERROR"] = @39L;
	context[@"RDNA_RESP_STATUS_BLOCK_USERID"] = @40L;


	context[@"RDNA_IWA_AUTH_SUCCESS"] = @0L;
	context[@"RDNA_IWA_AUTH_CANCELLED"] = @1L;
	context[@"RDNA_IWA_AUTH_DEFERRED"] = @2L;


	context[@"RDNA_CHALLENGE_OP_VERIFY"] = @0L;
	context[@"RDNA_CHALLENGE_OP_SET"] = @1L;
	context[@"RDNA_OP_UPDATE_CREDENTIALS"] = @2L;
	context[@"RDNA_OP_AUTHORIZE_NOTIFICATION"] = @3L;
	context[@"RDNA_OP_UPDATE_ON_EXPIRY"] = @4L;
	context[@"RDNA_AUTHORIZE_LDA_MANAGEMENT"] = @5L;
	context[@"RDNA_IDV_BIO_OPT_IN"] = @6L;
	context[@"RDNA_IDV_BIO_OPT_OUT"] = @7L;
	context[@"RDNA_IDV_CHALLENGE_BIOMETRIC_AND_DOCUMENT_SCAN"] = @8L;
	context[@"RDNA_IDV_API_BIOMETRIC_AND_DOCUMENT_SCAN"] = @9L;
	context[@"RDNA_IDV_API_AGENT_BIOMETRIC_AND_DOCUMENT_SCAN"] = @10L;
	context[@"RDNA_IDV_API_DOCUMENT_SCAN"] = @11L;
	context[@"RDNA_OP_STEP_UP_AUTH_AND_SIGN_DATA"] = @12L;
	context[@"RDNA_OP_STEP_UP_AUTH"] = @13L;
	context[@"RDNA_MANAGE_LDA_SET_PASS"] = @14L;
	context[@"RDNA_MANAGE_LDA_RECONFIRM_VERIFY_PASS"] = @15L;
	context[@"RDNA_MANAGE_LDA_SET_LDA"] = @16L;
	context[@"RDNA_OP_MODE_NONE"] = @17L;


	context[@"IDV_ACTIVATION"] = @0L;
	context[@"IDV_ACTIVATION_WITH_TEMPLATE"] = @1L;
	context[@"IDV_ADDITIONAL_DEVICE_WITH_TEMPLATE"] = @2L;
	context[@"IDV_ADDITIONAL_DEVICE_WITHOUT_TEMPLATE"] = @3L;
	context[@"IDV_ACCOUNT_RECOVERY_WITH_TEMPLATE"] = @4L;
	context[@"IDV_ACCOUNT_RECOVERY_WITHOUT_TEMPLATE"] = @5L;
	context[@"IDV_POSTLOGIN_KYC"] = @6L;
	context[@"IDV_POSTLOGIN_DOC_SCAN_ONLY"] = @7L;
	context[@"IDV_POSTLOGIN_IDV_SELFIE_BIOMETRIC"] = @8L;
	context[@"IDV_POSTLOGIN_IDV_STEPUP_AUTH"] = @9L;
	context[@"IDV_POSTLOGIN_OPTIN"] = @10L;
	context[@"IDV_POSTLOGIN_OPTOUT"] = @11L;
	context[@"IDV_POSTLOGIN_TEMPLATE_CHECK"] = @12L;
	context[@"IDV_POSTLOGIN_AGENT_KYC"] = @13L;
	context[@"IDV_ONBOARDING"] = @14L;
	context[@"IDV_LOGIN"] = @15L;
	context[@"IDV_POSTLOGIN_STEP_UP_AUTH_AND_SIGN_DATA"] = @16L;
	context[@"IDV_INVALID"] = @17L;


	context[@"RDNA_DEVSTATUS_ACTIVE"] = @0L;
	context[@"RDNA_DEVSTATUS_UPDATE"] = @1L;
	context[@"RDNA_DEVSTATUS_DELETE"] = @2L;
	context[@"RDNA_DEVSTATUS_BLOCKED"] = @3L;
	context[@"RDNA_DEVSTATUS_SUSPEND"] = @4L;


	context[@"RDNA_PERMENANT"] = @0L;
	context[@"RDNA_TEMPORARY"] = @1L;


	context[@"RDNA_HTTP_POST"] = @0L;
	context[@"RDNA_HTTP_GET"] = @1L;
	context[@"RDNA_HTTP_HEAD"] = @2L;
	context[@"RDNA_HTTP_PUT"] = @3L;
	context[@"RDNA_HTTP_DELETE"] = @4L;


	context[@"RDNA_APP_SESSION"] = @0L;
	context[@"RDNA_USER_SESSION"] = @1L;


	context[@"STARTED"] = @0L;
	context[@"COMPLETED"] = @1L;
	context[@"NOT_APPLICABLE"] = @2L;
	context[@"NOT_STARTED"] = @3L;
	context[@"INIT_FAILED"] = @4L;


	context[@"RDNA_LDA_INVALID"] = @0L;
	context[@"RDNA_LDA_FINGERPRINT"] = @1L;
	context[@"RDNA_LDA_FACE"] = @2L;
	context[@"RDNA_LDA_PATTERN"] = @3L;
	context[@"RDNA_LDA_SSKB_PASSWORD"] = @4L;
	context[@"RDNA_SEC_QA"] = @5L;
	context[@"RDNA_IDV_EXT_BIO_OPT_IN"] = @6L;
	context[@"RDNA_IDV_EXT_BIO_OPT_OUT"] = @7L;
	context[@"RDNA_LDA_DEVICE_PASSCODE"] = @8L;
	context[@"RDNA_DEVICE_LDA"] = @9L;
	context[@"RDNA_LDA_BIOMETRIC"] = @10L;


	context[@"RDNA_DISABLE_DEVICE_AUTHS"] = @0L;
	context[@"RDNA_ENABLE_DEVICE_AUTHS"] = @1L;


	context[@"RDNA_IDV_APPROVED"] = @0L;
	context[@"RDNA_IDV_RECAPTURE"] = @1L;
	context[@"RDNA_IDV_CANCEL"] = @2L;


	context[@"RDNA_AUTH_TYPE_NONE"] = @0L;
	context[@"RDNA_IDV_SERVER_BIOMETRIC"] = @1L;


	context[@"RDNA_AUTH_LEVEL_NONE"] = @0L;
	context[@"RDNA_AUTH_LEVEL_1"] = @1L;
	context[@"RDNA_AUTH_LEVEL_2"] = @2L;
	context[@"RDNA_AUTH_LEVEL_3"] = @3L;
	context[@"RDNA_AUTH_LEVEL_4"] = @4L;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void RELID_RDNAStructProtocols()
{
	(void)objc_getProtocol('RDNAPrivacyStreamCallBacks');
	(void)objc_getProtocol('RDNAHTTPCallbacks');
}
void load_RELID_RDNAStruct_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
