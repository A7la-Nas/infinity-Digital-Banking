#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLGeocoder_symbols(JSContext*);
@protocol CLGeocoderInstanceExports<JSExport>
@property (getter=isGeocoding,readonly,nonatomic) BOOL geocoding;
JSExportAs(reverseGeocodeLocationCompletionHandler,
-(void) jsreverseGeocodeLocation: (CLLocation *) location completionHandler: (JSValue *) completionHandler );
JSExportAs(reverseGeocodeLocationPreferredLocaleCompletionHandler,
-(void) jsreverseGeocodeLocation: (CLLocation *) location preferredLocale: (NSLocale *) locale completionHandler: (JSValue *) completionHandler );
JSExportAs(geocodeAddressDictionaryCompletionHandler,
-(void) jsgeocodeAddressDictionary: (NSDictionary *) addressDictionary completionHandler: (JSValue *) completionHandler );
JSExportAs(geocodeAddressStringCompletionHandler,
-(void) jsgeocodeAddressString: (NSString *) addressString completionHandler: (JSValue *) completionHandler );
JSExportAs(geocodeAddressStringInRegionCompletionHandler,
-(void) jsgeocodeAddressString: (NSString *) addressString inRegion: (CLRegion *) region completionHandler: (JSValue *) completionHandler );
JSExportAs(geocodeAddressStringInRegionPreferredLocaleCompletionHandler,
-(void) jsgeocodeAddressString: (NSString *) addressString inRegion: (CLRegion *) region preferredLocale: (NSLocale *) locale completionHandler: (JSValue *) completionHandler );
-(void) cancelGeocode;
@end
@protocol CLGeocoderClassExports<JSExport>
@end
@protocol CLGeocoderContactsAdditionsCategoryInstanceExports<JSExport>
JSExportAs(geocodePostalAddressCompletionHandler,
-(void) jsgeocodePostalAddress: (CNPostalAddress *) postalAddress completionHandler: (JSValue *) completionHandler );
JSExportAs(geocodePostalAddressPreferredLocaleCompletionHandler,
-(void) jsgeocodePostalAddress: (CNPostalAddress *) postalAddress preferredLocale: (NSLocale *) locale completionHandler: (JSValue *) completionHandler );
@end
@protocol CLGeocoderContactsAdditionsCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop