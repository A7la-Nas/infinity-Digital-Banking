#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLCircularRegion_symbols(JSContext*);
@protocol CLCircularRegionInstanceExports<JSExport>
@property (readonly,atomic) CLLocationCoordinate2D center;
@property (readonly,atomic) CLLocationDistance radius;
JSExportAs(initWithCenterRadiusIdentifier,
-(id) jsinitWithCenter: (CLLocationCoordinate2D) center radius: (CLLocationDistance) radius identifier: (NSString *) identifier );
-(BOOL) containsCoordinate: (CLLocationCoordinate2D) coordinate ;
@end
@protocol CLCircularRegionClassExports<JSExport>
@end
#pragma clang diagnostic pop