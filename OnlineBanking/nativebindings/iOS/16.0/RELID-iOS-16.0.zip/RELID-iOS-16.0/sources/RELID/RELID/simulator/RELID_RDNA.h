#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_RELID_RDNA_symbols(JSContext*);
@protocol RDNAInstanceExports<JSExport>
-(NSString *) setIDVCallback: (id) callback ;
JSExportAs(initializeCallbacksGatewayHostGatewayPortCipherSpecCipherSaltProxySettingsRDNASSLCertificateDNSServerListRDNALoggingLevelAppContext,
-(NSString *) jsinitialize: (NSString *) agentInfo Callbacks: (id) callbacks GatewayHost: (NSString *) gwHNIP GatewayPort: (uint16_t) gwPort CipherSpec: (NSString *) cipherSpec CipherSalt: (NSString *) cipherSalt ProxySettings: (NSString *) proxySettings RDNASSLCertificate: (RDNASSLCertificate *) rdnaSSLCertificate DNSServerList: (NSArray *) dnsServerList RDNALoggingLevel: (int) loggingLevel AppContext: (id) appCtx );
-(NSString *) enrollUser: (NSString *) userID firstName: (NSString *) firstName lastName: (NSString *) lastName email: (NSString *) email mobileNumber: (NSString *) mobileNumber groupName: (NSString *) groupName ;
-(NSString *) setUser: (NSString *) userID ;
-(NSString *) setActivationCode: (NSString *) activationCode ;
-(NSString *) activateUsing: (NSString *) choice ;
-(NSString *) setDeviceName: (NSString *) deviceName ;
-(NSString *) setUserConsentForLDA: (BOOL) shouldEnrollLDA challengeMode: (RDNAChallengeOpMode) challengeMode authenticationType: (RDNALDACapabilities) authenticationType ;
-(NSString *) setPassword: (NSString *) password challengeMode: (RDNAChallengeOpMode) mode ;
-(NSString *) updatePassword: (NSString *) currentPassword withNewPassword: (NSString *) newPassword challengeMode: (RDNAChallengeOpMode) mode ;
-(NSString *) setAccessCode: (NSString *) accessCode ;
-(NSString *) generateTOTP: (NSString *) userID ;
-(NSString *) setTOTPPassword: (NSString *) password ;
-(NSString *) performVerifyAuth: (BOOL) status ;
-(NSString *) resetAuthState;
-(NSString *) serviceAccessStart: (NSString *) service ;
-(NSString *) serviceAccessStop: (NSString *) service ;
-(NSString *) serviceAccessStartAll;
-(NSString *) serviceAccessStopAll;
-(NSString *) resumeRuntime: (NSString *) state Callbacks: (id) callbacks ProxySettings: (NSString *) proxySettings RDNALoggingLevel: (RDNALoggingLevel) loggingLevel AppContext: (id) appCtx ;
-(NSString *) terminate;
-(NSString *) getPostLoginChallenges: (NSString *) userID withUseCaseName: (NSString *) useCaseName ;
-(NSString *) getConfig: (NSString *) configRequest ;
-(NSString *) getAllChallenges: (NSString *) userID ;
-(NSString *) getRegisteredDeviceDetails: (NSString *) configJeson ;
-(NSString *) updateDeviceDetails: (NSString *) userID withDevices: (NSString *) devices ;
-(NSString *) resetChallenge;
-(NSString *) logOff: (NSString *) userID ;
-(NSString *) forgotPassword: (NSString *) userID ;
-(NSString *) getNotifications: (int) recordCount withEnterpriseID: (NSString *) enterpriseID withStartIndex: (int) startIndex withStartDate: (NSString *) startDate withEndDate: (NSString *) endDate ;
-(NSString *) updateNotification: (NSString *) notificationID withResponse: (NSString *) response ;
-(NSString *) getNotificationHistory: (int) recordCount withEnterpriseID: (NSString *) enterpriseID withStartIndex: (int) startIndex withStartDate: (NSString *) startDate withEndDate: (NSString *) endDate withNotificationStatus: (NSString *) notificationStatus withActionPerformed: (NSString *) actionPerformed withKeywordSearch: (NSString *) keywordSearch withDeviceID: (NSString *) deviceID ;
-(NSString *) addAlternateLoginId: (NSString *) loginId ;
-(NSString *) forgotLoginID: (NSString *) requestType requestData: (NSString *) requestData ;
JSExportAs(initiateUpdateFlowForCredential,
-(NSString *) jsinitiateUpdateFlowForCredential: (NSString *) credentialName );
-(NSString *) setCustomChallengeResponse: (NSString *) challengeResponse ;
-(NSString *) fallbackNewDeviceActivationFlow;
-(NSString *) takeActionOnThreats: (NSString *) userConsentThreats ;
-(NSString *) setSecretQuestionAnswer: (NSArray *) response andchallengeMode: (RDNAChallengeOpMode) mode ;
-(NSString *) forgotPassword;
-(NSString *) resendActivationCode;
-(NSString *) resendAccessCode;
-(NSString *) manageDeviceAuthenticationModes: (BOOL) isEnabled withauthenticationType: (int) authenticationType ;
-(NSString *) resetBlockedUserAccount;
-(NSString *) requestNewAccessToken: (NSString *) reasonForRefresh ;
-(NSString *) authenticateUserAndSignData: (NSString *) payload authLevel: (RDNAAuthLevel) authLevel authenticatorType: (RDNAAuthenticatorType) authenticatorType reason: (NSString *) reason ;
-(NSString *) resetAuthenticateUserAndSignDataState;
-(NSString *) setIDVDocumentScanProcessStartConfirmation: (BOOL) isConfirm idvWorkflow: (RDNAIDVWorkflow) workflow ;
-(NSString *) setIDVSelfieProcessStartConfirmation: (BOOL) isConfirm useDeviceBackCamera: (BOOL) useDeviceBackCamera idvWorkflow: (RDNAIDVWorkflow) workflow ;
-(NSString *) setIDVSelfieConfirmation: (NSString *) action challengeMode: (RDNAChallengeOpMode) opMode ;
-(NSString *) setIDVConfirmDocumentDetails: (BOOL) isConfirm challengeMode: (RDNAChallengeOpMode) opMode ;
-(NSString *) checkIDVUserBiometricTemplateStatus;
JSExportAs(initiateIDVServerBiometricAuthenticationRetries,
-(NSString *) jsinitiateIDVServerBiometricAuthentication: (NSString *) reason retries: (int) retries );
-(NSString *) setIDVBiometricOptInConsent: (BOOL) isOptIn challengeMode: (RDNAChallengeOpMode) opMode ;
-(NSString *) jsinitiateIDVBiometricOptIn;
-(NSString *) jsinitiateIDVBiometricOptOut;
-(NSString *) setIDVBiometricOptInConfirmation: (int) status ;
JSExportAs(initiateIDVAdditionalDocumentScan,
-(NSString *) jsinitiateIDVAdditionalDocumentScan: (NSString *) reason );
JSExportAs(initiateActivatedCustomerKYC,
-(NSString *) jsinitiateActivatedCustomerKYC: (NSString *) reason );
JSExportAs(initiateAgentKYCforUserAndReason,
-(NSString *) jsinitiateAgentKYCforUser: (NSString *) userID andReason: (NSString *) reason );
-(NSString *) getIDVConfig;
-(NSString *) setIDVConfig: (NSString *) configJson ;
@end
@protocol RDNAClassExports<JSExport>
+(RDNA *) sharedInstance;
+(NSString *) getSDKVersion;
+(RDNAErrorID) getErrorInfo: (int) errorCode ;
@end
@protocol RDNACallbacksInstanceExports_<JSExport>
-(CLLocationManager *) getLocationManager;
-(int) ShowLocationDailogue;
-(void) onInitializeError: (NSString *) status ;
-(void) onInitialized: (NSString *) status ;
-(void) onInitializeProgress: (NSString *) status ;
-(int) onSecurityThreat: (NSString *) status ;
-(void) getUser: (NSString *) status ;
-(void) getActivationCode: (NSString *) status ;
-(void) activateUserOptions: (NSString *) status ;
-(void) getPassword: (NSString *) status ;
-(void) getUserConsentForLDA: (NSString *) status ;
-(void) getDeviceName: (NSString *) status ;
-(void) getAccessCode: (NSString *) status ;
-(void) onUserLoggedIn: (NSString *) status ;
-(void) onUserLoggedOff: (NSString *) status ;
-(void) addNewDeviceOptions: (NSString *) status ;
-(void) onTOTPRegistrationStatus: (NSString *) status ;
-(void) onTOTPGenerated: (NSString *) status ;
-(void) getTOTPPassword: (NSString *) status ;
-(int) onTerminate: (NSString *) status ;
-(int) onPauseRuntime: (NSString *) status ;
-(int) onResumeRuntime: (NSString *) status ;
-(int) onConfigReceived: (NSString *) status ;
-(RDNAIWACreds *) getCredentials: (NSString *) domainUrl ;
-(int) onGetPostLoginChallenges: (NSString *) status ;
-(int) onGetRegistredDeviceDetails: (NSString *) status ;
-(int) onUpdateDeviceDetails: (NSString *) status ;
-(int) onGetNotifications: (NSString *) status ;
-(int) onUpdateNotification: (NSString *) status ;
-(int) onGetNotificationsHistory: (NSString *) status ;
-(void) onHandleCustomChallenge: (NSString *) status ;
-(void) getLoginId;
-(void) onLoginIdUpdateStatus: (NSString *) status ;
-(void) onForgotLoginIDStatus: (NSString *) status ;
-(void) onCredentialsAvailableForUpdate: (NSString *) status ;
-(void) onUpdateCredentialResponse: (NSString *) status ;
-(NSString *) getDeviceToken;
-(int) onSessionTimeout: (NSString *) status ;
-(int) onSdkLogPrintRequest: (RDNALoggingLevel) level andlogData: (NSString *) logData ;
-(void) onUserConsentThreats: (NSString *) threats ;
-(void) onTerminateWithThreats: (NSString *) threats ;
-(void) onSelectSecretQuestionAnswer: (NSString *) status ;
-(void) getSecretAnswer: (NSString *) status ;
-(void) onDeviceAuthManagementStatus: (NSString *) status ;
-(void) onAccessTokenRefreshed: (NSString *) status ;
-(void) onUserEnrollmentResponse: (NSString *) status ;
-(void) onAuthenticateUserAndSignData: (NSString *) status ;
@end
@protocol RDNACallbacksClassExports_<JSExport>
@end
@protocol RDNAIDVCallbacksInstanceExports_<JSExport>
-(void) getIDVDocumentScanProcessStartConfirmation: (NSString *) response ;
-(void) getIDVSelfieProcessStartConfirmation: (NSString *) response ;
-(void) getIDVConfirmDocumentDetails: (NSString *) response ;
-(void) getIDVSelfieConfirmation: (NSString *) response ;
-(void) getIDVBiometricOptInConsent: (NSString *) status ;
-(void) onIDVCheckUserBiometricTemplateStatus: (NSString *) status ;
-(void) onIDVServerBiometricAuthenticationResult: (NSString *) status ;
-(void) onIDVBiometricOptInStatus: (NSString *) status ;
-(void) onIDVBiometricOptOutStatus: (NSString *) status ;
-(void) onIDVOptInCapturedFrameConfirmation: (NSString *) capturedImage ;
-(void) onIDVAdditionalDocumentScan: (NSString *) status ;
-(void) onIDVActivatedCustomerKYCResponse: (NSString *) status ;
-(void) onIDVAgentKYCResponse: (NSString *) status ;
-(void) onIDVKYCProgress: (NSString *) status ;
@end
@protocol RDNAIDVCallbacksClassExports_<JSExport>
@end
#pragma clang diagnostic pop