#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation RDNA (Exports)
-(NSString *) jsinitialize: (NSString *) agentInfo Callbacks: (id) callbacks GatewayHost: (NSString *) gwHNIP GatewayPort: (uint16_t) gwPort CipherSpec: (NSString *) cipherSpec CipherSalt: (NSString *) cipherSalt ProxySettings: (NSString *) proxySettings RDNASSLCertificate: (RDNASSLCertificate *) rdnaSSLCertificate DNSServerList: (NSArray *) dnsServerList RDNALoggingLevel: (int) loggingLevel AppContext: (id) appCtx 
{
	NSString * resultVal__;
	resultVal__ = [self initialize: agentInfo Callbacks: callbacks GatewayHost: gwHNIP GatewayPort: gwPort CipherSpec: cipherSpec CipherSalt: cipherSalt ProxySettings: proxySettings RDNASSLCertificate: rdnaSSLCertificate DNSServerList: dnsServerList RDNALoggingLevel: loggingLevel AppContext: appCtx ];
	return resultVal__;
}
-(NSString *) jsinitiateUpdateFlowForCredential: (NSString *) credentialName 
{
	NSString * resultVal__;
	resultVal__ = [self initiateUpdateFlowForCredential: credentialName ];
	return resultVal__;
}
-(NSString *) jsinitiateIDVServerBiometricAuthentication: (NSString *) reason retries: (int) retries 
{
	NSString * resultVal__;
	resultVal__ = [self initiateIDVServerBiometricAuthentication: reason retries: retries ];
	return resultVal__;
}
-(NSString *) jsinitiateIDVBiometricOptIn
{
	NSString * resultVal__;
	resultVal__ = [self initiateIDVBiometricOptIn];
	return resultVal__;
}
-(NSString *) jsinitiateIDVBiometricOptOut
{
	NSString * resultVal__;
	resultVal__ = [self initiateIDVBiometricOptOut];
	return resultVal__;
}
-(NSString *) jsinitiateIDVAdditionalDocumentScan: (NSString *) reason 
{
	NSString * resultVal__;
	resultVal__ = [self initiateIDVAdditionalDocumentScan: reason ];
	return resultVal__;
}
-(NSString *) jsinitiateActivatedCustomerKYC: (NSString *) reason 
{
	NSString * resultVal__;
	resultVal__ = [self initiateActivatedCustomerKYC: reason ];
	return resultVal__;
}
-(NSString *) jsinitiateAgentKYCforUser: (NSString *) userID andReason: (NSString *) reason 
{
	NSString * resultVal__;
	resultVal__ = [self initiateAgentKYCforUser: userID andReason: reason ];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([RDNA class], @protocol(RDNAInstanceExports));
	class_addProtocol([RDNA class], @protocol(RDNAClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void RELID_RDNAProtocols()
{
	(void)objc_getProtocol('RDNACallbacks');
	(void)objc_getProtocol('RDNAIDVCallbacks');
}
void load_RELID_RDNA_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
