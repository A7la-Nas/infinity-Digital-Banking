#import "allincludes.h"
#import <JavaScriptCore/JavaScriptCore.h>
void loadNFIRELIDModules(JSContext* context)
{
	load_RELID_RDNAStruct_symbols(context);
	load_RELID_RDNA_symbols(context);
}

JSValue* extractNFIRELIDStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context)
{
    
    return nil;
}

BOOL setNFIRELIDStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation)
{
    
    return NO;
}

