#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
	class_addProtocol([RDNAPort class], @protocol(RDNAPortInstanceExports));
	class_addProtocol([RDNAPort class], @protocol(RDNAPortClassExports));
	class_addProtocol([RDNAService class], @protocol(RDNAServiceInstanceExports));
	class_addProtocol([RDNAService class], @protocol(RDNAServiceClassExports));
	class_addProtocol([RDNAResponseStatus class], @protocol(RDNAResponseStatusInstanceExports));
	class_addProtocol([RDNAResponseStatus class], @protocol(RDNAResponseStatusClassExports));
	class_addProtocol([RDNAStatusInit class], @protocol(RDNAStatusInitInstanceExports));
	class_addProtocol([RDNAStatusInit class], @protocol(RDNAStatusInitClassExports));
	class_addProtocol([RDNAStatusTerminate class], @protocol(RDNAStatusTerminateInstanceExports));
	class_addProtocol([RDNAStatusTerminate class], @protocol(RDNAStatusTerminateClassExports));
	class_addProtocol([RDNAStatusPauseRuntime class], @protocol(RDNAStatusPauseRuntimeInstanceExports));
	class_addProtocol([RDNAStatusPauseRuntime class], @protocol(RDNAStatusPauseRuntimeClassExports));
	class_addProtocol([RDNAStatusResumeRuntime class], @protocol(RDNAStatusResumeRuntimeInstanceExports));
	class_addProtocol([RDNAStatusResumeRuntime class], @protocol(RDNAStatusResumeRuntimeClassExports));
	class_addProtocol([RDNAStatusGetConfig class], @protocol(RDNAStatusGetConfigInstanceExports));
	class_addProtocol([RDNAStatusGetConfig class], @protocol(RDNAStatusGetConfigClassExports));
	class_addProtocol([RDNAProxySettings class], @protocol(RDNAProxySettingsInstanceExports));
	class_addProtocol([RDNAProxySettings class], @protocol(RDNAProxySettingsClassExports));
	class_addProtocol([RDNADeviceDetails class], @protocol(RDNADeviceDetailsInstanceExports));
	class_addProtocol([RDNADeviceDetails class], @protocol(RDNADeviceDetailsClassExports));
	class_addProtocol([RDNAStatusGetRegisteredDeviceDetails class], @protocol(RDNAStatusGetRegisteredDeviceDetailsInstanceExports));
	class_addProtocol([RDNAStatusGetRegisteredDeviceDetails class], @protocol(RDNAStatusGetRegisteredDeviceDetailsClassExports));
	class_addProtocol([RDNAStatusUpdateDeviceDetails class], @protocol(RDNAStatusUpdateDeviceDetailsInstanceExports));
	class_addProtocol([RDNAStatusUpdateDeviceDetails class], @protocol(RDNAStatusUpdateDeviceDetailsClassExports));
	class_addProtocol([RDNAExpectedResponse class], @protocol(RDNAExpectedResponseInstanceExports));
	class_addProtocol([RDNAExpectedResponse class], @protocol(RDNAExpectedResponseClassExports));
	class_addProtocol([RDNAResponseLabel class], @protocol(RDNAResponseLabelInstanceExports));
	class_addProtocol([RDNAResponseLabel class], @protocol(RDNAResponseLabelClassExports));
	class_addProtocol([RDNANotfBody class], @protocol(RDNANotfBodyInstanceExports));
	class_addProtocol([RDNANotfBody class], @protocol(RDNANotfBodyClassExports));
	class_addProtocol([RDNANotification class], @protocol(RDNANotificationInstanceExports));
	class_addProtocol([RDNANotification class], @protocol(RDNANotificationClassExports));
	class_addProtocol([RDNANotfHistBody class], @protocol(RDNANotfHistBodyInstanceExports));
	class_addProtocol([RDNANotfHistBody class], @protocol(RDNANotfHistBodyClassExports));
	class_addProtocol([RDNANotificationHistory class], @protocol(RDNANotificationHistoryInstanceExports));
	class_addProtocol([RDNANotificationHistory class], @protocol(RDNANotificationHistoryClassExports));
	class_addProtocol([RDNAStatusGetNotifications class], @protocol(RDNAStatusGetNotificationsInstanceExports));
	class_addProtocol([RDNAStatusGetNotifications class], @protocol(RDNAStatusGetNotificationsClassExports));
	class_addProtocol([RDNAStatusUpdateNotification class], @protocol(RDNAStatusUpdateNotificationInstanceExports));
	class_addProtocol([RDNAStatusUpdateNotification class], @protocol(RDNAStatusUpdateNotificationClassExports));
	class_addProtocol([RDNAStatusGetNotificationHistory class], @protocol(RDNAStatusGetNotificationHistoryInstanceExports));
	class_addProtocol([RDNAStatusGetNotificationHistory class], @protocol(RDNAStatusGetNotificationHistoryClassExports));
	class_addProtocol([RDNAStatusCheckChallengeResponse class], @protocol(RDNAStatusCheckChallengeResponseInstanceExports));
	class_addProtocol([RDNAStatusCheckChallengeResponse class], @protocol(RDNAStatusCheckChallengeResponseClassExports));
	class_addProtocol([RDNAStatusUpdateChallenges class], @protocol(RDNAStatusUpdateChallengesInstanceExports));
	class_addProtocol([RDNAStatusUpdateChallenges class], @protocol(RDNAStatusUpdateChallengesClassExports));
	class_addProtocol([RDNAStatusGetAllChallenges class], @protocol(RDNAStatusGetAllChallengesInstanceExports));
	class_addProtocol([RDNAStatusGetAllChallenges class], @protocol(RDNAStatusGetAllChallengesClassExports));
	class_addProtocol([RDNAStatusGetPostLoginChallenges class], @protocol(RDNAStatusGetPostLoginChallengesInstanceExports));
	class_addProtocol([RDNAStatusGetPostLoginChallenges class], @protocol(RDNAStatusGetPostLoginChallengesClassExports));
	class_addProtocol([RDNAStatusForgotPassword class], @protocol(RDNAStatusForgotPasswordInstanceExports));
	class_addProtocol([RDNAStatusForgotPassword class], @protocol(RDNAStatusForgotPasswordClassExports));
	class_addProtocol([RDNAStatusLogOff class], @protocol(RDNAStatusLogOffInstanceExports));
	class_addProtocol([RDNAStatusLogOff class], @protocol(RDNAStatusLogOffClassExports));
	class_addProtocol([RDNAIWACreds class], @protocol(RDNAIWACredsInstanceExports));
	class_addProtocol([RDNAIWACreds class], @protocol(RDNAIWACredsClassExports));
	class_addProtocol([RDNAHTTPRequest class], @protocol(RDNAHTTPRequestInstanceExports));
	class_addProtocol([RDNAHTTPRequest class], @protocol(RDNAHTTPRequestClassExports));
	class_addProtocol([RDNAHTTPResponse class], @protocol(RDNAHTTPResponseInstanceExports));
	class_addProtocol([RDNAHTTPResponse class], @protocol(RDNAHTTPResponseClassExports));
	class_addProtocol([RDNAHTTPStatus class], @protocol(RDNAHTTPStatusInstanceExports));
	class_addProtocol([RDNAHTTPStatus class], @protocol(RDNAHTTPStatusClassExports));
	class_addProtocol([RDNASSLCertificate class], @protocol(RDNASSLCertificateInstanceExports));
	class_addProtocol([RDNASSLCertificate class], @protocol(RDNASSLCertificateClassExports));
	class_addProtocol([RDNAChallengeInfo class], @protocol(RDNAChallengeInfoInstanceExports));
	class_addProtocol([RDNAChallengeInfo class], @protocol(RDNAChallengeInfoClassExports));
	class_addProtocol([RDNAChallenge class], @protocol(RDNAChallengeInstanceExports));
	class_addProtocol([RDNAChallenge class], @protocol(RDNAChallengeClassExports));
	class_addProtocol([RDNAError class], @protocol(RDNAErrorInstanceExports));
	class_addProtocol([RDNAError class], @protocol(RDNAErrorClassExports));
	class_addProtocol([RDNASession class], @protocol(RDNASessionInstanceExports));
	class_addProtocol([RDNASession class], @protocol(RDNASessionClassExports));
	class_addProtocol([RDNARequestStatus class], @protocol(RDNARequestStatusInstanceExports));
	class_addProtocol([RDNARequestStatus class], @protocol(RDNARequestStatusClassExports));
	class_addProtocol([RDNAGroupInfo class], @protocol(RDNAGroupInfoInstanceExports));
	class_addProtocol([RDNAGroupInfo class], @protocol(RDNAGroupInfoClassExports));
	class_addProtocol([RDNAAdditionalInfo class], @protocol(RDNAAdditionalInfoInstanceExports));
	class_addProtocol([RDNAAdditionalInfo class], @protocol(RDNAAdditionalInfoClassExports));
	class_addProtocol([RDNAChallengeResponse class], @protocol(RDNAChallengeResponseInstanceExports));
	class_addProtocol([RDNAChallengeResponse class], @protocol(RDNAChallengeResponseClassExports));
	class_addProtocol([RDNAAppInfo class], @protocol(RDNAAppInfoInstanceExports));
	class_addProtocol([RDNAAppInfo class], @protocol(RDNAAppInfoClassExports));
	class_addProtocol([RDNANetworkInfo class], @protocol(RDNANetworkInfoInstanceExports));
	class_addProtocol([RDNANetworkInfo class], @protocol(RDNANetworkInfoClassExports));
	class_addProtocol([RDNAThreat class], @protocol(RDNAThreatInstanceExports));
	class_addProtocol([RDNAThreat class], @protocol(RDNAThreatClassExports));
	class_addProtocol([RDNAThreatDetails class], @protocol(RDNAThreatDetailsInstanceExports));
	class_addProtocol([RDNAThreatDetails class], @protocol(RDNAThreatDetailsClassExports));
	class_addProtocol([RDNAThreatLog class], @protocol(RDNAThreatLogInstanceExports));
	class_addProtocol([RDNAThreatLog class], @protocol(RDNAThreatLogClassExports));
	class_addProtocol([RDNAInitProgressStatus class], @protocol(RDNAInitProgressStatusInstanceExports));
	class_addProtocol([RDNAInitProgressStatus class], @protocol(RDNAInitProgressStatusClassExports));
	class_addProtocol([RDNAThreatLogDetails class], @protocol(RDNAThreatLogDetailsInstanceExports));
	class_addProtocol([RDNAThreatLogDetails class], @protocol(RDNAThreatLogDetailsClassExports));
	class_addProtocol([RDNASecretQuestionAndAnswer class], @protocol(RDNASecretQuestionAndAnswerInstanceExports));
	class_addProtocol([RDNASecretQuestionAndAnswer class], @protocol(RDNASecretQuestionAndAnswerClassExports));
	class_addProtocol([RDNADeviceAuthenticationDetails class], @protocol(RDNADeviceAuthenticationDetailsInstanceExports));
	class_addProtocol([RDNADeviceAuthenticationDetails class], @protocol(RDNADeviceAuthenticationDetailsClassExports));
	class_addProtocol([RDNADataSigningDetails class], @protocol(RDNADataSigningDetailsInstanceExports));
	class_addProtocol([RDNADataSigningDetails class], @protocol(RDNADataSigningDetailsClassExports));
	class_addProtocol([RDNAPrivacyStream class], @protocol(RDNAPrivacyStreamInstanceExports));
	class_addProtocol([RDNAPrivacyStream class], @protocol(RDNAPrivacyStreamClassExports));
	class_addProtocol([RDNAStruct class], @protocol(RDNAStructInstanceExports));
	class_addProtocol([RDNAStruct class], @protocol(RDNAStructClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{

	context[@"RDNA_METH_NONE"] = @0;
	context[@"RDNA_METH_INITIALIZE"] = @1;
	context[@"RDNA_METH_TERMINATE"] = @2;
	context[@"RDNA_METH_RESUME"] = @3;
	context[@"RDNA_METH_PAUSE"] = @4;
	context[@"RDNA_METH_GET_CONFIG"] = @5;
	context[@"RDNA_METH_CHECK_CHALLENGE"] = @6;
	context[@"RDNA_METH_UPDATE_CHALLENGE"] = @7;
	context[@"RDNA_METH_GET_ALL_CHALLENGES"] = @8;
	context[@"RDNA_METH_LOGOFF"] = @9;
	context[@"RDNA_METH_FORGOT_PASSWORD"] = @10;
	context[@"RDNA_METH_GET_POST_LOGIN_CHALLENGES"] = @11;
	context[@"RDNA_METH_GET_DEVICE_DETAILS"] = @12;
	context[@"RDNA_METH_UPDATE_DEVICE_DETAILS"] = @13;
	context[@"RDNA_METH_GET_NOTIFICATIONS"] = @14;
	context[@"RDNA_METH_UPDATE_NOTIFICATION"] = @15;
	context[@"RDNA_METH_GET_NOTIFICATION_HISTORY"] = @16;
	context[@"RDNA_METH_OPEN_HTTP_CONNECTION"] = @17;
	context[@"RDNA_ADD_ALTERNATE_LOGIN_ID"] = @18;
	context[@"RDNA_METH_DELETE_LOGIN_ID"] = @19;
	context[@"RDNA_METH_EDIT_LOGIN_ID"] = @20;
	context[@"RDNA_METH_GET_ALL_REGISTERED_LOGIN_IDS"] = @21;
	context[@"RDNA_METH_GET_NOTIFICATIONS_EX"] = @22;


	context[@"RDNA_NO_LOGS"] = @0;
	context[@"RDNA_LOG_WARN"] = @1;
	context[@"RDNA_LOG_NOTIFY"] = @2;
	context[@"RDNA_LOG_NETWORK"] = @3;
	context[@"RDNA_LOG_DNA"] = @4;
	context[@"RDNA_LOG_DEBUG"] = @5;
	context[@"RDNA_LOG_VERBOSE"] = @6;


	context[@"RDNA_ERR_NONE"] = @0;
	context[@"RDNA_ERR_NOT_INITIALIZED"] = @1;
	context[@"RDNA_ERR_GENERIC_ERROR"] = @2;
	context[@"RDNA_ERR_INVALID_VERSION"] = @3;
	context[@"RDNA_ERR_INVALID_ARGS"] = @4;
	context[@"RDNA_ERR_SESSION_EXPIRED"] = @5;
	context[@"RDNA_ERR_PARENT_PROXY_CONNECT_FAILED"] = @6;
	context[@"RDNA_ERR_NULL_CALLBACKS"] = @7;
	context[@"RDNA_ERR_INVALID_HOST"] = @8;
	context[@"RDNA_ERR_INVALID_PORTNUM"] = @9;
	context[@"RDNA_ERR_INVALID_AGENT_INFO"] = @10;
	context[@"RDNA_ERR_UNSUPPORTED_AGENT_RELID"] = @11;
	context[@"RDNA_ERR_FAILED_TO_CONNECT_TO_SERVER"] = @12;
	context[@"RDNA_ERR_INVALID_SAVED_CONTEXT"] = @13;
	context[@"RDNA_ERR_INVALID_HTTP_REQUEST"] = @14;
	context[@"RDNA_ERR_INVALID_HTTP_RESPONSE"] = @15;
	context[@"RDNA_ERR_INVALID_CIPHERSPECS"] = @16;
	context[@"RDNA_ERR_SERVICE_NOT_SUPPORTED"] = @17;
	context[@"RDNA_ERR_FAILED_TO_GET_STREAM_PRIVACYSCOPE"] = @18;
	context[@"RDNA_ERR_FAILED_TO_GET_STREAM_TYPE"] = @19;
	context[@"RDNA_ERR_FAILED_TO_WRITE_INTO_STREAM"] = @20;
	context[@"RDNA_ERR_FAILED_TO_END_STREAM"] = @21;
	context[@"RDNA_ERR_FAILED_TO_DESTROY_STREAM"] = @22;
	context[@"RDNA_ERR_FAILED_TO_INITIALIZE"] = @23;
	context[@"RDNA_ERR_FAILED_TO_PAUSERUNTIME"] = @24;
	context[@"RDNA_ERR_FAILED_TO_RESUMERUNTIME"] = @25;
	context[@"RDNA_ERR_FAILED_TO_TERMINATE"] = @26;
	context[@"RDNA_ERR_FAILED_TO_GET_CIPHERSALT"] = @27;
	context[@"RDNA_ERR_FAILED_TO_GET_CIPHERSPECS"] = @28;
	context[@"RDNA_ERR_FAILED_TO_GET_AGENT_ID"] = @29;
	context[@"RDNA_ERR_FAILED_TO_GET_SESSION_ID"] = @30;
	context[@"RDNA_ERR_FAILED_TO_GET_DEVICE_ID"] = @31;
	context[@"RDNA_ERR_FAILED_TO_GET_SERVICE"] = @32;
	context[@"RDNA_ERR_FAILED_TO_START_SERVICE"] = @33;
	context[@"RDNA_ERR_FAILED_TO_STOP_SERVICE"] = @34;
	context[@"RDNA_ERR_FAILED_TO_ENCRYPT_DATA_PACKET"] = @35;
	context[@"RDNA_ERR_FAILED_TO_DECRYPT_DATA_PACKET"] = @36;
	context[@"RDNA_ERR_FAILED_TO_ENCRYPT_HTTP_REQUEST"] = @37;
	context[@"RDNA_ERR_FAILED_TO_DECRYPT_HTTP_RESPONSE"] = @38;
	context[@"RDNA_ERR_FAILED_TO_CREATE_PRIVACY_STREAM"] = @39;
	context[@"RDNA_ERR_FAILED_TO_CHECK_CHALLENGE"] = @40;
	context[@"RDNA_ERR_FAILED_TO_UPDATE_CHALLENGE"] = @41;
	context[@"RDNA_ERR_FAILED_TO_GET_CONFIG"] = @42;
	context[@"RDNA_ERR_FAILED_TO_GET_ALL_CHALLENGES"] = @43;
	context[@"RDNA_ERR_FAILED_TO_LOGOFF"] = @44;
	context[@"RDNA_ERR_FAILED_TO_RESET_CHALLENGE"] = @45;
	context[@"RDNA_ERR_FAILED_TO_DO_FORGOT_PASSWORD"] = @46;
	context[@"RDNA_ERR_FAILED_TO_GET_POST_LOGIN_CHALLENGES"] = @47;
	context[@"RDNA_ERR_FAILED_TO_GET_REGISTERD_DEVICE_DETAILS"] = @48;
	context[@"RDNA_ERR_FAILED_TO_UPDATE_DEVICE_DETAILS"] = @49;
	context[@"RDNA_ERR_FAILED_TO_GET_NOTIFICATIONS"] = @50;
	context[@"RDNA_ERR_FAILED_TO_UPDATE_NOTIFICATION"] = @51;
	context[@"RDNA_ERR_FAILED_TO_OPEN_HTTP_CONNECTION"] = @52;
	context[@"RDNA_ERR_SSL_INIT_FAILED"] = @53;
	context[@"RDNA_ERR_SSL_ACTIVITY_FAILED"] = @54;
	context[@"RDNA_ERR_DNS_FAILED"] = @55;
	context[@"RDNA_ERR_NET_DOWN"] = @56;
	context[@"RDNA_ERR_SOCK_TIMEDOUT"] = @57;
	context[@"RDNA_ERR_DNA_INTERNAL"] = @58;
	context[@"RDNA_ERR_INVALID_USER_MR_STATE"] = @59;
	context[@"RDNA_ERR_NOTF_SIGN_INTERNAL_FAILURE"] = @60;
	context[@"RDNA_ERR_INVALID_PROXY_CREDS"] = @61;
	context[@"RDNA_ERR_CONNECTION_TIMEDOUT"] = @62;
	context[@"RDNA_ERR_DNS_TIMEDOUT"] = @63;
	context[@"RDNA_ERR_RESPONSE_TIMEDOUT"] = @64;
	context[@"RDNA_ERR_UNSUPPORTED_USER_RELID_VERSION"] = @65;
	context[@"RDNA_ERR_RMAK_INCORRECT_TIMESTAMP"] = @66;
	context[@"RDNA_ERR_FAILED_TO_GET_NOTF_HIST_USER_NOT_LOGGED_IN"] = @67;
	context[@"RDNA_ERR_FAILED_TO_GET_NOTIFICATION_HISTORY"] = @68;
	context[@"RDNA_ERR_INVALID_TUNNEL_CONFIGURATION"] = @69;
	context[@"RDNA_ERR_FAILED_TO_PARSE_DEVICES"] = @70;
	context[@"RDNA_ERR_INVALID_CHALLENGE_CONFIG"] = @71;
	context[@"RDNA_ERR_INVALID_HTTP_API_REQ_URL"] = @72;
	context[@"RDNA_ERR_NO_MEMORY"] = @73;
	context[@"RDNA_ERR_INVALID_CONTEXT"] = @74;
	context[@"RDNA_ERR_CIPHERTEXT_LENGTH_INVALID"] = @75;
	context[@"RDNA_ERR_CIPHERTEXT_EMPTY"] = @76;
	context[@"RDNA_ERR_PLAINTEXT_EMPTY"] = @77;
	context[@"RDNA_ERR_PLAINTEXT_LENGTH_INVALID"] = @78;
	context[@"RDNA_ERR_USERID_EMPTY"] = @79;
	context[@"RDNA_ERR_CHALLENGE_EMPTY"] = @80;
	context[@"RDNA_ERR_FAILED_TO_SERIALIZE_JSON"] = @81;
	context[@"RDNA_ERR_USECASE_EMPTY"] = @82;
	context[@"RDNA_ERR_NOTF_HISTORY_ARRAYLEN_MISMATCH"] = @83;
	context[@"RDNA_ERR_INVALID_SERVICE_NAME"] = @84;
	context[@"RDNA_ERR_DEVICE_DETAILS_EMPTY"] = @85;
	context[@"RDNA_ERR_FAILED_TO_DESERIALIZE_JSON"] = @86;
	context[@"RDNA_ERR_INVALID_CHALLENGE_JSON"] = @87;
	context[@"RDNA_ERR_RDNA_ALREADY_INITIALIZED"] = @88;
	context[@"RDNA_ERR_LDA_BIO_FINGERPRINT_CANCELLED_BY_USER"] = @89;
	context[@"RDNA_ERR_LDA_BIO_FINGERPRINT_CANCELLED_BY_SYSTEM"] = @90;
	context[@"RDNA_ERR_LDA_BIO_FINGERPRINT_LOCKED_OUT"] = @91;
	context[@"RDNA_ERR_LDA_BIO_FACERECOGNITION_CANCELLED_BY_USER"] = @92;
	context[@"RDNA_ERR_LDA_BIO_FACERECOGNITION_CANCELLED_BY_SYSTEM"] = @93;
	context[@"RDNA_ERR_LDA_BIO_FACERECOGNITION_LOCKED_OUT"] = @94;
	context[@"RDNA_ERR_LDA_PATTERN_CANCELLED_BY_USER"] = @95;
	context[@"RDNA_ERR_ARCHITECTURE_NOT_SUPPORTED"] = @96;
	context[@"RDNA_ERR_INVALID_DEVICE_CONTEXT"] = @97;
	context[@"RDNA_ERR_INVALID_NOTIFICATION_ACTIVITY_CLASS"] = @98;
	context[@"RDNA_ERR_LDA_FINGERPRINT_AUTH_DISABLED_DURING_LOGIN"] = @99;
	context[@"RDNA_ERR_LDA_FACE_AUTH_DISABLED_DURING_LOGIN"] = @100;
	context[@"RDNA_ERR_LDA_PATTERN_AUTH_DISABLED_DURING_LOGIN"] = @101;
	context[@"RDNA_ERR_INCONSISTANT_USER_DEVICE_STATE"] = @102;
	context[@"RDNA_ERR_CONFLICTING_CALLBACK_OBJECTS"] = @103;
	context[@"RDNA_ERR_TOTP_INVALID_TOTP_CONTEXT"] = @104;
	context[@"RDNA_ERR_INVALID_TOTP_CONFIG"] = @105;
	context[@"RDNA_ERR_USER_REGISTERED_FOR_TOTP"] = @106;
	context[@"RDNA_ERR_TOTP_INVALID_CHALLENGE_SEQUENCE"] = @107;
	context[@"RDNA_ERR_INVALID_TOTP_CREDENTIAL"] = @108;
	context[@"RDNA_ERR_TOTP_AUTHENTIATION_CANCELLED"] = @109;
	context[@"RDNA_ERR_USER_NOT_REGISTERED_FOR_TOTP"] = @110;
	context[@"RDNA_ERR_USERNAME_MISMATCH_WITH_LOGGED_IN_USER"] = @111;
	context[@"RDNA_ERR_INCONSISTENT_CORE_STATE"] = @112;
	context[@"RDNA_ERR_TOTP_GENERIC_ERROR"] = @113;
	context[@"RDNA_ERR_TOTP_BLOCKED_FOR_USER_DUE_TO_EXHAUSTED_ATTEMPTS"] = @114;
	context[@"RDNA_ERR_TOTP_FAILED_TO_REGISTER_USER"] = @115;
	context[@"RDNA_ERR_CIS_CONFIGURATION_INVALID"] = @116;
	context[@"RDNA_ERR_INVALID_INITIAL_CHLNG_JSON"] = @117;
	context[@"RDNA_ERR_NO_OR_INVALID_UPDATE_CHLNG_SEQ"] = @118;
	context[@"RDNA_ERR_CHALLENGE_NOT_SUPPORTED"] = @119;
	context[@"RDNA_ERR_INVALID_API_EXECUTED"] = @120;
	context[@"RDNA_ERR_USER_ACTIVATION_CHOICE_NOT_SUPPORTED"] = @121;
	context[@"RDNA_ERR_INVALID_USER_AUTH_CHALLENGE_SEQUENCE"] = @122;
	context[@"RDNA_ERR_UPDATING_UNSUPPORTED_CRED"] = @123;
	context[@"RDNA_ERR_INVALID_SUPPORTED_AUTH"] = @124;
	context[@"RDNA_ERR_UNABLE_TO_STORE_USER_AUTH_STATE_DURING_ACTIVATION"] = @125;
	context[@"RDNA_ERR_USER_LDA_AUTH_FAILED_DURING_ACTIVATION"] = @126;
	context[@"RDNA_ERR_TOTP_NOT_SUPPORTED_BY_APPLICATION_AGENT"] = @127;
	context[@"RDNA_ERR_INVALID_INITIAL_CHALLENGE"] = @128;
	context[@"RDNA_ERR_LOGIN_ID_ALREADY_EXISTS"] = @129;
	context[@"RDNA_ERR_ADD_LOGIN_ID_GENERIC_ERROR"] = @130;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_USER"] = @131;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_SYSTEM"] = @132;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FINGERPRINT_LOCKED_OUT"] = @133;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_USER"] = @134;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_SYSTEM"] = @135;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_LOCKED_OUT"] = @136;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_PATTERN_CANCELLED_BY_USER"] = @137;
	context[@"RDNA_ERR_STEPUP_AUTH_VERIFICATION_FAILED"] = @138;
	context[@"RDNA_ERR_STEPUP_AUTH_LDA_DISABLED"] = @139;
	context[@"RDNA_ERR_PSWD_POLICY_CONFIGURED_INVALID"] = @140;
	context[@"RDNA_ERR_PSWD_POLICY_VALIDATION_FAILED"] = @141;
	context[@"RDNA_ERR_SET_LOGIN_ID_COUNT_EXHAUSTED"] = @142;
	context[@"RDNA_ERR_USER_ACTIVATION_RELID_NOT_FOUND"] = @143;
	context[@"RDNA_ERR_APP_INTEGRITY_COMPROMISED"] = @144;
	context[@"RDNA_ERR_DEVICE_SECURITY_CHECKS_FAILED"] = @145;
	context[@"RDNA_ERR_IDV_PROCESS_FAILED"] = @146;
	context[@"RDNA_ERR_CREDENTIAL_UPDATE_FAILED_DUE_TO_AUTH_FAILURE"] = @147;
	context[@"RDNA_ERR_DEVICE_BLOCKED_BY_ADMIN"] = @148;
	context[@"RDNA_ERR_SESSION_CREATION_FAILED"] = @149;
	context[@"RDNA_ERR_LDA_MGMT_ATTEMPTS_EXHAUSTED_LOGGIN_OFF"] = @150;
	context[@"RDNA_ERR_LDA_MGMT_NOT_SUPPORTED_NOT_CONFIGURED_DEVICE_INSECURE"] = @151;
	context[@"RDNA_ERR_LDA_MGMT_FAILED_USER_NOT_LOGGED_IN"] = @152;
	context[@"RDNA_ERR_LDA_MGMT_LDA_ALREADY_MANAGED_NOTHING_TO_UPDATE"] = @153;
	context[@"RDNA_ERR_LDA_MGMT_INTERNAL_STATE_INVALID"] = @154;
	context[@"RDNA_ERR_LDA_MGMT_INVALID_CHOICE"] = @155;
	context[@"RDNA_ERR_LDA_MGMT_FAILED_TO_INITIATE_AUTH_PROCESS_DATA_EXTRACTION_FAILED"] = @156;
	context[@"RDNA_ERR_LDA_MGMT_OPERATION_FAILED_INVALID_ARGS"] = @157;
	context[@"RDNA_ERR_LDA_MGMT_FAILED_DUE_TO_STEUP_AUTH_FAILURE"] = @158;
	context[@"RDNA_ERR_LDA_MGMT_FAILURE_TO_ENABLE_PATTERN"] = @159;
	context[@"RDNA_ERR_LDA_ACTIVATION_SKIPPED_OR_FAILED"] = @160;
	context[@"RDNA_ERR_RELID_STATUS_INVALID"] = @161;
	context[@"RDNA_ERR_DEVICE_LIMIT_EXCEEDED"] = @162;
	context[@"RDNA_ERR_GENERIC_SERVER_ERROR"] = @163;
	context[@"RDNA_ERR_JWT_REFRESH_NOT_SUPPORTED"] = @164;
	context[@"RDNA_ERR_INVALID_JWT_RESPONSE"] = @165;
	context[@"RDNA_ERR_USER_NOT_LOGGED_IN"] = @166;
	context[@"RDNA_ERR_PSWD_UPDATE_FAILED_SAME_NEW_AND_CURRENT_PSWD"] = @167;
	context[@"RDNA_ERR_BIO_DOMAIN_STATE_CHANGED"] = @168;
	context[@"RDNA_ERR_SESSION_TERMINATED_BIO_DOMAIN_STATE_CHANGED"] = @169;
	context[@"RDNA_ERR_FEATURE_OR_OPERATION_NOT_SUPPORTED"] = @170;
	context[@"RDNA_ERR_PATTERN_UPDATE_FAILED_SAME_NEW_AND_CURRENT_PATTERN"] = @171;
	context[@"RDNA_ERR_APP_DEBUG_MODE_DETECTED"] = @172;
	context[@"RDNA_ERR_EMULATOR_DETECTED"] = @173;
	context[@"RDNA_ERR_APP_INSTALLED_FROM_UNKNOWN_SOURCE"] = @174;
	context[@"RDNA_ERR_PACKAGE_INVALID"] = @175;
	context[@"RDNA_ERR_APPLICATION_REPACKAGED"] = @176;
	context[@"RDNA_ERR_FGT_LOGIN_ID_INVALID_SEARCH_PARAM"] = @177;
	context[@"RDNA_ERR_SET_LOGIN_ID_INVALID_LOGIN_ID"] = @178;
	context[@"RDNA_ERR_INITIALIZE_ALREADY_IN_PROGRESS"] = @179;
	context[@"RDNA_ERR_CONNECTION_REFUSED"] = @180;
	context[@"RDNA_ERR_CHECK_USER_BIO_TEMPLATE_GENERIC_FAILURE"] = @181;
	context[@"RDNA_ERR_INITIATE_SERVER_BIO_AUTH_INVALID_RETRIES"] = @182;
	context[@"RDNA_ERR_STEPUP_AUTH_NOT_CONFIGURED"] = @183;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_USER"] = @184;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_SYSTEM"] = @185;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FINGERPRINT_LOCKED_OUT"] = @186;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_USER"] = @187;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_SYSTEM"] = @188;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_LOCKED_OUT"] = @189;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_PATTERN_CANCELLED_BY_USER"] = @190;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_VERIFICATION_FAILED"] = @191;
	context[@"RDNA_ERR_GENEREIC_STEPUP_AUTH_LDA_DISABLED"] = @192;
	context[@"RDNA_ERR_OPEN_HTTP_MALFORMED_REQUEST"] = @193;
	context[@"RDNA_ERR_OPEN_HTTP_UNSUPPORTED_METHOD"] = @194;
	context[@"RDNA_ERR_OPEN_HTTP_UNSUPPORTED_PROTOCOL"] = @195;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_CANCELLED_BY_APPLICATION"] = @196;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_CONTEXT_INVALIDATED"] = @197;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_FAILED_BY_APPLE_WATCH"] = @198;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_NONINTERACTIVE_USERINTERFACE_FORBIDDEN"] = @199;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_ERROR_UNKNOWN"] = @200;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_NO_FALLBACK_AVAILABLE"] = @201;
	context[@"RDNA_ERR_LDA_PASSCODE_NOT_SET"] = @202;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_NOT_SUPPORTED"] = @203;
	context[@"RDNA_ERR_LDA_BIO_AUTHENTICATION_BIOMETRIC_NOT_ENROLLED"] = @204;
	context[@"RDNA_ERR_NOTF_STEP_UP_AUTH_NOT_SUPPORTED"] = @205;
	context[@"RDNA_STEPUP_AUTH_ALREADY_IN_PROGRESS"] = @206;
	context[@"RDNA_STEP_UP_AUTH_ATTEMPTS_EXHAUSTED"] = @207;
	context[@"RDNA_ERR_APP_INSIGHT_KEY_NOT_FOUND_IN_MTD_CONFIG"] = @208;
	context[@"RDNA_ERR_CONNECTION_BROKEN_OR_FORCIBLY_CLOSED"] = @209;
	context[@"RDNA_ERR_GENERIC_SET_LOGIN_ID_FAILED"] = @210;
	context[@"RDNA_ERR_INSUFFICIENT_PRIVILEGES"] = @211;
	context[@"RDNA_ERR_LOGGED_IN_USER_AND_KYC_USER_SHOULD_BE_DIFFERENT"] = @212;
	context[@"RDNA_ERR_GENERIC_STEPUP_AUTH_ALREADY_IN_PROGRESS"] = @213;
	context[@"RDNA_ERR_GENERIC_STEP_UP_AUTH_NOT_SUPPORTED"] = @214;
	context[@"RDNA_ERR_TOTP_REGISTRATION_IN_PROGRESS"] = @215;
	context[@"RDNA_ERR_LOGINID_SAME_AS_PRIMARY_USERID"] = @216;
	context[@"RDNA_ERR_LDA_CONSENT_REJECTED_BY_USER"] = @217;


	context[@"RDNA_STREAM_TYPE_ENCRYPT"] = @0;
	context[@"RDNA_STREAM_TYPE_DECRYPT"] = @1;


	context[@"RDNA_PORT_TYPE_PROXY"] = @0;
	context[@"RDNA_PORT_TYPE_PORTF"] = @1;
	context[@"RDNA_PORT_TYPE_REST"] = @2;


	context[@"RDNA_PRIVACY_SCOPE_SESSION"] = @1;
	context[@"RDNA_PRIVACY_SCOPE_DEVICE"] = @2;
	context[@"RDNA_PRIVACY_SCOPE_USER"] = @4;
	context[@"RDNA_PRIVACY_SCOPE_AGENT"] = @8;


	context[@"RDNA_PROMPT_BOOLEAN"] = @0;
	context[@"RDNA_PROMPT_ONE_WAY"] = @1;
	context[@"RDNA_PROMPT_TWO_WAY_READONLY"] = @2;
	context[@"RDNA_PROMPT_TWO_WAY_READWRITE"] = @3;


	context[@"RDNA_RESP_STATUS_SUCCESS"] = @0;
	context[@"RDNA_RESP_STATUS_NO_USER_ID"] = @1;
	context[@"RDNA_RESP_STATUS_AUTH_FAILED"] = @2;
	context[@"RDNA_RESP_STATUS_SEC_QA_MATCH_FAILED"] = @3;
	context[@"RDNA_RESP_STATUS_NO_SEC_QA_PRESENT"] = @4;
	context[@"RDNA_RESP_STATUS_PWD_UPDATE_FAILED"] = @5;
	context[@"RDNA_RESP_STATUS_OTP_MATCH_FAILED"] = @6;
	context[@"RDNA_RESP_STATUS_SECONDARY_SEC_QA_MATCH_FAILED"] = @7;
	context[@"RDNA_RESP_STATUS_ACT_CODE_MATCH_FAILED"] = @8;
	context[@"RDNA_RESP_STATUS_ACT_CODE_EXPIRED"] = @9;
	context[@"RDNA_RESP_STATUS_PASSWORD_EXPIRED"] = @10;
	context[@"RDNA_RESP_STATUS_OTP_EXPIRED"] = @11;
	context[@"RDNA_RESP_STATUS_OTP_ALREADY_USED"] = @12;
	context[@"RDNA_RESP_STATUS_AUTO_RESET_USER"] = @13;
	context[@"RDNA_RESP_STATUS_INTERNAL_SERVER_ERROR"] = @14;
	context[@"RDNA_RESP_STATUS_POST_LOGIN_VERIFY_CREDS_FAILURE"] = @15;
	context[@"RDNA_RESP_STATUS_DEVICE_UPDATE_FAILED"] = @16;
	context[@"RDNA_RESP_STATUS_USER_UNENROLLED"] = @17;
	context[@"RDNA_RESP_STATUS_INVALID_USE_CASE"] = @18;
	context[@"RDNA_RESP_STATUS_USER_LOCKED"] = @19;
	context[@"RDNA_RESP_STATUS_PERMANENT_DEVICE_LIMIT_EXCEEDED"] = @20;
	context[@"RDNA_RESP_STATUS_CHALLENGE_NOT_FOUND"] = @21;
	context[@"RDNA_RESP_STATUS_TOKEN_BASED_AUTH_FAILED"] = @22;
	context[@"RDNA_RESP_STATUS_TOKEN_BASED_AUTH_UPDATED"] = @23;
	context[@"RDNA_RESP_STATUS_AD_USER_DISABLE"] = @24;
	context[@"RDNA_RESP_STATUS_AD_USER_DELETED"] = @25;
	context[@"RDNA_RESP_STATUS_USER_DEVICE_NOT_REGISTERED"] = @26;
	context[@"RDNA_RESP_STATUS_USER_BLOCKED"] = @27;
	context[@"RDNA_RESP_STATUS_USER_SUSPENDED"] = @28;
	context[@"RDNA_RESP_STATUS_INVALID_CHALLENGE_JSON"] = @29;
	context[@"RDNA_RESP_STATUS_AD_PASSWORD_MISMATCH"] = @30;
	context[@"RDNA_RESP_STATUS_DEVICE_VALIDATION_FAILED"] = @31;
	context[@"RDNA_RESP_STATUS_USER_ALREADY_ACTIVE"] = @32;
	context[@"RDNA_SECONDARY_USER_DEVICE_ACTIVATION_FLOW_REJECTED"] = @33;
	context[@"RDNA_SECONDARY_USER_DEVICE_FRAUD_DETECTED"] = @34;
	context[@"RDNA_SECONDARY_USER_DEVICE_ACTIVATION_NOTIFICATION_EXPIRED"] = @35;
	context[@"RDNA_INTERNAL_VERIFY_SERVER_ERROR"] = @36;
	context[@"RDNA_RESET_DEVICE_FAILED"] = @37;
	context[@"RDNA_USER_DEVICE_BLOCKED"] = @38;
	context[@"RDNA_RESP_STATUS_UNKNOWN_ERROR"] = @39;
	context[@"RDNA_RESP_STATUS_BLOCK_USERID"] = @40;


	context[@"RDNA_IWA_AUTH_SUCCESS"] = @0;
	context[@"RDNA_IWA_AUTH_CANCELLED"] = @1;
	context[@"RDNA_IWA_AUTH_DEFERRED"] = @2;


	context[@"RDNA_CHALLENGE_OP_VERIFY"] = @0;
	context[@"RDNA_CHALLENGE_OP_SET"] = @1;
	context[@"RDNA_OP_UPDATE_CREDENTIALS"] = @2;
	context[@"RDNA_OP_AUTHORIZE_NOTIFICATION"] = @3;
	context[@"RDNA_OP_UPDATE_ON_EXPIRY"] = @4;
	context[@"RDNA_AUTHORIZE_LDA_MANAGEMENT"] = @5;
	context[@"RDNA_IDV_BIO_OPT_IN"] = @6;
	context[@"RDNA_IDV_BIO_OPT_OUT"] = @7;
	context[@"RDNA_IDV_CHALLENGE_BIOMETRIC_AND_DOCUMENT_SCAN"] = @8;
	context[@"RDNA_IDV_API_BIOMETRIC_AND_DOCUMENT_SCAN"] = @9;
	context[@"RDNA_IDV_API_AGENT_BIOMETRIC_AND_DOCUMENT_SCAN"] = @10;
	context[@"RDNA_IDV_API_DOCUMENT_SCAN"] = @11;
	context[@"RDNA_OP_STEP_UP_AUTH_AND_SIGN_DATA"] = @12;
	context[@"RDNA_OP_STEP_UP_AUTH"] = @13;
	context[@"RDNA_MANAGE_LDA_SET_PASS"] = @14;
	context[@"RDNA_MANAGE_LDA_RECONFIRM_VERIFY_PASS"] = @15;
	context[@"RDNA_MANAGE_LDA_SET_LDA"] = @16;
	context[@"RDNA_OP_MODE_NONE"] = @17;


	context[@"IDV_ACTIVATION"] = @0;
	context[@"IDV_ACTIVATION_WITH_TEMPLATE"] = @1;
	context[@"IDV_ADDITIONAL_DEVICE_WITH_TEMPLATE"] = @2;
	context[@"IDV_ADDITIONAL_DEVICE_WITHOUT_TEMPLATE"] = @3;
	context[@"IDV_ACCOUNT_RECOVERY_WITH_TEMPLATE"] = @4;
	context[@"IDV_ACCOUNT_RECOVERY_WITHOUT_TEMPLATE"] = @5;
	context[@"IDV_POSTLOGIN_KYC"] = @6;
	context[@"IDV_POSTLOGIN_DOC_SCAN_ONLY"] = @7;
	context[@"IDV_POSTLOGIN_IDV_SELFIE_BIOMETRIC"] = @8;
	context[@"IDV_POSTLOGIN_IDV_STEPUP_AUTH"] = @9;
	context[@"IDV_POSTLOGIN_OPTIN"] = @10;
	context[@"IDV_POSTLOGIN_OPTOUT"] = @11;
	context[@"IDV_POSTLOGIN_TEMPLATE_CHECK"] = @12;
	context[@"IDV_POSTLOGIN_AGENT_KYC"] = @13;
	context[@"IDV_ONBOARDING"] = @14;
	context[@"IDV_LOGIN"] = @15;
	context[@"IDV_POSTLOGIN_STEP_UP_AUTH_AND_SIGN_DATA"] = @16;
	context[@"IDV_INVALID"] = @17;


	context[@"RDNA_DEVSTATUS_ACTIVE"] = @0;
	context[@"RDNA_DEVSTATUS_UPDATE"] = @1;
	context[@"RDNA_DEVSTATUS_DELETE"] = @2;
	context[@"RDNA_DEVSTATUS_BLOCKED"] = @3;
	context[@"RDNA_DEVSTATUS_SUSPEND"] = @4;


	context[@"RDNA_PERMENANT"] = @0;
	context[@"RDNA_TEMPORARY"] = @1;


	context[@"RDNA_HTTP_POST"] = @0;
	context[@"RDNA_HTTP_GET"] = @1;
	context[@"RDNA_HTTP_HEAD"] = @2;
	context[@"RDNA_HTTP_PUT"] = @3;
	context[@"RDNA_HTTP_DELETE"] = @4;


	context[@"RDNA_APP_SESSION"] = @0;
	context[@"RDNA_USER_SESSION"] = @1;


	context[@"STARTED"] = @0;
	context[@"COMPLETED"] = @1;
	context[@"NOT_APPLICABLE"] = @2;
	context[@"NOT_STARTED"] = @3;
	context[@"INIT_FAILED"] = @4;


	context[@"RDNA_LDA_INVALID"] = @0;
	context[@"RDNA_LDA_FINGERPRINT"] = @1;
	context[@"RDNA_LDA_FACE"] = @2;
	context[@"RDNA_LDA_PATTERN"] = @3;
	context[@"RDNA_LDA_SSKB_PASSWORD"] = @4;
	context[@"RDNA_SEC_QA"] = @5;
	context[@"RDNA_IDV_EXT_BIO_OPT_IN"] = @6;
	context[@"RDNA_IDV_EXT_BIO_OPT_OUT"] = @7;
	context[@"RDNA_LDA_DEVICE_PASSCODE"] = @8;
	context[@"RDNA_DEVICE_LDA"] = @9;
	context[@"RDNA_LDA_BIOMETRIC"] = @10;


	context[@"RDNA_DISABLE_DEVICE_AUTHS"] = @0;
	context[@"RDNA_ENABLE_DEVICE_AUTHS"] = @1;


	context[@"RDNA_IDV_APPROVED"] = @0;
	context[@"RDNA_IDV_RECAPTURE"] = @1;
	context[@"RDNA_IDV_CANCEL"] = @2;


	context[@"RDNA_AUTH_TYPE_NONE"] = @0;
	context[@"RDNA_IDV_SERVER_BIOMETRIC"] = @1;


	context[@"RDNA_AUTH_LEVEL_NONE"] = @0;
	context[@"RDNA_AUTH_LEVEL_1"] = @1;
	context[@"RDNA_AUTH_LEVEL_2"] = @2;
	context[@"RDNA_AUTH_LEVEL_3"] = @3;
	context[@"RDNA_AUTH_LEVEL_4"] = @4;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void RELID_RDNAStructProtocols()
{
	(void)objc_getProtocol('RDNAPrivacyStreamCallBacks');
	(void)objc_getProtocol('RDNAHTTPCallbacks');
}
void load_RELID_RDNAStruct_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
