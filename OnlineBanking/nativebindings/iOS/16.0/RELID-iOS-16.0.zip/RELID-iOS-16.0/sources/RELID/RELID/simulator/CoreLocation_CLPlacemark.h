#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLPlacemark_symbols(JSContext*);
@protocol CLPlacemarkInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) CLLocation * location;
@property (readonly,copy,nonatomic) CLRegion * region;
@property (readonly,copy,nonatomic) NSTimeZone * timeZone;
@property (readonly,copy,nonatomic) NSDictionary * addressDictionary;
@property (readonly,copy,nonatomic) NSString * name;
@property (readonly,copy,nonatomic) NSString * thoroughfare;
@property (readonly,copy,nonatomic) NSString * subThoroughfare;
@property (readonly,copy,nonatomic) NSString * locality;
@property (readonly,copy,nonatomic) NSString * subLocality;
@property (readonly,copy,nonatomic) NSString * administrativeArea;
@property (readonly,copy,nonatomic) NSString * subAdministrativeArea;
@property (readonly,copy,nonatomic) NSString * postalCode;
@property (readonly,copy,nonatomic) NSString * ISOcountryCode;
@property (readonly,copy,nonatomic) NSString * country;
@property (readonly,copy,nonatomic) NSString * inlandWater;
@property (readonly,copy,nonatomic) NSString * ocean;
@property (readonly,copy,nonatomic) NSArray * areasOfInterest;
JSExportAs(initWithPlacemark,
-(id) jsinitWithPlacemark: (CLPlacemark *) placemark );
@end
@protocol CLPlacemarkClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
@protocol CLPlacemarkContactsAdditionsCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) CNPostalAddress * postalAddress;
@end
@protocol CLPlacemarkContactsAdditionsCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop