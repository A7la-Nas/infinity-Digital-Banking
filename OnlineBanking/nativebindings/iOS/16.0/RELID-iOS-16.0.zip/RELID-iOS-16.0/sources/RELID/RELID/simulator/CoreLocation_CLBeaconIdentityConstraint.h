#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLBeaconIdentityConstraint_symbols(JSContext*);
@protocol CLBeaconIdentityConstraintInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSUUID * UUID;
@property (readonly,copy,nonatomic) NSNumber * major;
@property (readonly,copy,nonatomic) NSNumber * minor;
JSExportAs(initWithUUID,
-(id) jsinitWithUUID: (NSUUID *) uuid );
JSExportAs(initWithUUIDMajor,
-(id) jsinitWithUUID: (NSUUID *) uuid major: (CLBeaconMajorValue) major );
JSExportAs(initWithUUIDMajorMinor,
-(id) jsinitWithUUID: (NSUUID *) uuid major: (CLBeaconMajorValue) major minor: (CLBeaconMinorValue) minor );
@end
@protocol CLBeaconIdentityConstraintClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop