#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLLocationManager_symbols(JSContext*);
@protocol CLLocationManagerInstanceExports<JSExport>
@property (readonly,nonatomic) CLAuthorizationStatus authorizationStatus;
@property (readonly,nonatomic) CLAccuracyAuthorization accuracyAuthorization;
@property (getter=isAuthorizedForWidgetUpdates,readonly,nonatomic) BOOL authorizedForWidgetUpdates;
@property (nonatomic,weak) id delegate;
@property (readonly,nonatomic) BOOL locationServicesEnabled;
@property (copy,nonatomic) NSString * purpose;
@property (assign,nonatomic) CLActivityType activityType;
@property (assign,nonatomic) CLLocationDistance distanceFilter;
@property (assign,nonatomic) CLLocationAccuracy desiredAccuracy;
@property (assign,nonatomic) BOOL pausesLocationUpdatesAutomatically;
@property (assign,nonatomic) BOOL allowsBackgroundLocationUpdates;
@property (assign,nonatomic) BOOL showsBackgroundLocationIndicator;
@property (readonly,copy,nonatomic) CLLocation * location;
@property (readonly,nonatomic) BOOL headingAvailable;
@property (assign,nonatomic) CLLocationDegrees headingFilter;
@property (assign,nonatomic) CLDeviceOrientation headingOrientation;
@property (readonly,copy,nonatomic) CLHeading * heading;
@property (readonly,nonatomic) CLLocationDistance maximumRegionMonitoringDistance;
@property (readonly,copy,nonatomic) NSSet * monitoredRegions;
@property (readonly,copy,nonatomic) NSSet * rangedRegions;
@property (readonly,copy,nonatomic) NSSet * rangedBeaconConstraints;
-(void) requestWhenInUseAuthorization;
-(void) requestAlwaysAuthorization;
JSExportAs(requestTemporaryFullAccuracyAuthorizationWithPurposeKeyCompletion,
-(void) jsrequestTemporaryFullAccuracyAuthorizationWithPurposeKey: (NSString *) purposeKey completion: (JSValue *) completion );
-(void) requestTemporaryFullAccuracyAuthorizationWithPurposeKey: (NSString *) purposeKey ;
-(void) startUpdatingLocation;
-(void) stopUpdatingLocation;
-(void) requestLocation;
-(void) startUpdatingHeading;
-(void) stopUpdatingHeading;
-(void) dismissHeadingCalibrationDisplay;
-(void) startMonitoringSignificantLocationChanges;
-(void) stopMonitoringSignificantLocationChanges;
JSExportAs(startMonitoringLocationPushesWithCompletion,
-(void) jsstartMonitoringLocationPushesWithCompletion: (JSValue *) completion );
-(void) stopMonitoringLocationPushes;
-(void) startMonitoringForRegion: (CLRegion *) region desiredAccuracy: (CLLocationAccuracy) accuracy ;
-(void) stopMonitoringForRegion: (CLRegion *) region ;
-(void) startMonitoringForRegion: (CLRegion *) region ;
-(void) requestStateForRegion: (CLRegion *) region ;
-(void) startRangingBeaconsInRegion: (CLBeaconRegion *) region ;
-(void) stopRangingBeaconsInRegion: (CLBeaconRegion *) region ;
-(void) startRangingBeaconsSatisfyingConstraint: (CLBeaconIdentityConstraint *) constraint ;
-(void) stopRangingBeaconsSatisfyingConstraint: (CLBeaconIdentityConstraint *) constraint ;
-(void) allowDeferredLocationUpdatesUntilTraveled: (CLLocationDistance) distance timeout: (NSTimeInterval) timeout ;
-(void) disallowDeferredLocationUpdates;
@end
@protocol CLLocationManagerClassExports<JSExport>
+(BOOL) locationServicesEnabled;
+(BOOL) headingAvailable;
+(BOOL) significantLocationChangeMonitoringAvailable;
JSExportAs(isMonitoringAvailableForClass,
+(BOOL) jsisMonitoringAvailableForClass: (JSValue *) regionClass );
+(BOOL) regionMonitoringAvailable;
+(BOOL) regionMonitoringEnabled;
+(BOOL) isRangingAvailable;
+(CLAuthorizationStatus) authorizationStatus;
+(BOOL) deferredLocationUpdatesAvailable;
@end
#pragma clang diagnostic pop