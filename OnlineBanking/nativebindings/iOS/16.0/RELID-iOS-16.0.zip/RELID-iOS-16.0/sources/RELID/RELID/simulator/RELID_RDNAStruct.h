#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_RELID_RDNAStruct_symbols(JSContext*);
@protocol RDNAPortInstanceExports<JSExport>
@property (nonatomic) BOOL isStarted;
@property (nonatomic) BOOL isLocalhostOnly;
@property (nonatomic) BOOL isAutoStarted;
@property (nonatomic) BOOL isPrivacyEnabled;
@property (nonatomic) RDNAPortType portType;
@property (nonatomic) uint16_t port;
@end
@protocol RDNAPortClassExports<JSExport>
@end
@protocol RDNAServiceInstanceExports<JSExport>
@property (copy,nonatomic) NSString * serviceName;
@property (copy,nonatomic) NSString * targetHNIP;
@property (nonatomic) uint16_t targetPort;
@property (nonatomic) RDNAPort * portInfo;
@end
@protocol RDNAServiceClassExports<JSExport>
@end
@protocol RDNAResponseStatusInstanceExports<JSExport>
@property (nonatomic,strong) NSString * message;
@property (assign,nonatomic) RDNAResponseStatusCode statusCode;
@end
@protocol RDNAResponseStatusClassExports<JSExport>
@end
@protocol RDNAStatusInitInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) NSArray * services;
@property (nonatomic) RDNAPort * pxyDetails;
@property (nonatomic) NSArray * challenges;
@end
@protocol RDNAStatusInitClassExports<JSExport>
@end
@protocol RDNAStatusTerminateInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@end
@protocol RDNAStatusTerminateClassExports<JSExport>
@end
@protocol RDNAStatusPauseRuntimeInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@end
@protocol RDNAStatusPauseRuntimeClassExports<JSExport>
@end
@protocol RDNAStatusResumeRuntimeInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) NSArray * services;
@property (nonatomic) RDNAPort * pxyDetails;
@property (nonatomic) NSArray * challenges;
@property (nonatomic) RDNAResponseStatus * status;
@end
@protocol RDNAStatusResumeRuntimeClassExports<JSExport>
@end
@protocol RDNAStatusGetConfigInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) NSString * responseData;
@end
@protocol RDNAStatusGetConfigClassExports<JSExport>
@end
@protocol RDNAProxySettingsInstanceExports<JSExport>
@property (copy,nonatomic) NSString * proxyHNIP;
@property (nonatomic) uint16_t proxyPort;
@property (copy,nonatomic) NSString * username;
@property (copy,nonatomic) NSString * password;
@end
@protocol RDNAProxySettingsClassExports<JSExport>
@end
@protocol RDNADeviceDetailsInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSString * deviceUUID;
@property (copy,nonatomic) NSString * deviceName;
@property (readonly,nonatomic) RDNADeviceBinding deviceBinding;
@property (readonly,copy,nonatomic) NSString * deviceStatus;
@property (readonly,copy,nonatomic) NSString * deviceRegistrationTime;
@property (readonly,nonatomic) NSTimeInterval deviceRegistrationEpochTime;
@property (readonly,copy,nonatomic) NSString * lastAccessTime;
@property (readonly,nonatomic) NSTimeInterval lastAccessEpochTime;
@property (readonly,copy,nonatomic) NSString * AppUUID;
@property (readonly,nonatomic) BOOL currentDevice;
-(void) deleteDevice;
-(void) setDeviceName: (NSString *) deviceName ;
@end
@protocol RDNADeviceDetailsClassExports<JSExport>
@end
@protocol RDNAStatusGetRegisteredDeviceDetailsInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) NSArray * devices;
@property (nonatomic) RDNAResponseStatus * status;
@end
@protocol RDNAStatusGetRegisteredDeviceDetailsClassExports<JSExport>
@end
@protocol RDNAStatusUpdateDeviceDetailsInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) RDNAResponseStatus * status;
@end
@protocol RDNAStatusUpdateDeviceDetailsClassExports<JSExport>
@end
@protocol RDNAExpectedResponseInstanceExports<JSExport>
@property (nonatomic,strong) NSString * responseLabel;
@property (nonatomic,strong) NSString * response;
@property (nonatomic) int nAuthLevel;
@property (nonatomic,strong) NSString * authenticator;
@end
@protocol RDNAExpectedResponseClassExports<JSExport>
@end
@protocol RDNAResponseLabelInstanceExports<JSExport>
@property (nonatomic,strong) NSString * responseLabel;
@property (nonatomic,strong) NSString * response;
@end
@protocol RDNAResponseLabelClassExports<JSExport>
@end
@protocol RDNANotfBodyInstanceExports<JSExport>
@property (nonatomic,strong) NSString * language;
@property (nonatomic,strong) NSString * subject;
@property (nonatomic,strong) NSString * notificationMessage;
@property (nonatomic,strong) NSArray * displayLabels;
@end
@protocol RDNANotfBodyClassExports<JSExport>
@end
@protocol RDNANotificationInstanceExports<JSExport>
@property (nonatomic,strong) NSString * notificationID;
@property (nonatomic,strong) NSString * notificationResponse;
@property (nonatomic) NSTimeInterval notificationCreatedEpochTime;
@property (nonatomic,strong) NSString * notificationExpireTime;
@property (nonatomic) NSTimeInterval notificationExpireEpochTime;
@property (nonatomic,strong) NSString * enterpriseID;
@property (nonatomic) int nNumLanguages;
@property (nonatomic,strong) NSArray * notfBody;
@property (nonatomic,strong) NSArray * expectedResponse;
@end
@protocol RDNANotificationClassExports<JSExport>
@end
@protocol RDNANotfHistBodyInstanceExports<JSExport>
@property (nonatomic,strong) NSString * language;
@property (nonatomic,strong) NSString * subject;
@property (nonatomic,strong) NSString * notificationMessage;
@end
@protocol RDNANotfHistBodyClassExports<JSExport>
@end
@protocol RDNANotificationHistoryInstanceExports<JSExport>
@property (nonatomic) int nNumLanguages;
@property (nonatomic,strong) NSString * notificationID;
@property (nonatomic,strong) NSString * status;
@property (nonatomic,strong) NSArray * notfBody;
@property (nonatomic,strong) NSString * actionPerformed;
@property (nonatomic,strong) NSString * deviceName;
@property (nonatomic,strong) NSString * deviceUUID;
@property (nonatomic,strong) NSString * createdTime;
@property (nonatomic) NSTimeInterval createdEpochTime;
@property (nonatomic,strong) NSString * updatedTime;
@property (nonatomic) NSTimeInterval updatedEpochTime;
@property (nonatomic,strong) NSString * expiredTime;
@property (nonatomic) NSTimeInterval expiredEpochTime;
@property (nonatomic,strong) NSString * enterpriseID;
@property (nonatomic,strong) NSString * signingStatus;
@property (nonatomic,strong) NSString * deliveryStatus;
@end
@protocol RDNANotificationHistoryClassExports<JSExport>
@end
@protocol RDNAStatusGetNotificationsInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) int totalNotificationCount;
@property (nonatomic) int startIndex;
@property (nonatomic) int fetchedNotificationCount;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) RDNAResponseStatus * status;
@property (nonatomic,strong) NSArray * notifications;
@end
@protocol RDNAStatusGetNotificationsClassExports<JSExport>
@end
@protocol RDNAStatusUpdateNotificationInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) NSString * notificationID;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) RDNAResponseStatus * status;
@end
@protocol RDNAStatusUpdateNotificationClassExports<JSExport>
@end
@protocol RDNAStatusGetNotificationHistoryInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) int totalNotificationCount;
@property (nonatomic) RDNAResponseStatus * status;
@property (nonatomic,strong) NSArray * notificationHistory;
@end
@protocol RDNAStatusGetNotificationHistoryClassExports<JSExport>
@end
@protocol RDNAStatusCheckChallengeResponseInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) RDNAPort * pxyDetails;
@property (nonatomic) RDNAResponseStatus * status;
@property (nonatomic) NSArray * services;
@property (nonatomic) NSArray * challenges;
@property (nonatomic,strong) NSString * jwt;
@end
@protocol RDNAStatusCheckChallengeResponseClassExports<JSExport>
@end
@protocol RDNAStatusUpdateChallengesInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) RDNAResponseStatus * status;
@property (nonatomic) NSArray * challenges;
@end
@protocol RDNAStatusUpdateChallengesClassExports<JSExport>
@end
@protocol RDNAStatusGetAllChallengesInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) RDNAResponseStatus * status;
@property (nonatomic) NSArray * challenges;
@end
@protocol RDNAStatusGetAllChallengesClassExports<JSExport>
@end
@protocol RDNAStatusGetPostLoginChallengesInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) RDNAResponseStatus * status;
@property (nonatomic) NSArray * challenges;
@end
@protocol RDNAStatusGetPostLoginChallengesClassExports<JSExport>
@end
@protocol RDNAStatusForgotPasswordInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) RDNAResponseStatus * status;
@property (nonatomic) NSArray * challenges;
@end
@protocol RDNAStatusForgotPasswordClassExports<JSExport>
@end
@protocol RDNAStatusLogOffInstanceExports<JSExport>
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) NSArray * services;
@property (nonatomic) RDNAPort * pxyDetails;
@property (nonatomic) NSArray * challenges;
@property (nonatomic) RDNAResponseStatus * status;
@end
@protocol RDNAStatusLogOffClassExports<JSExport>
@end
@protocol RDNAIWACredsInstanceExports<JSExport>
@property (nonatomic,strong) NSString * userName;
@property (nonatomic,strong) NSString * password;
@property (assign) RDNAIWAAuthStatus authStatus;
@end
@protocol RDNAIWACredsClassExports<JSExport>
@end
@protocol RDNAHTTPRequestInstanceExports<JSExport>
@property (assign,nonatomic) RDNAHttpMethods method;
@property (nonatomic,strong) NSString * url;
@property (nonatomic,strong) NSDictionary * headers;
@property (nonatomic,strong) NSData * body;
@end
@protocol RDNAHTTPRequestClassExports<JSExport>
@end
@protocol RDNAHTTPResponseInstanceExports<JSExport>
@property (copy,nonatomic) NSString * version;
@property (assign,nonatomic) int statusCode;
@property (nonatomic,strong) NSString * statusMessage;
@property (nonatomic,strong) NSDictionary * headers;
@property (nonatomic,strong) NSData * body;
@end
@protocol RDNAHTTPResponseClassExports<JSExport>
@end
@protocol RDNAHTTPStatusInstanceExports<JSExport>
@property (assign,nonatomic) int errorCode;
@property (nonatomic) RDNAError * error;
@property (assign,nonatomic) int requestID;
@property (nonatomic,strong) RDNAHTTPRequest * request;
@property (nonatomic,strong) RDNAHTTPResponse * response;
@end
@protocol RDNAHTTPStatusClassExports<JSExport>
@end
@protocol RDNASSLCertificateInstanceExports<JSExport>
@property (nonatomic,strong) NSString * p12Certificate;
@property (nonatomic,strong) NSString * password;
@property (assign,nonatomic) BOOL enableSSL;
@end
@protocol RDNASSLCertificateClassExports<JSExport>
@end
@protocol RDNAChallengeInfoInstanceExports<JSExport>
@property (nonatomic,strong) NSString * infoKey;
@property (nonatomic,strong) NSString * infoMessage;
@end
@protocol RDNAChallengeInfoClassExports<JSExport>
@end
@protocol RDNAChallengeInstanceExports<JSExport>
@property (readonly,nonatomic,strong) NSString * name;
@property (readonly,assign,nonatomic) RDNAChallengePromptType type;
@property (readonly,assign,nonatomic) int index;
@property (readonly,assign,nonatomic) int subChallengeIndex;
@property (readonly,nonatomic,strong) NSArray * info;
@property (readonly,nonatomic,strong) NSArray * prompts;
@property (readonly,assign,nonatomic) int attemptsLeft;
@property (readonly,assign,nonatomic) BOOL shouldValidateResponse;
@property (readonly,nonatomic,strong) NSArray * responsePolicies;
@property (nonatomic,strong) NSString * responseKey;
@property (nonatomic,strong) NSString * responseValue;
@property (nonatomic) RDNAChallengeOpMode challengeOperation;
@end
@protocol RDNAChallengeClassExports<JSExport>
@end
@protocol RDNAErrorInstanceExports<JSExport>
@property (nonatomic) int longErrorCode;
@property (nonatomic) RDNAErrorID errorCode;
@property (copy,nonatomic) NSString * errorString;
@end
@protocol RDNAErrorClassExports<JSExport>
@end
@protocol RDNASessionInstanceExports<JSExport>
@property (copy,nonatomic) NSString * sessionID;
@property (nonatomic) RDNASessionType sessionType;
@end
@protocol RDNASessionClassExports<JSExport>
@end
@protocol RDNARequestStatusInstanceExports<JSExport>
@property (nonatomic) int statusCode;
@property (copy,nonatomic) NSString * statusMessage;
@end
@protocol RDNARequestStatusClassExports<JSExport>
@end
@protocol RDNAGroupInfoInstanceExports<JSExport>
@property (nonatomic,strong) NSString * groupName;
@property (nonatomic,strong) NSString * groupDescription;
@end
@protocol RDNAGroupInfoClassExports<JSExport>
@end
@protocol RDNAAdditionalInfoInstanceExports<JSExport>
@property (nonatomic) int RDNAProxyPort;
@property (nonatomic) BOOL isRDNAProxyPortLocalHost;
@property (nonatomic) BOOL setGlobalProxy;
@property (nonatomic) BOOL isAdUser;
@property (copy,nonatomic) NSString * JWT;
@property (copy,nonatomic) NSString * accessTokenInfo;
@property (copy,nonatomic) NSString * jwtJsonTokenInfo;
@property (copy,nonatomic) NSString * settings;
@property (copy,nonatomic) NSString * configSettings;
@property (copy,nonatomic) NSString * mTLSP12Bundle;
@property (nonatomic,strong) NSArray * loginIDs;
@property (copy,nonatomic) NSString * currentWorkFlow;
@property (copy,nonatomic) NSString * idvUserRole;
@property (nonatomic,strong) NSMutableArray * availableGroupInfo;
@end
@protocol RDNAAdditionalInfoClassExports<JSExport>
@end
@protocol RDNAChallengeResponseInstanceExports<JSExport>
@property (nonatomic) RDNARequestStatus * status;
@property (nonatomic,strong) NSArray * info;
@property (nonatomic) RDNASession * sessionInfo;
@property (nonatomic) RDNAAdditionalInfo * additionalInfo;
@end
@protocol RDNAChallengeResponseClassExports<JSExport>
@end
@protocol RDNAAppInfoInstanceExports<JSExport>
@property (nonatomic,strong) NSString * appName;
@property (nonatomic,strong) NSString * appSha256;
@property (nonatomic,strong) NSString * packageName;
@end
@protocol RDNAAppInfoClassExports<JSExport>
@end
@protocol RDNANetworkInfoInstanceExports<JSExport>
@property (nonatomic,strong) NSString * ssid;
@property (nonatomic,strong) NSString * bssid;
@property (nonatomic,strong) NSString * maliciousAddress;
@property (nonatomic,strong) NSString * maliciousMacAddress;
@end
@protocol RDNANetworkInfoClassExports<JSExport>
@end
@protocol RDNAThreatInstanceExports<JSExport>
@property (nonatomic,strong) NSString * threatName;
@property (nonatomic,strong) NSString * threatMsg;
@property (nonatomic,strong) NSString * threatReason;
@property (nonatomic,strong) NSString * threatSeverity;
@property (nonatomic,strong) NSString * threatCategory;
@property (nonatomic,strong) NSString * configured_action;
@property (nonatomic) int threatId;
@property (nonatomic) RDNAAppInfo * appInfo;
@property (nonatomic) RDNANetworkInfo * networkInfo;
@property (nonatomic) BOOL shouldProceedWithThreats;
@property (nonatomic) BOOL rememberActionForSession;
@end
@protocol RDNAThreatClassExports<JSExport>
@end
@protocol RDNAThreatDetailsInstanceExports<JSExport>
@property (nonatomic,strong) NSArray * userConsentThreats;
@property (nonatomic,strong) NSArray * terminateOnThreats;
@end
@protocol RDNAThreatDetailsClassExports<JSExport>
@end
@protocol RDNAThreatLogInstanceExports<JSExport>
@property (nonatomic,strong) NSString * threatName;
@property (nonatomic,strong) NSString * threatMsg;
@property (nonatomic,strong) NSString * threatReason;
@property (nonatomic,strong) NSString * threatSeverity;
@property (nonatomic,strong) NSString * threatCategory;
@property (nonatomic) int threatId;
@property (nonatomic) RDNAAppInfo * appInfo;
@property (nonatomic) RDNANetworkInfo * networkInfo;
@property (nonatomic) NSString * reportedTime;
@property (nonatomic) NSString * actionTakenTime;
@property (nonatomic,strong) NSString * configuredAction;
@property (nonatomic,strong) NSString * actionTaken;
@end
@protocol RDNAThreatLogClassExports<JSExport>
@end
@protocol RDNAInitProgressStatusInstanceExports<JSExport>
@property (nonatomic) RDNAInitState systemThreatCheckStatus;
@property (nonatomic) RDNAInitState appThreatCheckStatus;
@property (nonatomic) RDNAInitState networkThreatCheckStatus;
@property (nonatomic) RDNAInitState initializeStatus;
@end
@protocol RDNAInitProgressStatusClassExports<JSExport>
@end
@protocol RDNAThreatLogDetailsInstanceExports<JSExport>
@property (nonatomic) int totalLogsCount;
@property (nonatomic) int startIndex;
@property (nonatomic) RDNAError * error;
@property (nonatomic) RDNAThreatLog * threatLog;
@end
@protocol RDNAThreatLogDetailsClassExports<JSExport>
@end
@protocol RDNASecretQuestionAndAnswerInstanceExports<JSExport>
@property (copy,nonatomic) NSString * secretQuestion;
@property (copy,nonatomic) NSString * secretAnswer;
@end
@protocol RDNASecretQuestionAndAnswerClassExports<JSExport>
@end
@protocol RDNADeviceAuthenticationDetailsInstanceExports<JSExport>
@property (nonatomic) RDNALDACapabilities authenticationType;
@property (nonatomic) BOOL isEnabled;
@end
@protocol RDNADeviceAuthenticationDetailsClassExports<JSExport>
@end
@protocol RDNADataSigningDetailsInstanceExports<JSExport>
@property (nonatomic,strong) NSString * dataPayload;
@property (nonatomic,strong) NSString * payloadSignature;
@property (nonatomic,strong) NSString * dataSignatureID;
@property (nonatomic) RDNAAuthLevel authLevel;
@property (nonatomic) RDNAAuthenticatorType authenticatorType;
@property (nonatomic,strong) NSString * reason;
@end
@protocol RDNADataSigningDetailsClassExports<JSExport>
@end
@protocol RDNAPrivacyStreamInstanceExports<JSExport>
-(int) writeDataIntoStream: (NSData *) data ;
-(int) endStream;
-(int) destroy;
@end
@protocol RDNAPrivacyStreamClassExports<JSExport>
@end
@protocol RDNAStructInstanceExports<JSExport>
@end
@protocol RDNAStructClassExports<JSExport>
@end
@protocol RDNAPrivacyStreamCallBacksInstanceExports_<JSExport>
-(int) onBlockReadyFor: (RDNAPrivacyStream *) rdnaPrivacyStream BlockReadyContext: (id) pvBlockReadyCtx PrivacyBlockBuffer: (NSData *) pvBlockBuf andBlockSize: (int) nBlockSize ;
@end
@protocol RDNAPrivacyStreamCallBacksClassExports_<JSExport>
@end
@protocol RDNAHTTPCallbacksInstanceExports_<JSExport>
-(int) onHttpResponse: (RDNAHTTPStatus *) status ;
@end
@protocol RDNAHTTPCallbacksClassExports_<JSExport>
@end
#pragma clang diagnostic pop