#import <Foundation/Foundation.h>

//! Project version number for RELIDXCFramework.
FOUNDATION_EXPORT double RELIDXCFrameworkVersionNumber;

//! Project version string for RELIDXCFramework.
FOUNDATION_EXPORT const unsigned char RELIDXCFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RELIDXCFramework/PublicHeader.h>

#import "RDNAStruct.h"
#import "RDNA.h"
