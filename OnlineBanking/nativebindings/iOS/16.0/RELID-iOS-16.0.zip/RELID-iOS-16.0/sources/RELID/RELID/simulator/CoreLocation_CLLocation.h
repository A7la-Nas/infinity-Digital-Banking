#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLLocation_symbols(JSContext*);
@interface JSValue (CoreLocation_CLLocation)
+(JSValue*) valueWithCLLocationCoordinate2D: (CLLocationCoordinate2D) s inContext: (JSContext*) context;
-(CLLocationCoordinate2D) toCLLocationCoordinate2D;
@end
@protocol CLFloorInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) NSInteger level;
@end
@protocol CLFloorClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
@protocol CLLocationSourceInformationInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) BOOL isSimulatedBySoftware;
@property (readonly,nonatomic) BOOL isProducedByAccessory;
JSExportAs(initWithSoftwareSimulationStateAndExternalAccessoryState,
-(id) jsinitWithSoftwareSimulationState: (BOOL) isSoftware andExternalAccessoryState: (BOOL) isAccessory );
@end
@protocol CLLocationSourceInformationClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
@protocol CLLocationInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) CLLocationCoordinate2D coordinate;
@property (readonly,nonatomic) CLLocationDistance altitude;
@property (readonly,nonatomic) CLLocationDistance ellipsoidalAltitude;
@property (readonly,nonatomic) CLLocationAccuracy horizontalAccuracy;
@property (readonly,nonatomic) CLLocationAccuracy verticalAccuracy;
@property (readonly,nonatomic) CLLocationDirection course;
@property (readonly,nonatomic) CLLocationDirectionAccuracy courseAccuracy;
@property (readonly,nonatomic) CLLocationSpeed speed;
@property (readonly,nonatomic) CLLocationSpeedAccuracy speedAccuracy;
@property (readonly,copy,nonatomic) NSDate * timestamp;
@property (readonly,copy,nonatomic) CLFloor * floor;
@property (readonly,nonatomic) CLLocationSourceInformation * sourceInformation;
JSExportAs(initWithLatitudeLongitude,
-(id) jsinitWithLatitude: (CLLocationDegrees) latitude longitude: (CLLocationDegrees) longitude );
JSExportAs(initWithCoordinateAltitudeHorizontalAccuracyVerticalAccuracyTimestamp,
-(id) jsinitWithCoordinate: (CLLocationCoordinate2D) coordinate altitude: (CLLocationDistance) altitude horizontalAccuracy: (CLLocationAccuracy) hAccuracy verticalAccuracy: (CLLocationAccuracy) vAccuracy timestamp: (NSDate *) timestamp );
JSExportAs(initWithCoordinateAltitudeHorizontalAccuracyVerticalAccuracyCourseSpeedTimestamp,
-(id) jsinitWithCoordinate: (CLLocationCoordinate2D) coordinate altitude: (CLLocationDistance) altitude horizontalAccuracy: (CLLocationAccuracy) hAccuracy verticalAccuracy: (CLLocationAccuracy) vAccuracy course: (CLLocationDirection) course speed: (CLLocationSpeed) speed timestamp: (NSDate *) timestamp );
JSExportAs(initWithCoordinateAltitudeHorizontalAccuracyVerticalAccuracyCourseCourseAccuracySpeedSpeedAccuracyTimestamp,
-(id) jsinitWithCoordinate: (CLLocationCoordinate2D) coordinate altitude: (CLLocationDistance) altitude horizontalAccuracy: (CLLocationAccuracy) hAccuracy verticalAccuracy: (CLLocationAccuracy) vAccuracy course: (CLLocationDirection) course courseAccuracy: (CLLocationDirectionAccuracy) courseAccuracy speed: (CLLocationSpeed) speed speedAccuracy: (CLLocationSpeedAccuracy) speedAccuracy timestamp: (NSDate *) timestamp );
JSExportAs(initWithCoordinateAltitudeHorizontalAccuracyVerticalAccuracyCourseCourseAccuracySpeedSpeedAccuracyTimestampSourceInfo,
-(id) jsinitWithCoordinate: (CLLocationCoordinate2D) coordinate altitude: (CLLocationDistance) altitude horizontalAccuracy: (CLLocationAccuracy) hAccuracy verticalAccuracy: (CLLocationAccuracy) vAccuracy course: (CLLocationDirection) course courseAccuracy: (CLLocationDirectionAccuracy) courseAccuracy speed: (CLLocationSpeed) speed speedAccuracy: (CLLocationSpeedAccuracy) speedAccuracy timestamp: (NSDate *) timestamp sourceInfo: (CLLocationSourceInformation *) sourceInfo );
-(CLLocationDistance) getDistanceFrom: (const CLLocation *) location ;
-(CLLocationDistance) distanceFromLocation: (const CLLocation *) location ;
@end
@protocol CLLocationClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop