

#import <Foundation/Foundation.h>
#import <sys/types.h>
#import <CoreLocation/CoreLocation.h>

NS_ASSUME_NONNULL_BEGIN
/*
 @brief Enum RDNAMethodID - These identifiers are used to identify the routine when the StatusUpdate callback routine is invoked.
 */
typedef NS_ENUM(NSInteger, RDNAMethodID) {
    RDNA_METH_NONE = 0,                          /* Not a specific method ID                           */
    RDNA_METH_INITIALIZE,                        /* Initialize runtime                                 */
    RDNA_METH_TERMINATE,                         /* Terminate runtime                                  */
    RDNA_METH_RESUME,                            /* Resume runtime                                     */
    RDNA_METH_PAUSE,                             /* Pause runtime                                      */
    RDNA_METH_GET_CONFIG,                        /* Get config call back method                        */
    RDNA_METH_CHECK_CHALLENGE,                   /* Check challenge call back method                   */
    RDNA_METH_UPDATE_CHALLENGE,                  /* Update user Challenge call back method             */
    RDNA_METH_GET_ALL_CHALLENGES,                /* Get All challenges of user call back method        */
    RDNA_METH_LOGOFF,                            /* Log Off user call back method*/
    RDNA_METH_FORGOT_PASSWORD,                   /* Forgot password call back method*/
    RDNA_METH_GET_POST_LOGIN_CHALLENGES,         /* Get Post login challenge callback method           */
    RDNA_METH_GET_DEVICE_DETAILS,                /* Get all registred devices for the user             */
    RDNA_METH_UPDATE_DEVICE_DETAILS,             /* Update device details of the user                  */
    RDNA_METH_GET_NOTIFICATIONS,                 /* Get pending notifications from server              */
    RDNA_METH_UPDATE_NOTIFICATION,               /* Update notification status to server               */
    RDNA_METH_GET_NOTIFICATION_HISTORY,          /* Get notifications action taken by user from server */
    RDNA_METH_OPEN_HTTP_CONNECTION,              /* Create http rest api tunnel request                */
    RDNA_ADD_ALTERNATE_LOGIN_ID,
    RDNA_METH_DELETE_LOGIN_ID,
    RDNA_METH_EDIT_LOGIN_ID,
    RDNA_METH_GET_ALL_REGISTERED_LOGIN_IDS,
    RDNA_METH_GET_NOTIFICATIONS_EX
};

typedef NS_ENUM(NSInteger, RDNALoggingLevel) {
    RDNA_NO_LOGS = 0,
    RDNA_LOG_WARN,
    RDNA_LOG_NOTIFY,
    RDNA_LOG_NETWORK,
    RDNA_LOG_DNA,
    RDNA_LOG_DEBUG,
    RDNA_LOG_VERBOSE
};

/*
 @brief Enum RDNAErrorID - This enum specifies all the error codes which RDNA returns back to the client.
 */
typedef NS_ENUM(NSInteger, RDNAErrorID) {
    RDNA_ERR_NONE = 0,                               /* No Error                                             */
    RDNA_ERR_NOT_INITIALIZED,                        /* If core not initialized                              */
    RDNA_ERR_GENERIC_ERROR,                          /* If generic error occured                             */
    RDNA_ERR_INVALID_VERSION,                        /* If invalid SDK Version                               */
    RDNA_ERR_INVALID_ARGS,                           /* If invalid args are passed                           */
    RDNA_ERR_SESSION_EXPIRED,                        /* If session has expired                               */
    RDNA_ERR_PARENT_PROXY_CONNECT_FAILED,            /* If failed to connect to proxy server                 */
    RDNA_ERR_NULL_CALLBACKS,                         /* If Null callback/ptr passed in                       */
    RDNA_ERR_INVALID_HOST,                           /* If Null or empty hostname/IP                         */
    RDNA_ERR_INVALID_PORTNUM,                        /* If Invalid port number                               */
    RDNA_ERR_INVALID_AGENT_INFO,                     /* If agent info is invalid                             */
    RDNA_ERR_UNSUPPORTED_AGENT_RELID,                /* If agent info contains an unsupported relid version  */
    RDNA_ERR_FAILED_TO_CONNECT_TO_SERVER,            /* If failed to connect to server                       */
    RDNA_ERR_INVALID_SAVED_CONTEXT,                  /* If Invalid saved context                             */
    RDNA_ERR_INVALID_HTTP_REQUEST,                   /* If Invalid HTTP request                              */
    RDNA_ERR_INVALID_HTTP_RESPONSE,                  /* If Invalid HTTP response                             */
    RDNA_ERR_INVALID_CIPHERSPECS,                    /* If cipherspecs is invalid                            */
    RDNA_ERR_SERVICE_NOT_SUPPORTED,                  /* If service not supported                             */
    RDNA_ERR_FAILED_TO_GET_STREAM_PRIVACYSCOPE,      /* If failed to get stream privacy scope                */
    RDNA_ERR_FAILED_TO_GET_STREAM_TYPE,              /* If failed to get stream type                         */
    RDNA_ERR_FAILED_TO_WRITE_INTO_STREAM,            /* If failed to write into data stream                  */
    RDNA_ERR_FAILED_TO_END_STREAM,                   /* If failed to end stream                              */
    RDNA_ERR_FAILED_TO_DESTROY_STREAM,               /* If failed to destroy stream                          */
    RDNA_ERR_FAILED_TO_INITIALIZE,                   /* If failed to initialize                              */
    RDNA_ERR_FAILED_TO_PAUSERUNTIME,                 /* If failed to pause runtime                           */
    RDNA_ERR_FAILED_TO_RESUMERUNTIME,                /* If failed to resume runtime                          */
    RDNA_ERR_FAILED_TO_TERMINATE,                    /* If failed to terminate                               */
    RDNA_ERR_FAILED_TO_GET_CIPHERSALT,               /* If failed to get ciphersalt                          */
    RDNA_ERR_FAILED_TO_GET_CIPHERSPECS,              /* If failed to get cipherspecs                         */
    RDNA_ERR_FAILED_TO_GET_AGENT_ID,                 /* If failed to get agent id                            */
    RDNA_ERR_FAILED_TO_GET_SESSION_ID,               /* If failed to get session id                          */
    RDNA_ERR_FAILED_TO_GET_DEVICE_ID,                /* If failed to get device id                           */
    RDNA_ERR_FAILED_TO_GET_SERVICE,                  /* If failed to get service                             */
    RDNA_ERR_FAILED_TO_START_SERVICE,                /* If failed to start service                           */
    RDNA_ERR_FAILED_TO_STOP_SERVICE,                 /* If failed to stop service                            */
    RDNA_ERR_FAILED_TO_ENCRYPT_DATA_PACKET,          /* If failed to encrypt data packet                     */
    RDNA_ERR_FAILED_TO_DECRYPT_DATA_PACKET,          /* If failed to decrypt data packet                     */
    RDNA_ERR_FAILED_TO_ENCRYPT_HTTP_REQUEST,         /* If failed to encrypt HTTP request                    */
    RDNA_ERR_FAILED_TO_DECRYPT_HTTP_RESPONSE,        /* If failed to decrypt HTTP response                   */
    RDNA_ERR_FAILED_TO_CREATE_PRIVACY_STREAM,        /* If failed to create privacy stream                   */
    RDNA_ERR_FAILED_TO_CHECK_CHALLENGE,              /* If failed to check challenges                        */
    RDNA_ERR_FAILED_TO_UPDATE_CHALLENGE,             /* If failed to update challenges                       */
    RDNA_ERR_FAILED_TO_GET_CONFIG,                   /* If failed to get config                              */
    RDNA_ERR_FAILED_TO_GET_ALL_CHALLENGES,           /* If failed to get all challenges                      */
    RDNA_ERR_FAILED_TO_LOGOFF,                       /* If failed to log off                                 */
    RDNA_ERR_FAILED_TO_RESET_CHALLENGE,              /* If failed to reset challenge                         */
    RDNA_ERR_FAILED_TO_DO_FORGOT_PASSWORD,           /* If failed to update forgot pass operation            */
    RDNA_ERR_FAILED_TO_GET_POST_LOGIN_CHALLENGES,    /* If failed to get post login challenges               */
    RDNA_ERR_FAILED_TO_GET_REGISTERD_DEVICE_DETAILS, /* If failed to get registered device details           */
    RDNA_ERR_FAILED_TO_UPDATE_DEVICE_DETAILS,        /* If failed to update registered device details        */
    RDNA_ERR_FAILED_TO_GET_NOTIFICATIONS,            /* If failed to get notification from server            */
    RDNA_ERR_FAILED_TO_UPDATE_NOTIFICATION,          /* If failed to update notification to server           */
    RDNA_ERR_FAILED_TO_OPEN_HTTP_CONNECTION,         /* If any failure occurs while openeing http tunnel(api)*/
    RDNA_ERR_SSL_INIT_FAILED,
    RDNA_ERR_SSL_ACTIVITY_FAILED,
    RDNA_ERR_DNS_FAILED,
    RDNA_ERR_NET_DOWN,
    RDNA_ERR_SOCK_TIMEDOUT,
    RDNA_ERR_DNA_INTERNAL,
    RDNA_ERR_INVALID_USER_MR_STATE,
    RDNA_ERR_NOTF_SIGN_INTERNAL_FAILURE,
    RDNA_ERR_INVALID_PROXY_CREDS,
    RDNA_ERR_CONNECTION_TIMEDOUT,
    RDNA_ERR_DNS_TIMEDOUT,
    RDNA_ERR_RESPONSE_TIMEDOUT,
    RDNA_ERR_UNSUPPORTED_USER_RELID_VERSION,
    RDNA_ERR_RMAK_INCORRECT_TIMESTAMP,
    RDNA_ERR_FAILED_TO_GET_NOTF_HIST_USER_NOT_LOGGED_IN,
    RDNA_ERR_FAILED_TO_GET_NOTIFICATION_HISTORY,
    RDNA_ERR_INVALID_TUNNEL_CONFIGURATION,
    RDNA_ERR_FAILED_TO_PARSE_DEVICES,                /* If parsing the device details failed                 */
    RDNA_ERR_INVALID_CHALLENGE_CONFIG,               /* If there is any mistake in challenge configuration   */
    RDNA_ERR_INVALID_HTTP_API_REQ_URL,               /* If URL in HTTP req is invalid                        */
    RDNA_ERR_NO_MEMORY,
    RDNA_ERR_INVALID_CONTEXT,
    RDNA_ERR_CIPHERTEXT_LENGTH_INVALID,
    RDNA_ERR_CIPHERTEXT_EMPTY,
    RDNA_ERR_PLAINTEXT_EMPTY,
    RDNA_ERR_PLAINTEXT_LENGTH_INVALID,
    RDNA_ERR_USERID_EMPTY,
    RDNA_ERR_CHALLENGE_EMPTY,
    RDNA_ERR_FAILED_TO_SERIALIZE_JSON,
    RDNA_ERR_USECASE_EMPTY,
    RDNA_ERR_NOTF_HISTORY_ARRAYLEN_MISMATCH,
    RDNA_ERR_INVALID_SERVICE_NAME,
    RDNA_ERR_DEVICE_DETAILS_EMPTY,
    RDNA_ERR_FAILED_TO_DESERIALIZE_JSON,
    RDNA_ERR_INVALID_CHALLENGE_JSON,
    RDNA_ERR_RDNA_ALREADY_INITIALIZED,
    RDNA_ERR_LDA_BIO_FINGERPRINT_CANCELLED_BY_USER,
    RDNA_ERR_LDA_BIO_FINGERPRINT_CANCELLED_BY_SYSTEM,
    RDNA_ERR_LDA_BIO_FINGERPRINT_LOCKED_OUT,
    RDNA_ERR_LDA_BIO_FACERECOGNITION_CANCELLED_BY_USER,
    RDNA_ERR_LDA_BIO_FACERECOGNITION_CANCELLED_BY_SYSTEM,
    RDNA_ERR_LDA_BIO_FACERECOGNITION_LOCKED_OUT,
    RDNA_ERR_LDA_PATTERN_CANCELLED_BY_USER,
    RDNA_ERR_ARCHITECTURE_NOT_SUPPORTED,
    RDNA_ERR_INVALID_DEVICE_CONTEXT,
    RDNA_ERR_INVALID_NOTIFICATION_ACTIVITY_CLASS,
    RDNA_ERR_LDA_FINGERPRINT_AUTH_DISABLED_DURING_LOGIN,
    RDNA_ERR_LDA_FACE_AUTH_DISABLED_DURING_LOGIN,
    RDNA_ERR_LDA_PATTERN_AUTH_DISABLED_DURING_LOGIN,
    RDNA_ERR_INCONSISTANT_USER_DEVICE_STATE,
    RDNA_ERR_CONFLICTING_CALLBACK_OBJECTS,
    RDNA_ERR_TOTP_INVALID_TOTP_CONTEXT,
    RDNA_ERR_INVALID_TOTP_CONFIG,
    RDNA_ERR_USER_REGISTERED_FOR_TOTP,
    RDNA_ERR_TOTP_INVALID_CHALLENGE_SEQUENCE,
    RDNA_ERR_INVALID_TOTP_CREDENTIAL,
    RDNA_ERR_TOTP_AUTHENTIATION_CANCELLED,
    RDNA_ERR_USER_NOT_REGISTERED_FOR_TOTP,
    RDNA_ERR_USERNAME_MISMATCH_WITH_LOGGED_IN_USER,
    RDNA_ERR_INCONSISTENT_CORE_STATE,
    RDNA_ERR_TOTP_GENERIC_ERROR,
    RDNA_ERR_TOTP_BLOCKED_FOR_USER_DUE_TO_EXHAUSTED_ATTEMPTS,
    RDNA_ERR_TOTP_FAILED_TO_REGISTER_USER,
    RDNA_ERR_CIS_CONFIGURATION_INVALID,
    RDNA_ERR_INVALID_INITIAL_CHLNG_JSON,
    RDNA_ERR_NO_OR_INVALID_UPDATE_CHLNG_SEQ,
    RDNA_ERR_CHALLENGE_NOT_SUPPORTED,
    RDNA_ERR_INVALID_API_EXECUTED,
    RDNA_ERR_USER_ACTIVATION_CHOICE_NOT_SUPPORTED,
    RDNA_ERR_INVALID_USER_AUTH_CHALLENGE_SEQUENCE,
    RDNA_ERR_UPDATING_UNSUPPORTED_CRED,
    RDNA_ERR_INVALID_SUPPORTED_AUTH,
    RDNA_ERR_UNABLE_TO_STORE_USER_AUTH_STATE_DURING_ACTIVATION,
    RDNA_ERR_USER_LDA_AUTH_FAILED_DURING_ACTIVATION,
    RDNA_ERR_TOTP_NOT_SUPPORTED_BY_APPLICATION_AGENT,
    RDNA_ERR_INVALID_INITIAL_CHALLENGE,
    RDNA_ERR_LOGIN_ID_ALREADY_EXISTS,
    RDNA_ERR_ADD_LOGIN_ID_GENERIC_ERROR,
    RDNA_ERR_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_USER,
    RDNA_ERR_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_SYSTEM,
    RDNA_ERR_STEPUP_AUTH_LDA_BIO_FINGERPRINT_LOCKED_OUT,
    RDNA_ERR_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_USER,
    RDNA_ERR_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_SYSTEM,
    RDNA_ERR_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_LOCKED_OUT,
    RDNA_ERR_STEPUP_AUTH_LDA_PATTERN_CANCELLED_BY_USER,
    RDNA_ERR_STEPUP_AUTH_VERIFICATION_FAILED,
    RDNA_ERR_STEPUP_AUTH_LDA_DISABLED,
    RDNA_ERR_PSWD_POLICY_CONFIGURED_INVALID,
    RDNA_ERR_PSWD_POLICY_VALIDATION_FAILED,
    RDNA_ERR_SET_LOGIN_ID_COUNT_EXHAUSTED,
    RDNA_ERR_USER_ACTIVATION_RELID_NOT_FOUND,
    RDNA_ERR_APP_INTEGRITY_COMPROMISED,
    RDNA_ERR_DEVICE_SECURITY_CHECKS_FAILED,
    RDNA_ERR_IDV_PROCESS_FAILED,
    RDNA_ERR_CREDENTIAL_UPDATE_FAILED_DUE_TO_AUTH_FAILURE,
    RDNA_ERR_DEVICE_BLOCKED_BY_ADMIN,
    RDNA_ERR_SESSION_CREATION_FAILED,
    RDNA_ERR_LDA_MGMT_ATTEMPTS_EXHAUSTED_LOGGIN_OFF,
    RDNA_ERR_LDA_MGMT_NOT_SUPPORTED_NOT_CONFIGURED_DEVICE_INSECURE,
    RDNA_ERR_LDA_MGMT_FAILED_USER_NOT_LOGGED_IN,
    RDNA_ERR_LDA_MGMT_LDA_ALREADY_MANAGED_NOTHING_TO_UPDATE,
    RDNA_ERR_LDA_MGMT_INTERNAL_STATE_INVALID,
    RDNA_ERR_LDA_MGMT_INVALID_CHOICE,
    RDNA_ERR_LDA_MGMT_FAILED_TO_INITIATE_AUTH_PROCESS_DATA_EXTRACTION_FAILED,
    RDNA_ERR_LDA_MGMT_OPERATION_FAILED_INVALID_ARGS,
    RDNA_ERR_LDA_MGMT_FAILED_DUE_TO_STEUP_AUTH_FAILURE,
    RDNA_ERR_LDA_MGMT_FAILURE_TO_ENABLE_PATTERN,
    RDNA_ERR_LDA_ACTIVATION_SKIPPED_OR_FAILED,
    RDNA_ERR_RELID_STATUS_INVALID,   //server error 1031
    RDNA_ERR_DEVICE_LIMIT_EXCEEDED,  //server error 1071
    RDNA_ERR_GENERIC_SERVER_ERROR,
    RDNA_ERR_JWT_REFRESH_NOT_SUPPORTED,
    RDNA_ERR_INVALID_JWT_RESPONSE,
    RDNA_ERR_USER_NOT_LOGGED_IN,
    RDNA_ERR_PSWD_UPDATE_FAILED_SAME_NEW_AND_CURRENT_PSWD,
    RDNA_ERR_BIO_DOMAIN_STATE_CHANGED,
    RDNA_ERR_SESSION_TERMINATED_BIO_DOMAIN_STATE_CHANGED,
    RDNA_ERR_FEATURE_OR_OPERATION_NOT_SUPPORTED,
    RDNA_ERR_PATTERN_UPDATE_FAILED_SAME_NEW_AND_CURRENT_PATTERN,
    RDNA_ERR_APP_DEBUG_MODE_DETECTED,
    RDNA_ERR_EMULATOR_DETECTED,
    RDNA_ERR_APP_INSTALLED_FROM_UNKNOWN_SOURCE,
    RDNA_ERR_PACKAGE_INVALID,
    RDNA_ERR_APPLICATION_REPACKAGED,
    RDNA_ERR_FGT_LOGIN_ID_INVALID_SEARCH_PARAM,
    RDNA_ERR_SET_LOGIN_ID_INVALID_LOGIN_ID,
    RDNA_ERR_INITIALIZE_ALREADY_IN_PROGRESS,
    RDNA_ERR_CONNECTION_REFUSED,
    RDNA_ERR_CHECK_USER_BIO_TEMPLATE_GENERIC_FAILURE, /* Check IDV Bio template failure*/
    RDNA_ERR_INITIATE_SERVER_BIO_AUTH_INVALID_RETRIES, /* IDV Server Bio Auth Invalid retries*/
    RDNA_ERR_STEPUP_AUTH_NOT_CONFIGURED,
    RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_USER,
    RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FINGERPRINT_CANCELLED_BY_SYSTEM,
    RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FINGERPRINT_LOCKED_OUT,
    RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_USER,
    RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_CANCELLED_BY_SYSTEM,
    RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_BIO_FACERECOGNITION_LOCKED_OUT,
    RDNA_ERR_GENERIC_STEPUP_AUTH_LDA_PATTERN_CANCELLED_BY_USER,
    RDNA_ERR_GENERIC_STEPUP_AUTH_VERIFICATION_FAILED,
    RDNA_ERR_GENEREIC_STEPUP_AUTH_LDA_DISABLED,
    RDNA_ERR_OPEN_HTTP_MALFORMED_REQUEST,
    RDNA_ERR_OPEN_HTTP_UNSUPPORTED_METHOD,
    RDNA_ERR_OPEN_HTTP_UNSUPPORTED_PROTOCOL,
    RDNA_ERR_LDA_BIO_AUTHENTICATION_CANCELLED_BY_APPLICATION,
    RDNA_ERR_LDA_BIO_AUTHENTICATION_CONTEXT_INVALIDATED,
    RDNA_ERR_LDA_BIO_AUTHENTICATION_FAILED_BY_APPLE_WATCH,
    RDNA_ERR_LDA_BIO_AUTHENTICATION_NONINTERACTIVE_USERINTERFACE_FORBIDDEN,
    RDNA_ERR_LDA_BIO_AUTHENTICATION_ERROR_UNKNOWN,
    RDNA_ERR_LDA_BIO_AUTHENTICATION_NO_FALLBACK_AVAILABLE,
    RDNA_ERR_LDA_PASSCODE_NOT_SET,
    RDNA_ERR_LDA_BIO_AUTHENTICATION_NOT_SUPPORTED,
    RDNA_ERR_LDA_BIO_AUTHENTICATION_BIOMETRIC_NOT_ENROLLED,
    RDNA_ERR_NOTF_STEP_UP_AUTH_NOT_SUPPORTED,
    RDNA_STEPUP_AUTH_ALREADY_IN_PROGRESS,
    RDNA_STEP_UP_AUTH_ATTEMPTS_EXHAUSTED,
    RDNA_ERR_APP_INSIGHT_KEY_NOT_FOUND_IN_MTD_CONFIG,
    RDNA_ERR_CONNECTION_BROKEN_OR_FORCIBLY_CLOSED,
    RDNA_ERR_GENERIC_SET_LOGIN_ID_FAILED,
    RDNA_ERR_INSUFFICIENT_PRIVILEGES,
    RDNA_ERR_LOGGED_IN_USER_AND_KYC_USER_SHOULD_BE_DIFFERENT,
    RDNA_ERR_GENERIC_STEPUP_AUTH_ALREADY_IN_PROGRESS,
    RDNA_ERR_GENERIC_STEP_UP_AUTH_NOT_SUPPORTED,
    RDNA_ERR_TOTP_REGISTRATION_IN_PROGRESS,
    RDNA_ERR_LOGINID_SAME_AS_PRIMARY_USERID,
    RDNA_ERR_LDA_CONSENT_REJECTED_BY_USER
};

/*
 @brief Enum RDNAStreamType - These identifiers are used to identify the privecy stream type
 */
typedef NS_ENUM(NSInteger, RDNAStreamType) {
    RDNA_STREAM_TYPE_ENCRYPT = 0x00, /* a stream for encrypting */
    RDNA_STREAM_TYPE_DECRYPT = 0x01, /* a stream for decrypting */
};

/*
 @brief enum RDNAPortType - These flags specify attributes of the returned access port for the backend service.
 */
typedef NS_ENUM(NSInteger, RDNAPortType) {
    RDNA_PORT_TYPE_PROXY = 0x00,    /* port type is proxy           */
    RDNA_PORT_TYPE_PORTF,           /* port type is port forwarding */
    RDNA_PORT_TYPE_REST
};

/*
 @brief enum RDNAPrivacyScope - These flags specifies which level of key to be used for encryption in data encryption API's.
 */
typedef NS_ENUM(NSInteger, RDNAPrivacyScope) {
    RDNA_PRIVACY_SCOPE_SESSION = 0x01,  /* use session-specific keys */
    RDNA_PRIVACY_SCOPE_DEVICE = 0x02,   /* use device-specific keys  */
    RDNA_PRIVACY_SCOPE_USER = 0x04,     /* use user-specific keys    */
    RDNA_PRIVACY_SCOPE_AGENT = 0x08,    /* use agent-specific keys   */
};

/*
 @brief enum RDNAChallengePromptType - These flags specifies the prompted challenge type, whether the challenge is read only or read-write
 or one way prompt (like password)
 */
typedef NS_ENUM(NSInteger, RDNAChallengePromptType) {
    RDNA_PROMPT_BOOLEAN = 0,                /* Boolean prompt             */
    RDNA_PROMPT_ONE_WAY,                    /* One way prompt             */
    RDNA_PROMPT_TWO_WAY_READONLY,           /* Two way prompt read-only   */
    RDNA_PROMPT_TWO_WAY_READWRITE,          /* Two way prompt read-write  */
};

/*
 @brief enum RDNAChallengeStatusCode - These flags error codes occured in MFA flow of advance API-SDK
 */
typedef NS_ENUM(NSInteger, RDNAResponseStatusCode) {
    RDNA_RESP_STATUS_SUCCESS = 0,                                /* Success                                                   */
    RDNA_RESP_STATUS_NO_USER_ID,                                 /* No user Id.                                               */
    RDNA_RESP_STATUS_AUTH_FAILED,                                /* Authentication failed                                     */
    RDNA_RESP_STATUS_SEC_QA_MATCH_FAILED,                        /* Sec QA match failed                                       */
    RDNA_RESP_STATUS_NO_SEC_QA_PRESENT,                          /* No Sec QA present                                         */
    RDNA_RESP_STATUS_PWD_UPDATE_FAILED,                          /* Password update failed                                    */
    RDNA_RESP_STATUS_OTP_MATCH_FAILED,                           /* OTP matching failed                                       */
    RDNA_RESP_STATUS_SECONDARY_SEC_QA_MATCH_FAILED,              /* Secondary Sec QA match failed                             */
    RDNA_RESP_STATUS_ACT_CODE_MATCH_FAILED,                      /* Activation code match failed                              */
    RDNA_RESP_STATUS_ACT_CODE_EXPIRED,                           /* Activation code expired                                   */
    RDNA_RESP_STATUS_PASSWORD_EXPIRED,                           /* Password expired                                          */
    RDNA_RESP_STATUS_OTP_EXPIRED,                                /* OTP expired                                               */
    RDNA_RESP_STATUS_OTP_ALREADY_USED,                           /* OTP already exists                                        */
    RDNA_RESP_STATUS_AUTO_RESET_USER,                            /* Auto reset user                                           */
    RDNA_RESP_STATUS_INTERNAL_SERVER_ERROR,                      /* Internal server error                                     */
    RDNA_RESP_STATUS_POST_LOGIN_VERIFY_CREDS_FAILURE,            /* Post login verify credentials failure                     */
    RDNA_RESP_STATUS_DEVICE_UPDATE_FAILED,                       /* Failed to update device                                   */
    RDNA_RESP_STATUS_USER_UNENROLLED,                            /* User removed                                              */
    RDNA_RESP_STATUS_INVALID_USE_CASE,                           /* Invalid use case                                          */
    RDNA_RESP_STATUS_USER_LOCKED,                                /* User locked                                               */
    RDNA_RESP_STATUS_PERMANENT_DEVICE_LIMIT_EXCEEDED,            /* Permanent device limit exceeded                           */
    RDNA_RESP_STATUS_CHALLENGE_NOT_FOUND,                        /* Challenge not found                                       */
    RDNA_RESP_STATUS_TOKEN_BASED_AUTH_FAILED,                    /* Token authentication failed                               */
    RDNA_RESP_STATUS_TOKEN_BASED_AUTH_UPDATED,                   /* Token authentication updated                              */
    RDNA_RESP_STATUS_AD_USER_DISABLE,                            /* AD User disabled                                          */
    RDNA_RESP_STATUS_AD_USER_DELETED,                            /* AD User deleted                                           */
    RDNA_RESP_STATUS_USER_DEVICE_NOT_REGISTERED,                 /* User device not register                                  */
    RDNA_RESP_STATUS_USER_BLOCKED,                               /* User blocked                                              */
    RDNA_RESP_STATUS_USER_SUSPENDED,                             /* User suspended                                            */
    RDNA_RESP_STATUS_INVALID_CHALLENGE_JSON,                     /* Challenge JSON is invalid                                 */
    RDNA_RESP_STATUS_AD_PASSWORD_MISMATCH,                       /* AD password mismatch                                      */
    RDNA_RESP_STATUS_DEVICE_VALIDATION_FAILED,                   /* Device validation failed                                  */
    RDNA_RESP_STATUS_USER_ALREADY_ACTIVE,                        /* User already active                                       */
    RDNA_SECONDARY_USER_DEVICE_ACTIVATION_FLOW_REJECTED,         /* Secondary device activation is rejected                   */
    RDNA_SECONDARY_USER_DEVICE_FRAUD_DETECTED,                   /* Illegal or FRAUD access from UNKNOWN device detected.     */
    RDNA_SECONDARY_USER_DEVICE_ACTIVATION_NOTIFICATION_EXPIRED,  /* REL-ID Notification is expired, Please try again.         */
    RDNA_INTERNAL_VERIFY_SERVER_ERROR,                           /* INTERNAL_VERIFY_SERVER_ERROR                              */
    RDNA_RESET_DEVICE_FAILED,                                    /* user device reset failed                                  */
    RDNA_USER_DEVICE_BLOCKED,                                    /* User device blocked                                       */
    RDNA_RESP_STATUS_UNKNOWN_ERROR,                              /* Unknown error occured while updating/validating challenges */
    RDNA_RESP_STATUS_BLOCK_USERID                   /* This will be available only if the user is in blocked state on reception of status code 141 */
};

/*
 @brief enum RDNAIWAAuthStatus - These flags specifies the Integrated windows authentication credential status which will be set by the
 API-Client in getCredentials call back
 */
typedef NS_ENUM(NSInteger, RDNAIWAAuthStatus) {
    RDNA_IWA_AUTH_SUCCESS = 0,
    RDNA_IWA_AUTH_CANCELLED = 1,
    RDNA_IWA_AUTH_DEFERRED = 2
};

/*
 @brief enum RDNAChallengeOpMode - These flags specifies the operation on the challenges whether the challenges received are to set new challenge
 or the received challenges are to be verified by the user.
 */
typedef NS_ENUM(NSInteger, RDNAChallengeOpMode) {
    RDNA_CHALLENGE_OP_VERIFY = 0,
    RDNA_CHALLENGE_OP_SET,
    RDNA_OP_UPDATE_CREDENTIALS,
    RDNA_OP_AUTHORIZE_NOTIFICATION,
    RDNA_OP_UPDATE_ON_EXPIRY,
    RDNA_AUTHORIZE_LDA_MANAGEMENT,
    RDNA_IDV_BIO_OPT_IN,
    RDNA_IDV_BIO_OPT_OUT,
    RDNA_IDV_CHALLENGE_BIOMETRIC_AND_DOCUMENT_SCAN,
    RDNA_IDV_API_BIOMETRIC_AND_DOCUMENT_SCAN,
    RDNA_IDV_API_AGENT_BIOMETRIC_AND_DOCUMENT_SCAN,
    RDNA_IDV_API_DOCUMENT_SCAN,
    RDNA_OP_STEP_UP_AUTH_AND_SIGN_DATA, 
    RDNA_OP_STEP_UP_AUTH,
    RDNA_MANAGE_LDA_SET_PASS,
    RDNA_MANAGE_LDA_RECONFIRM_VERIFY_PASS,
    RDNA_MANAGE_LDA_SET_LDA,
    RDNA_OP_MODE_NONE,
};

typedef NS_ENUM(NSInteger, RDNAIDVWorkflow) {
    IDV_ACTIVATION = 0,
    IDV_ACTIVATION_WITH_TEMPLATE,
    IDV_ADDITIONAL_DEVICE_WITH_TEMPLATE,
    IDV_ADDITIONAL_DEVICE_WITHOUT_TEMPLATE,
    IDV_ACCOUNT_RECOVERY_WITH_TEMPLATE,
    IDV_ACCOUNT_RECOVERY_WITHOUT_TEMPLATE,
    IDV_POSTLOGIN_KYC,
    IDV_POSTLOGIN_DOC_SCAN_ONLY,
    IDV_POSTLOGIN_IDV_SELFIE_BIOMETRIC,
    IDV_POSTLOGIN_IDV_STEPUP_AUTH,
    IDV_POSTLOGIN_OPTIN,
    IDV_POSTLOGIN_OPTOUT,
    IDV_POSTLOGIN_TEMPLATE_CHECK,
    IDV_POSTLOGIN_AGENT_KYC,
    IDV_ONBOARDING,
	IDV_LOGIN,
    IDV_POSTLOGIN_STEP_UP_AUTH_AND_SIGN_DATA,
    IDV_INVALID,
};

typedef NS_ENUM(NSInteger, RDNADeviceStatus) {
    RDNA_DEVSTATUS_ACTIVE = 0,
    RDNA_DEVSTATUS_UPDATE,
    RDNA_DEVSTATUS_DELETE,
    RDNA_DEVSTATUS_BLOCKED,     // - For Future use
    RDNA_DEVSTATUS_SUSPEND,     // - For Future use
};

typedef NS_ENUM(NSInteger, RDNADeviceBinding) {
    RDNA_PERMENANT = 0,
    RDNA_TEMPORARY,
};

typedef NS_ENUM(NSInteger, RDNAHttpMethods) {
    RDNA_HTTP_POST = 0,
    RDNA_HTTP_GET,
    RDNA_HTTP_HEAD,
    RDNA_HTTP_PUT,
    RDNA_HTTP_DELETE
};

typedef NS_ENUM(NSInteger, RDNASessionType){
    RDNA_APP_SESSION = 0x00,
    RDNA_USER_SESSION
};


typedef NS_ENUM(NSInteger, RDNAInitState) {
    STARTED = 0x00,
    COMPLETED,
    NOT_APPLICABLE,
    NOT_STARTED,
    INIT_FAILED
};

typedef NS_ENUM(NSInteger, RDNALDACapabilities) {
    RDNA_LDA_INVALID = 0,
    RDNA_LDA_FINGERPRINT,
    RDNA_LDA_FACE,
    RDNA_LDA_PATTERN,
    RDNA_LDA_SSKB_PASSWORD,
    RDNA_SEC_QA,
    RDNA_IDV_EXT_BIO_OPT_IN,   
    RDNA_IDV_EXT_BIO_OPT_OUT,   
    RDNA_LDA_DEVICE_PASSCODE,
    RDNA_DEVICE_LDA,
    RDNA_LDA_BIOMETRIC
};

typedef NS_ENUM(NSInteger, RDNALDAStatus) {
    RDNA_DISABLE_DEVICE_AUTHS = 0,
    RDNA_ENABLE_DEVICE_AUTHS
};

typedef NS_ENUM(NSInteger, RDNAIDVStatus) {
    RDNA_IDV_APPROVED = 0,
    RDNA_IDV_RECAPTURE,
    RDNA_IDV_CANCEL
};

typedef NS_ENUM(NSInteger, RDNAAuthenticatorType) {
    RDNA_AUTH_TYPE_NONE = 0,
    RDNA_IDV_SERVER_BIOMETRIC,
};

typedef NS_ENUM(NSInteger, RDNAAuthLevel) {
    RDNA_AUTH_LEVEL_NONE = 0,
    RDNA_AUTH_LEVEL_1, /* Logging Credentials ex:-LDA Or Manual Password */
    RDNA_AUTH_LEVEL_2, /* NA */
    RDNA_AUTH_LEVEL_3, /* NA */
    RDNA_AUTH_LEVEL_4  /* Strong Authenticator ex:- IDV Server Biometric */
};



@class RDNAChallenge;
@class RDNAError;

@interface RDNAPort : NSObject
@property (nonatomic) BOOL isStarted;            /* Specifies whether the service access is enabled                           */
@property (nonatomic) BOOL isLocalhostOnly;      /* Specifies whether the port is bound just on the local loopback interfaces */
@property (nonatomic) BOOL isAutoStarted;        /* Specifies whether the service access was started as part of the API-runtime initialization */
@property (nonatomic) BOOL isPrivacyEnabled;     /* Specifies whether use of the REL-ID Privacy API routines is mandated      */
@property (nonatomic) RDNAPortType portType;     /* Type of the port : proxy or portf                                         */
@property (nonatomic) uint16_t port;             /* Specifies the actual TCP port number for this service access              */
@end

/*
 @brief struct RDNAService : The service structure is unique for a given backend service, and specifies the unique logical name,
 target coordinates (hostname/IP and port number), access gateway details through which to access the service
 and access port details. It also specifies an opaque coordinate structure to be used when operating on the service using the ServiceAccess* API routines.
 */
@interface RDNAService : NSObject
@property (nonatomic, copy) NSString *serviceName;      /* logical service name  */
@property (nonatomic, copy) NSString *targetHNIP;       /* backend hostname/IP   */
@property (nonatomic) uint16_t targetPort;              /* backend port number   */
@property (nonatomic) RDNAPort *portInfo;               /* port setting and info */
@end

@interface RDNAResponseStatus : NSObject
@property (nonatomic, strong) NSString *message;                    /* Success or failure message if any.         */
@property (nonatomic, assign) RDNAResponseStatusCode statusCode;    /* Enum representing the status of challenge. */
@end

@interface RDNAStatusInit : NSObject
@property (nonatomic) void *pvtRuntimeCtx;      /* context of API runtime       */
@property (nonatomic) void *pvtAppCtx;          /* context of API-client        */
@property (nonatomic) int errCode;              /* error code return            */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;    /* update for method            */
@property (nonatomic) NSArray<RDNAService *> *services;        /* list of services             */
@property (nonatomic) RDNAPort *pxyDetails;     /* proxy details                */
@property (nonatomic) NSArray<RDNAChallenge *> *challenges;      /* challenge array in structure */
@end

@interface RDNAStatusTerminate : NSObject
@property (nonatomic) void *pvtRuntimeCtx;       /* context of API runtime */
@property (nonatomic) void *pvtAppCtx;           /* context of API-client  */
@property (nonatomic) int errCode;               /* error code return      */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;     /* update for method      */
@end

@interface RDNAStatusPauseRuntime : NSObject
@property (nonatomic) void *pvtRuntimeCtx;       /* context of API runtime */
@property (nonatomic) void *pvtAppCtx;           /* context of API-client  */
@property (nonatomic) int errCode;               /* error code return      */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;     /* update for method      */
@end

@interface RDNAStatusResumeRuntime : NSObject
@property (nonatomic) void *pvtRuntimeCtx;        /* context of API runtime               */
@property (nonatomic) void *pvtAppCtx;            /* context of API-client                */
@property (nonatomic) int errCode;                /* error code return                    */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;      /* update for method                    */
@property (nonatomic) NSArray<RDNAService *> *services;          /* list of services                     */
@property (nonatomic) RDNAPort *pxyDetails;       /* proxy details                        */
@property (nonatomic) NSArray<RDNAChallenge*> *challenges;    /* challenge array in structure             */
@property (nonatomic) RDNAResponseStatus *status;/* status code from server for challenge */
@end

@interface RDNAStatusGetConfig : NSObject
@property (nonatomic) void *pvtRuntimeCtx;       /* context of API runtime                                */
@property (nonatomic) void *pvtAppCtx;           /* context of API-client                                 */
@property (nonatomic) int errCode;               /* error code return                                     */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;     /* update for method                                     */
@property (nonatomic) NSString *responseData;    /* return the user specific configuration with json form */
@end

@interface RDNAProxySettings : NSObject
@property (nonatomic, copy) NSString *proxyHNIP; /* Proxy server's hostname/IP-address         */
@property (nonatomic) uint16_t proxyPort;        /* Proxy server's port number                 */
@property (nonatomic, copy) NSString *username;  /* Username for authentication, if applicable */
@property (nonatomic, copy) NSString *password;  /* Password for authentication, if applicable */
@end

@interface RDNADeviceDetails : NSObject
@property (nonatomic, readonly, copy) NSString *deviceUUID;
@property (nonatomic, copy) NSString *deviceName;
@property (nonatomic, readonly) RDNADeviceBinding deviceBinding;
@property (nonatomic,copy,readonly) NSString *deviceStatus;
@property (nonatomic, readonly, copy) NSString *deviceRegistrationTime __attribute__((deprecated("Use deviceRegistrationEpochTime instead")));
@property (nonatomic, readonly) NSTimeInterval deviceRegistrationEpochTime;
@property (nonatomic, readonly, copy) NSString *lastAccessTime __attribute__((deprecated("Use lastAccessEpochTime instead")));
@property (nonatomic, readonly) NSTimeInterval lastAccessEpochTime;
@property (nonatomic, readonly, copy) NSString *AppUUID;
@property (nonatomic, readonly) BOOL currentDevice;

- (void)deleteDevice;                                                   /*API to delete the particular registered device*/
- (void)setDeviceName:(NSString *)deviceName;                           /*API to change device name*/
@end

/*
 @brief RDNAStatusGetRegisteredDeviceDetails : This is get registred device details status structure, which will return all the devices
 registred by the user, user can be able to delete the devices or change the device name
 */
@interface RDNAStatusGetRegisteredDeviceDetails : NSObject
@property (nonatomic) void *pvtRuntimeCtx;
@property (nonatomic) void *pvtAppCtx;
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) NSArray<RDNADeviceDetails*> *devices;
@property (nonatomic) RDNAResponseStatus *status;                     /* Challenge status information   */
@end

/*
 @brief RDNAStatusUpdateDeviceDetails_s : This is update device details status structure, which will return the status
 */
@interface RDNAStatusUpdateDeviceDetails : NSObject
@property (nonatomic) void *pvtRuntimeCtx;                            /* context of API runtime         */
@property (nonatomic) void *pvtAppCtx;                                /* context of API-client          */
@property (nonatomic) int errCode;                                    /* error code return              */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;                          /* update for method              */
@property (nonatomic) RDNAResponseStatus *status;                     /* Challenge status information   */
@end

// Advanced API_SDK
@interface RDNAExpectedResponse : NSObject
@property (nonatomic,strong) NSString *responseLabel;      /* label of the expected response                         */
@property (nonatomic,strong) NSString *response;           /* Actual response value to be set for the notification   */
@property (nonatomic) int nAuthLevel;
@property (nonatomic,strong) NSString *authenticator;
@end

@interface RDNAResponseLabel : NSObject
@property (nonatomic,strong) NSString *responseLabel;      /* label of the expected response                         */
@property (nonatomic,strong) NSString *response;           /* Actual response value to be set for the notification   */

@end

@interface RDNANotfBody : NSObject
@property (nonatomic,strong) NSString *language;                               //Language of the payload
@property (nonatomic,strong) NSString *subject;                                //Subject of the notification
@property (nonatomic,strong) NSString  *notificationMessage;                    //Notification Text to be displayed to user
@property (nonatomic,strong) NSArray<RDNAResponseLabel *> *displayLabels;
@end

@interface RDNANotification : NSObject
@property (nonatomic,strong) NSString *notificationID;                           /* Unique ID for notifications                         */
@property (nonatomic,strong) NSString *notificationResponse;                     /* user response of the Notification                   */
@property (nonatomic) NSTimeInterval notificationCreatedEpochTime;                   /* Notification created timestamp                              */
@property (nonatomic,strong) NSString *notificationExpireTime __attribute__((deprecated("Use notificationExpireEpochTime instead")));                   /* Notification expiry timestamp                              */
@property (nonatomic) NSTimeInterval notificationExpireEpochTime;                   /* Notification expiry timestamp                              */
@property (nonatomic,strong) NSString *enterpriseID;                             /* Enterprise ID which we have got while onboarding the enterprise application */
@property (nonatomic) int nNumLanguages;   /*number of language suppoted to notification*/
@property (nonatomic,strong) NSArray<RDNANotfBody *> *notfBody;  /* All the possible responses of the notification      */
@property (nonatomic,strong) NSArray<RDNAExpectedResponse *> *expectedResponse;  /* All the possible responses of the notification      */
@end

@interface RDNANotfHistBody : NSObject
@property (nonatomic,strong) NSString *language;                               //Language of the payload
@property (nonatomic,strong) NSString *subject;                                //Subject of the notification
@property (nonatomic,strong) NSString *notificationMessage;                    //Notification Text to be displayed to user
@end

@interface RDNANotificationHistory : NSObject
@property (nonatomic) int nNumLanguages;                 // Number of languages the notification has            : Body array length
@property (nonatomic,strong) NSString *notificationID;       /* Unique ID for notifications                                                */
@property (nonatomic,strong) NSString *status;               /* <ACTIVE / EXPIRED / UPDATED>                                               */
@property (nonatomic,strong) NSArray<RDNANotfHistBody*> *notfBody;/*Subject & Message of notification */
@property (nonatomic,strong) NSString *actionPerformed;      /* Notification action taken by user                                          */
@property (nonatomic,strong) NSString *deviceName;           /* name of the device on which the notification was acted upon.               */
@property (nonatomic,strong) NSString *deviceUUID;           /* UUID of the device on which the notification was acted upon.               */
@property (nonatomic,strong) NSString *createdTime __attribute__((deprecated("Use createdEpochTime instead")));          /* Notification generated time on server                                      */
@property (nonatomic) NSTimeInterval createdEpochTime;          /* Notification generated time on server                                      */
@property (nonatomic,strong) NSString *updatedTime __attribute__((deprecated("Use updatedEpochTime instead")));          /* Notification action taken by user time                                     */
@property (nonatomic) NSTimeInterval updatedEpochTime;          /* Notification action taken by user time                                     */
@property (nonatomic,strong) NSString *expiredTime __attribute__((deprecated("Use expiredEpochTime instead")));          /* Notification expired time                                                  */
@property (nonatomic) NSTimeInterval expiredEpochTime;          /* Notification expired time                                                  */
@property (nonatomic,strong) NSString *enterpriseID;         /* EnterpriseID which we have got while onboarding the enterprise application */
@property (nonatomic,strong) NSString *signingStatus;       /*Whether the notification signing was success or not  : signing_status*/
@property (nonatomic,strong) NSString *deliveryStatus;       /*Notification delivery status                         : delivery_status*/
@end

@interface RDNAStatusGetNotifications : NSObject
@property (nonatomic) void *pvtRuntimeCtx;                              /* context of API runtime                                */
@property (nonatomic) void *pvtAppCtx;                                  /* context of API-client                                 */
@property (nonatomic) int  errCode;                                     /* error code return                                     */
@property (nonatomic) RDNAError *error;
@property (nonatomic) int totalNotificationCount;                       /* Total notifications available in server side for user */
@property (nonatomic) int startIndex;                                   /* Index of the record from which records are fetched    */
@property (nonatomic) int fetchedNotificationCount;                     /* Total count of notifications that are fetched         */
@property (nonatomic) RDNAMethodID methodID;                            /* update for method                                     */
@property (nonatomic) RDNAResponseStatus *status;                       /* Status code of notification update                    */
@property (nonatomic,strong) NSArray<RDNANotification *> *notifications;/* notification array                                    */
@end

@interface RDNAStatusUpdateNotification : NSObject
@property (nonatomic) void *pvtRuntimeCtx;        /* context of API runtime                           */
@property (nonatomic) void *pvtAppCtx;            /* context of API-client                            */
@property (nonatomic) int  errCode;               /* error code return                                */
@property (nonatomic) RDNAError *error;
@property (nonatomic) NSString *notificationID;   /* Notification ID for which the status is updated  */
@property (nonatomic) RDNAMethodID methodID;      /* update for method                                */
@property (nonatomic) RDNAResponseStatus *status; /* Status code of notification update               */
@end

@interface RDNAStatusGetNotificationHistory : NSObject
@property (nonatomic) void *pvtRuntimeCtx;                                     /* Context of API runtime                                */
@property (nonatomic) void *pvtAppCtx;                                         /* Context of API-client                                 */
@property (nonatomic) int errCode;                                             /* Error code return                                     */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;                                   /* Represents the callback method id                     */
@property (nonatomic) int totalNotificationCount;                              /* Total notifications available in server side for user */
@property (nonatomic) RDNAResponseStatus *status;                              /* Response status information                           */
@property (nonatomic,strong) NSArray<RDNANotificationHistory *> *notificationHistory;/* Notification History array                       */
@end


/*
 @brief RDNAStatusCheckChallengeResponse : This is checkChallenge status class, which will return the status of previous challenge verification status and next challenges if any
 if no more challenges for verification then the new service details which can be used by the user. and configured at the user level.
 */
@interface RDNAStatusCheckChallengeResponse : NSObject
@property (nonatomic) void *pvtRuntimeCtx;              /* context of API runtime        */
@property (nonatomic) void *pvtAppCtx;                  /* context of API-client         */
@property (nonatomic) int errCode;                      /* error code return             */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;            /* update for method             */
@property (nonatomic) RDNAPort *pxyDetails;             /* proxy details                 */
@property (nonatomic) RDNAResponseStatus *status;       /* Challenge status information  */
@property (nonatomic) NSArray<RDNAService *> *services;                /* list of services              */
@property (nonatomic) NSArray<RDNAChallenge *> *challenges;              /* Challenge array               */
@property (nonatomic, strong) NSString *jwt;         /* JSON Web Token */
@end

/*
 @brief RDNAStatusUpdateChallenges : This is update challenge status class, which will return the status of previous challenge update status and next challenges if any.
 */
@interface RDNAStatusUpdateChallenges : NSObject
@property (nonatomic) void *pvtRuntimeCtx;              /* context of API runtime        */
@property (nonatomic) void *pvtAppCtx;                  /* context of API-client         */
@property (nonatomic) int errCode;                      /* error code return             */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;            /* update for method             */
@property (nonatomic) RDNAResponseStatus *status;       /* Challenge status information  */
@property (nonatomic) NSArray<RDNAChallenge *> *challenges ;             /* Challenge array               */
@end

/*
 @brief RDNAStatusGetAllChallenges : This is get all challenge status class, which will return challenges which can be updated by the user.
 */
@interface RDNAStatusGetAllChallenges : NSObject
@property (nonatomic) void *pvtRuntimeCtx;              /* context of API runtime        */
@property (nonatomic) void *pvtAppCtx;                  /* context of API-client         */
@property (nonatomic) int errCode;                      /* error code return             */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;            /* update for method             */
@property (nonatomic) RDNAResponseStatus *status;       /* Challenge status information  */
@property (nonatomic) NSArray<RDNAChallenge *> *challenges ;             /* Challenge array               */
@end

/*
 @brief RDNAStatusGetPostLoginChallenges : This is get post challenge status class, which will retrun challenges which can be used for post login authentication, if required.
 */
@interface RDNAStatusGetPostLoginChallenges : NSObject
@property (nonatomic) void *pvtRuntimeCtx;
@property (nonatomic) void *pvtAppCtx;
@property (nonatomic) int errCode;
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;
@property (nonatomic) RDNAResponseStatus *status;
@property (nonatomic) NSArray<RDNAChallenge *> *challenges;
@end

/*
 @brief RDNAStatusForgotPassword : This is forgot password status class, which will return the challenges for verification when user initiates the forgot password.
 */
@interface RDNAStatusForgotPassword : NSObject
@property (nonatomic) void *pvtRuntimeCtx;              /* context of API runtime        */
@property (nonatomic) void *pvtAppCtx;                  /* context of API-client         */
@property (nonatomic) int errCode;                      /* error code return             */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;            /* update for method             */
@property (nonatomic) RDNAResponseStatus *status;       /* Challenge status information  */
@property (nonatomic) NSArray<RDNAChallenge *> *challenges ;             /* Challenge array               */
@end


@interface RDNAStatusLogOff : NSObject
@property (nonatomic) void *pvtRuntimeCtx;       /* context of API runtime                */
@property (nonatomic) void *pvtAppCtx;           /* context of API-client                 */
@property (nonatomic) int errCode;               /* error code return                     */
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAMethodID methodID;     /* update for method                     */
@property (nonatomic) NSArray<RDNAService *> *services;         /* list of services                      */
@property (nonatomic) RDNAPort *pxyDetails;      /* proxy details                         */
@property (nonatomic) NSArray<RDNAChallenge *> *challenges;       /* challenge array in structure          */
@property (nonatomic) RDNAResponseStatus *status;/* status code from server for challenge */
@end

@interface RDNAIWACreds : NSObject
@property (nonatomic, strong) NSString *userName;      /* username for particular domain url */
@property (nonatomic, strong) NSString *password;      /* password for particular domain url */
@property (assign) RDNAIWAAuthStatus authStatus;
@end

@interface RDNAHTTPRequest : NSObject
@property (nonatomic,assign) RDNAHttpMethods method;
@property (nonatomic,strong) NSString* url;
@property (nonatomic,strong) NSDictionary* headers;
@property (nonatomic,strong) NSData* body;
@end

@interface RDNAHTTPResponse : NSObject
@property (nonatomic,copy) NSString* version;
@property (nonatomic,assign) int statusCode;
@property (nonatomic,strong) NSString* statusMessage;
@property (nonatomic,strong) NSDictionary* headers;
@property (nonatomic,strong) NSData* body;
@end

@interface RDNAHTTPStatus : NSObject
@property (nonatomic,assign) int errorCode;
@property (nonatomic) RDNAError *error;
@property (nonatomic,assign) int requestID;
@property (nonatomic,strong) RDNAHTTPRequest* request;
@property (nonatomic,strong) RDNAHTTPResponse* response;
@end


@interface RDNASSLCertificate : NSObject
@property (nonatomic,strong) NSString* p12Certificate;
@property (nonatomic,strong) NSString* password;
@property (nonatomic, assign) BOOL enableSSL;
@end

/*
 @brief struct RDNAChallengeInfo : The challenge info class specifies the information regarding the challenge, this may contain the UI level descrption messages for the specific ui screen of challenge, UI labels etc.
 */
@interface RDNAChallengeInfo : NSObject
@property (nonatomic, strong) NSString *infoKey;                /* Challenge Details  */
@property (nonatomic, strong) NSString *infoMessage;            /* Message            */
@end

@interface RDNAChallenge : NSObject
@property (nonatomic, strong, readonly) NSString *name;
@property (nonatomic, assign, readonly) RDNAChallengePromptType type;
@property (nonatomic, assign, readonly) int index;
@property (nonatomic, assign, readonly) int subChallengeIndex;
@property (nonatomic, strong, readonly) NSArray<RDNAChallengeInfo *> *info;
@property (nonatomic, strong, readonly) NSArray *prompts;
@property (nonatomic, assign, readonly) int attemptsLeft;
@property (nonatomic, assign, readonly) BOOL shouldValidateResponse;
@property (nonatomic, strong, readonly) NSArray *responsePolicies;
@property (nonatomic, strong) NSString *responseKey;
@property (nonatomic, strong) NSString *responseValue;
@property (nonatomic) RDNAChallengeOpMode challengeOperation;
@end

@interface RDNAError:NSObject
@property (nonatomic) int longErrorCode;
@property (nonatomic) RDNAErrorID errorCode;
@property (nonatomic,copy) NSString* errorString;
@end

@interface RDNASession:NSObject
@property (nonatomic,copy) NSString* sessionID;
@property (nonatomic) RDNASessionType  sessionType;
@end

@interface RDNARequestStatus : NSObject
@property (nonatomic) int statusCode;
@property (nonatomic,copy) NSString* statusMessage;
@end

@interface RDNAGroupInfo : NSObject
@property (nonatomic,strong) NSString* groupName;
@property (nonatomic,strong) NSString* groupDescription;
@end

@interface RDNAAdditionalInfo : NSObject
@property (nonatomic) int RDNAProxyPort;
@property (nonatomic) BOOL isRDNAProxyPortLocalHost;
@property (nonatomic) BOOL setGlobalProxy;
@property (nonatomic) BOOL isAdUser;
@property (nonatomic,copy) NSString* JWT;
@property (nonatomic,copy) NSString* accessTokenInfo;
@property (nonatomic,copy) NSString* jwtJsonTokenInfo;
@property (nonatomic,copy) NSString* settings;
@property (nonatomic,copy) NSString* configSettings;
@property (nonatomic,copy) NSString* mTLSP12Bundle;
@property (nonatomic,strong)NSArray<NSString *> *loginIDs;
@property (nonatomic,copy) NSString* currentWorkFlow;
@property (nonatomic,copy) NSString* idvUserRole;
@property (nonatomic,strong) NSMutableArray<RDNAGroupInfo *> *availableGroupInfo;
@end

@interface RDNAChallengeResponse : NSObject
@property (nonatomic) RDNARequestStatus *status;
@property (nonatomic, strong) NSArray<RDNAChallengeInfo *> *info;
@property (nonatomic) RDNASession *sessionInfo;
@property (nonatomic) RDNAAdditionalInfo *additionalInfo;

@end

@interface RDNAAppInfo : NSObject
@property (nonatomic, strong) NSString *appName;
@property (nonatomic, strong) NSString *appSha256;
@property (nonatomic, strong) NSString *packageName;
@end

@interface RDNANetworkInfo : NSObject
@property (nonatomic, strong) NSString *ssid;
@property (nonatomic, strong) NSString *bssid;
@property (nonatomic, strong) NSString *maliciousAddress;
@property (nonatomic, strong) NSString *maliciousMacAddress;
@end

@interface RDNAThreat : NSObject
@property (nonatomic, strong) NSString *threatName;
@property (nonatomic, strong) NSString *threatMsg;
@property (nonatomic, strong) NSString *threatReason;
@property (nonatomic, strong) NSString *threatSeverity;
@property (nonatomic, strong) NSString *threatCategory;
@property (nonatomic, strong) NSString *configured_action;
@property (nonatomic) int threatId;
@property (nonatomic) RDNAAppInfo *appInfo;
@property (nonatomic) RDNANetworkInfo *networkInfo;
@property (nonatomic) BOOL shouldProceedWithThreats;
@property (nonatomic) BOOL rememberActionForSession;
@end

@interface RDNAThreatDetails : NSObject
@property (nonatomic, strong) NSArray<RDNAThreat*> *userConsentThreats;
@property (nonatomic, strong) NSArray<RDNAThreat*> *terminateOnThreats;
@end

@interface RDNAThreatLog : NSObject
@property (nonatomic, strong) NSString *threatName;
@property (nonatomic, strong) NSString *threatMsg;
@property (nonatomic, strong) NSString *threatReason;
@property (nonatomic, strong) NSString *threatSeverity;
@property (nonatomic, strong) NSString *threatCategory;
@property (nonatomic) int threatId;
@property (nonatomic) RDNAAppInfo *appInfo;
@property (nonatomic) RDNANetworkInfo *networkInfo;
@property (nonatomic) NSString *reportedTime;
@property (nonatomic) NSString *actionTakenTime;
@property (nonatomic, strong) NSString *configuredAction;
@property (nonatomic, strong) NSString *actionTaken;

@end

@interface RDNAInitProgressStatus : NSObject

@property (nonatomic) RDNAInitState systemThreatCheckStatus;
@property (nonatomic) RDNAInitState appThreatCheckStatus;
@property (nonatomic) RDNAInitState networkThreatCheckStatus;
@property (nonatomic) RDNAInitState initializeStatus;

@end

@interface RDNAThreatLogDetails : NSObject
@property (nonatomic) int totalLogsCount;
@property (nonatomic) int startIndex;
@property (nonatomic) RDNAError *error;
@property (nonatomic) RDNAThreatLog *threatLog;
@end

@interface RDNASecretQuestionAndAnswer : NSObject
@property (nonatomic, copy) NSString *secretQuestion;
@property (nonatomic, copy) NSString *secretAnswer;
@end

@interface RDNADeviceAuthenticationDetails : NSObject
@property (nonatomic) RDNALDACapabilities authenticationType;
@property (nonatomic) BOOL isEnabled;
@end

@interface RDNADataSigningDetails : NSObject
@property (nonatomic, strong) NSString *dataPayload;
@property (nonatomic, strong) NSString *payloadSignature;
@property (nonatomic, strong) NSString *dataSignatureID;
@property (nonatomic) RDNAAuthLevel authLevel;
@property (nonatomic) RDNAAuthenticatorType authenticatorType;
@property (nonatomic, strong) NSString *reason;
@end


@class RDNAPrivacyStream;


/**
 * RDNAPrivacyStreamCallBacks - This is a callback routine supplied by the API-client.
 */
@protocol RDNAPrivacyStreamCallBacks

@required

/**
 * @brief This routine is invoked from within the WriteDataIntoStream routine,
 * when the requisite number of blocks are ready for consumption by the API-client
 * (i.e. when that many blocks have been encrypted/decrypted)
 * @param rdnaPrivacyStream    - RDNA Privacy stream reference.
 * @param pvBlockReadyCtx   - Opaque block ready context passed by API-Client
 * @param pvBlockBuf        - Encrypted/Decrypted data block which is ready
 * @param nBlockSize        - Data block size.
 * @return                  - If success return 0 else appropriate error code.
 */
- (int)onBlockReadyFor:(RDNAPrivacyStream *)rdnaPrivacyStream
     BlockReadyContext:(id)pvBlockReadyCtx
    PrivacyBlockBuffer:(NSData *)pvBlockBuf
          andBlockSize:(int)nBlockSize;
@end

/**
 * class RDNAPrivacyStream - Interface class to be implemented by API-Client
 */
@interface RDNAPrivacyStream : NSObject {
@public
    id <RDNAPrivacyStreamCallBacks> callBack;
    void *corePrivyStream;
}

/**
 * @brief getPrivacyScope -
 * @return                -
 */
- (int)getPrivacyScope:(RDNAPrivacyScope *)privacyScope;

/**
 * @brief getStreamType -
 * @return              -
 */
- (int)getStreamType:(RDNAStreamType *)streamType;

/**
 * @brief writeDataIntoStream -
 * @param data          -
 */
- (int)writeDataIntoStream:(NSData *)data;

/**
 * @brief endStream -
 */
- (int)endStream;

/**
 * @brief cleanup - Method called to do the cleanup activity on the stream.
 */
- (int)destroy;

@end


/**
 * protocol RDNAHTTPCallbacks - Interface class to be implemented by end consumer.
 */
@protocol RDNAHTTPCallbacks
@required
/**
 * @brief onHttpResponse - Method is called by the API runtime to get http request response.
 */
- (int)onHttpResponse:(RDNAHTTPStatus *) status;
@end

@interface RDNAStruct : NSObject

@end

NS_ASSUME_NONNULL_END
