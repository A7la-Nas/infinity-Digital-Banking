#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLLocationManagerDelegate_symbols(JSContext*);
@protocol CLLocationManagerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) locationManager: (CLLocationManager *) manager didUpdateToLocation: (CLLocation *) newLocation fromLocation: (CLLocation *) oldLocation ;
-(void) locationManager: (CLLocationManager *) manager didUpdateLocations: (NSArray *) locations ;
-(void) locationManager: (CLLocationManager *) manager didUpdateHeading: (CLHeading *) newHeading ;
-(BOOL) locationManagerShouldDisplayHeadingCalibration: (CLLocationManager *) manager ;
-(void) locationManager: (CLLocationManager *) manager didDetermineState: (CLRegionState) state forRegion: (CLRegion *) region ;
-(void) locationManager: (CLLocationManager *) manager didRangeBeacons: (NSArray *) beacons inRegion: (CLBeaconRegion *) region ;
-(void) locationManager: (CLLocationManager *) manager rangingBeaconsDidFailForRegion: (CLBeaconRegion *) region withError: (NSError *) error ;
-(void) locationManager: (CLLocationManager *) manager didRangeBeacons: (NSArray *) beacons satisfyingConstraint: (CLBeaconIdentityConstraint *) beaconConstraint ;
-(void) locationManager: (CLLocationManager *) manager didFailRangingBeaconsForConstraint: (CLBeaconIdentityConstraint *) beaconConstraint error: (NSError *) error ;
-(void) locationManager: (CLLocationManager *) manager didEnterRegion: (CLRegion *) region ;
-(void) locationManager: (CLLocationManager *) manager didExitRegion: (CLRegion *) region ;
-(void) locationManager: (CLLocationManager *) manager didFailWithError: (NSError *) error ;
-(void) locationManager: (CLLocationManager *) manager monitoringDidFailForRegion: (CLRegion *) region withError: (NSError *) error ;
-(void) locationManager: (CLLocationManager *) manager didChangeAuthorizationStatus: (CLAuthorizationStatus) status ;
-(void) locationManagerDidChangeAuthorization: (CLLocationManager *) manager ;
-(void) locationManager: (CLLocationManager *) manager didStartMonitoringForRegion: (CLRegion *) region ;
-(void) locationManagerDidPauseLocationUpdates: (CLLocationManager *) manager ;
-(void) locationManagerDidResumeLocationUpdates: (CLLocationManager *) manager ;
-(void) locationManager: (CLLocationManager *) manager didFinishDeferredUpdatesWithError: (NSError *) error ;
-(void) locationManager: (CLLocationManager *) manager didVisit: (CLVisit *) visit ;
@end
@protocol CLLocationManagerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop